# What If You And Your Crush Were Stranded On An Island Alone?

Voiced timing: 10:20

`0:00` Your fingers unclench in warm salt surf,

`0:02` clutching a soaked boarding pass stamped Seat Fourteen-B.

`0:06` Behind you, the sheared aluminum cabin of Flight Eight-Fifteen hisses with gray smoke on a white coral sandbar.

`0:12` Three meters away, the girl you spent all semester rehearsing a single hello for sits up in the foam.

`0:18` > **CRUSH:** Please tell me this is a layover.

`0:19` You scan three hundred sixty degrees of empty turquoise horizon and swallow hard.

`0:24` Not a single boat.

`0:25` So, what if you

`0:27` and your crush were stranded on an island alone?

`0:30` Forget movie montages.

`0:31` Here is how ocean physics and human biology actually play out.

`0:34` When the tail section sheared off in a microburst,

`0:37` the forward slide rafts drifted twelve kilometers upwind.

`0:41` What changes immediately is every social filter you had in school.

`0:45` Popularity, grades, and Wi-Fi are gone.

`0:47` What stays brutally normal is your body's water clock

`0:50` and the geometry of the Pacific Ocean.

`0:53` File that ocean geometry away in your back pocket.

`0:55` In four days, your lives depend on it.

`0:58` Here is a fact that sounds made up.

`1:00` Even when air traffic control knows your route, ocean search grids explode.

`1:05` A jet gliding off radar for twenty minutes creates a search circle of forty-five thousand square kilometers.

`1:11` A rescue plane flying at three hundred meters can only scan a two-kilometer corridor on each pass.

`1:17` Spotting two teens on a three-hundred-meter sandbar inside

`1:20` that circle is like finding two ants across ten thousand football fields.

`1:24` > **CRUSH:** Stop doing math. You're making it worse.

`1:27` You promise to stop calculating odds right

`1:29` after you check the clock that actually matters.

`1:32` Now, the strange part.

`1:34` Starvation is not the enemy that hunts castaways on a tropical atoll.

`1:38` Wilderness medics live by the Rule of Threes: three minutes without air, three days without water, three weeks without food.

`1:45` At thirty-two degrees Celsius,

`1:46` two people lose four liters of water a day just sweating and breathing.

`1:50` You are surrounded by quadrillions of liters of water,

`1:53` yet a single gulp of seawater accelerates dehydration.

`1:56` Seawater contains thirty-five grams of salt per liter, while human kidneys max out at twenty grams per liter.

`2:03` To flush the extra fifteen grams of salt,

`2:05` your kidneys pull half a liter of water out of your own cells.

`2:09` > **CRUSH:** So the ocean is basically liquid sandpaper.

`2:11` That means you have exactly seventy-two hours.

`2:14` Before the tide rises, you both strip the fuselage for salvage.

`2:18` First, you pry loose a curved aluminum leading-edge wing slat polished to a mirror finish by wind friction.

`2:24` A flat pocket mirror scatters light after three kilometers, but a curved wing slat focuses a flash visible thirty-seven kilometers out.

`2:32` Second, you pull your dead smartphone from your pocket.

`2:35` The screen is cracked, but its sealed lithium-ion pouch holds fifteen watt-hours.

`2:40` Third, she carefully smooths out her pink Seat Fourteen-B boarding pass

`2:44` and zips it inside her dry collar pocket.

`2:47` > **CRUSH:** Don't ask. It's my lucky ticket.

`2:49` Fourth, wedged beneath the cockpit floor bulkhead,

`2:52` you find a locked brushed-titanium case with a blinking red biometric sensor.

`2:56` It has no passenger name tag, weighs nine kilograms, and is hermetically sealed.

`3:01` You haul it up to dry sand.

`3:03` As afternoon heat hits the lagoon, you test your gear

`3:06` and lock in three island physics rules.

`3:08` Rule one: green palm fronds boil sap into thick white smoke. Rule two: a four-to-one driftwood lever multiplies lifting force by four.

`3:17` You prove Rule Two by resting a two-point-four-meter ironwood spar over a basalt rock to lift a heavy seat frame effortlessly.

`3:24` Then you test Rule Three: tilting the concave wing slat toward the sun focuses a pinpoint beam

`3:30` that chars dry bark at four hundred ten degrees.

`3:33` You lash three driftwood branches into an aiming tripod beside the fire ring

`3:37` so the wing slat can sweep the horizon.

`3:39` With the science sorted, your teen brain switches to its second priority:

`3:43` looking cool in front of your crush.

`3:46` You pick up a fallen coconut, tell her to stand back,

`3:49` and attempt a movie-style karate chop.

`3:51` Your hand slams into the fibrous shell

`3:53` and bounces straight off with a hollow thud.

`3:56` Mature coconut shells resist twenty megapascals of pressure,

`3:59` roughly the same as red paving brick.

`4:01` The nut doesn't even scratch.

`4:03` > **CRUSH:** Coconut one, action hero zero.

`4:06` While you shake out your bruised fingers,

`4:08` she wedges a pointed basalt stone upright in the sand.

`4:11` Using leverage instead of ego, she spears the husk onto the stone point

`4:15` and twists it open in four seconds.

`4:17` Each green coconut yields four hundred milliliters of sterile electrolyte water rich in potassium.

`4:23` She lets you have the first sip.

`4:25` On Day Two, determined to redeem your pride,

`4:28` you fire-harden a bamboo pole into a four-pronged fishing spear.

`4:31` Knee-deep in the crystal reef,

`4:33` you spot a fat blue parrotfish hovering motionless beside a coral head.

`4:37` You lunge dead-center at its back,

`4:39` miss by thirty centimeters, and belly-flop into the salt lagoon.

`4:43` > **CRUSH:** Did you just tackle the ocean?

`4:45` Light slows down in water at a refractive index of one point three three, bending the image upward toward the surface.

`4:52` Because your brain assumes light travels in straight lines,

`4:55` every underwater target sits deeper and closer than it looks.

`4:58` > **CRUSH:** Aim below the belly, Einstein.

`5:00` You aim a hand's width under the hologram, strike true,

`5:04` and hold up lunch while she gives you a slow clap.

`5:07` On Day Three, you haul split bamboo poles to the dry dune ridge to build an A-frame shelter.

`5:12` Your first vine lashing snaps,

`5:14` dropping twenty kilograms of wet palm thatch straight over your head like a green wig.

`5:19` She steps in, ties square knots using braided hibiscus bark cordage,

`5:23` and locks the ridgepole rock-solid.

`5:25` There is only one small catch:

`5:26` the triangular floor frame is just wide enough for a single leaf mattress.

`5:31` Coconut water won't last forever,

`5:33` so you dig three conical pits one meter wide in the damp sand above the tideline.

`5:38` You pack crushed green shoreline plants around a central cup,

`5:41` cover the pit with clear cabin plastic, and center a pebble.

`5:45` Greenhouse heat evaporates pure water out of the damp sand and leaves the salt behind, dripping eight hundred milliliters per pit.

`5:52` Three solar stills produce two point four liters of distilled water every day.

`5:56` Combined with coconuts, you beat the dehydration clock.

`6:00` By Night Four, the solar-ignited driftwood fire crackles warmly

`6:03` under a sky of five thousand Bortle-One stars.

`6:06` > **CRUSH:** I was in row six. I paid fifty bucks to sit by you.

`6:10` > **CRUSH:** Best fifty dollars I ever spent.

`6:12` Sitting shoulder to shoulder by the surf,

`6:14` part of you secretly hopes the rescue ship takes another week.

`6:18` No cargo freighter or cruise liner will ever pass within visual range of this reef by chance.

`6:23` And then you see the real problem rising on the western horizon:

`6:27` a rotating black wall of cumulonimbus clouds.

`6:30` A Category Four cyclone is spinning toward the atoll at two hundred twenty kilometers per hour, twelve hours away.

`6:36` The barometer in the cockpit altimeter drops twenty-four millibars.

`6:40` A two-meter storm surge is coming right over a one-point-two-meter beach.

`6:44` > **CRUSH:** The whole beach is going underwater.

`6:46` Raw strength cannot fight a cyclone,

`6:48` and shouting cannot cross thirty-seven kilometers of ocean.

`6:51` Your survival rule is simple: don't fight the ocean with muscle. Chain the physics: leverage, thermal spark, steam smoke, parabolic flash.

`7:00` You seal dry coconut tinder and the foil wrapper around the lithium battery,

`7:05` and anchor the aiming tripod with heavy basalt rocks.

`7:08` Six hours early, the cyclone's outer squall line slams

`7:11` into the lagoon with horizontal rain and roaring surf.

`7:14` Then, through a narrow break in the storm clouds,

`7:17` a twin-engine Coast Guard search plane banks thirty-seven kilometers out!

`7:21` Flying its last pre-storm grid at two hundred forty knots, that plane will cross your horizon in one hundred eighty seconds.

`7:28` You both sprint toward the wreck to grab the wing slat,

`7:30` when a king-tide wave rolls the fuselage tail section!

`7:33` A one-hundred-eighty-kilogram aluminum structural beam drops across her boot,

`7:38` pinning her ankle in the rising surf!

`7:40` > **CRUSH:** It's pinned! Leave me, flash the plane!

`7:43` You grip the wet aluminum beam

`7:45` and deadlift with every muscle in your back.

`7:47` One hundred eighty kilograms in suction sand does not move.

`7:51` Here is the brutal math: the surge rises ten centimeters a minute.

`7:55` In two minutes the water reaches her chin,

`7:57` and in two minutes the plane is gone.

`8:00` The plane...

`8:01` or her life.

`8:01` You refuse the choice and execute the theme rule.

`8:04` Step one: Archimedes and the four-to-one driftwood lever!

`8:07` You jam the two-point-four-meter ironwood spar under the beam

`8:11` and roll a basalt boulder forty centimeters from the load as a fulcrum.

`8:15` Throwing forty-five kilograms onto the long arm multiplies

`8:18` into one hundred eighty kilograms of upward torque.

`8:21` The beam lifts and she slides free!

`8:23` Fifty-two seconds left!

`8:25` You half-carry her to the fire ring, pull out the foil pretzel wrapper,

`8:29` and bridge the lithium phone battery leads!

`8:32` Fifteen watt-hours discharge through the foil ribbon at four hundred ten degrees Celsius,

`8:37` bursting the dry coconut husk core into roaring flame!

`8:40` She heaps wet green palm fronds onto the core,

`8:43` boiling the sap into a towering white smoke column against the dark storm wall!

`8:48` Sixteen seconds!

`8:49` The plane is already banking away,

`8:51` so you lock the concave aluminum wing slat onto the driftwood tripod sight!

`8:55` Catching a red ray of sunset beneath the cloud deck,

`8:58` you sweep the thirty-seven-kilometer beam across the cockpit.

`9:02` Flash one.

`9:03` Flash two.

`9:04` Flash three!

`9:04` A surge wave sweeps your melted phone shell

`9:07` and the last foil pretzel wrapper out to sea as the plane rocks its wings and drops a green flare.

`9:12` The pretzel bag did not make it.

`9:14` You climb together onto the forty-meter basalt ridge above the storm surge,

`9:18` where a rescue helicopter touches down at dawn.

`9:21` By noon, the cockpit camera clip hits four million views under an ironic headline:

`9:26` Teen Signals Coast Guard With A Dead Phone And A Broken Wing.

`9:30` > **CRUSH:** Next time, we're taking a train.

`9:32` You don't need a rehearsed hallway line anymore.

`9:35` You just laugh, take her hand, and walk toward the open cabin door.

`9:39` Then, as you lift the salvaged nine-kilogram titanium case onto the helicopter skid,

`9:43` the flight commander freezes cold.

`9:46` > **COMMANDER:** Control, Asset Fourteen-B and the cargo survived.

`9:49` You look down at the titanium case's biometric plate.

`9:52` Laser-etched beside the red light is her exact seat number: Fourteen-B.

`9:56` And on the sheared fuselage latch behind you,

`9:59` the bolts weren't torn by wind.

`10:00` They were blown outward before takeoff.

`10:03` The crash was never an accident.

`10:05` So what is the first survival hack you would build if you were stranded on that island?

`10:10` And when that pilot reaches for the Fourteen-B case,

`10:13` do you board the helicopter or run back into the jungle?

`10:16` Tell us in the comments.

`10:18` See you in the next what-if.
