# What If You And Your Crush Were Stranded On An Island Alone?

Voiced timing: 10:20

`0:00` > **YOU:** Your fingers unclench in warm salt surf,

`0:02` clutching a soaked boarding pass stamped Seat Fourteen-B.

`0:06` > **YOU:** Behind you, the sheared aluminum cabin of Flight Eight-Fifteen hisses with gray smoke on a white coral sandbar.

`0:12` > **YOU:** Three meters away, the girl you spent all semester rehearsing a single hello for sits up in the foam.

`0:18` > **CRUSH:** Please tell me this is a layover.

`0:19` You scan three hundred sixty degrees of empty turquoise horizon and swallow hard.

`0:24` > **YOU:** Not a single boat.

`0:25` > **YOU:** So, what if you

`0:27` > **YOU:** and your crush were stranded on an island alone?

`0:30` > **YOU:** Forget movie montages.

`0:31` Here is how ocean physics and human biology actually play out.

`0:34` > **YOU:** When the tail section sheared off in a microburst,

`0:37` the forward slide rafts drifted twelve kilometers upwind.

`0:41` > **YOU:** What changes immediately is every social filter you had in school.

`0:45` > **YOU:** Popularity, grades, and Wi-Fi are gone.

`0:47` > **YOU:** What stays brutally normal is your body's water clock

`0:50` and the geometry of the Pacific Ocean.

`0:53` > **YOU:** File that ocean geometry away in your back pocket.

`0:55` > **YOU:** In four days, your lives depend on it.

`0:58` Here is a fact that sounds made up.

`1:00` > **YOU:** Even when air traffic control knows your route, ocean search grids explode.

`1:05` > **YOU:** A jet gliding off radar for twenty minutes creates a search circle of forty-five thousand square kilometers.

`1:11` > **YOU:** A rescue plane flying at three hundred meters can only scan a two-kilometer corridor on each pass.

`1:17` > **YOU:** Spotting two teens on a three-hundred-meter sandbar inside

`1:20` > **YOU:** that circle is like finding two ants across ten thousand football fields.

`1:24` > **FEMALE:** Stop doing math. You're making it worse.

`1:27` > **YOU:** You promise to stop calculating odds right

`1:29` > **YOU:** after you check the clock that actually matters.

`1:32` > **YOU:** Now, the strange part.

`1:34` > **YOU:** Starvation is not the enemy that hunts castaways on a tropical atoll.

`1:38` > **YOU:** Wilderness medics live by the Rule of Threes: three minutes without air, three days without water, three weeks without food.

`1:45` At thirty-two degrees Celsius,

`1:46` two people lose four liters of water a day just sweating and breathing.

`1:50` > **YOU:** You are surrounded by quadrillions of liters of water,

`1:53` > **YOU:** yet a single gulp of seawater accelerates dehydration.

`1:56` > **YOU:** Seawater contains thirty-five grams of salt per liter, while human kidneys max out at twenty grams per liter.

`2:03` > **YOU:** To flush the extra fifteen grams of salt,

`2:05` your kidneys pull half a liter of water out of your own cells.

`2:09` > **CRUSH:** So the ocean is basically liquid sandpaper.

`2:11` That means you have exactly seventy-two hours.

`2:14` > **YOU:** Before the tide rises, you both strip the fuselage for salvage.

`2:18` > **YOU:** First, you pry loose a curved aluminum leading-edge wing slat polished to a mirror finish by wind friction.

`2:24` > **YOU:** A flat pocket mirror scatters light after three kilometers, but a curved wing slat focuses a flash visible thirty-seven kilometers out.

`2:32` Second, you pull your dead smartphone from your pocket.

`2:35` > **YOU:** The screen is cracked, but its sealed lithium-ion pouch holds fifteen watt-hours.

`2:40` Third, she carefully smooths out her pink Seat Fourteen-B boarding pass

`2:44` and zips it inside her dry collar pocket.

`2:47` > **CRUSH:** Don't ask. It's my lucky ticket.

`2:49` > **YOU:** Fourth, wedged beneath the cockpit floor bulkhead,

`2:52` > **YOU:** you find a locked brushed-titanium case with a blinking red biometric sensor.

`2:56` > **YOU:** It has no passenger name tag, weighs nine kilograms, and is hermetically sealed.

`3:01` > **YOU:** You haul it up to dry sand.

`3:03` As afternoon heat hits the lagoon, you test your gear

`3:06` > **YOU:** and lock in three island physics rules.

`3:08` > **YOU:** Rule one: green palm fronds boil sap into thick white smoke. Rule two: a four-to-one driftwood lever multiplies lifting force by four.

`3:17` > **YOU:** You prove Rule Two by resting a two-point-four-meter ironwood spar over a basalt rock to lift a heavy seat frame effortlessly.

`3:24` > **YOU:** Then you test Rule Three: tilting the concave wing slat toward the sun focuses a pinpoint beam

`3:30` > **YOU:** that chars dry bark at four hundred ten degrees.

`3:33` You lash three driftwood branches into an aiming tripod beside the fire ring

`3:37` so the wing slat can sweep the horizon.

`3:39` > **YOU:** With the science sorted, your teen brain switches to its second priority:

`3:43` > **YOU:** looking cool in front of your crush.

`3:46` > **YOU:** You pick up a fallen coconut, tell her to stand back,

`3:49` > **YOU:** and attempt a movie-style karate chop.

`3:51` > **YOU:** Your hand slams into the fibrous shell

`3:53` and bounces straight off with a hollow thud.

`3:56` > **YOU:** Mature coconut shells resist twenty megapascals of pressure,

`3:59` roughly the same as red paving brick.

`4:01` > **YOU:** The nut doesn't even scratch.

`4:03` > **CRUSH:** Coconut one, action hero zero.

`4:06` > **YOU:** While you shake out your bruised fingers,

`4:08` > **YOU:** she wedges a pointed basalt stone upright in the sand.

`4:11` Using leverage instead of ego, she spears the husk onto the stone point

`4:15` and twists it open in four seconds.

`4:17` > **YOU:** Each green coconut yields four hundred milliliters of sterile electrolyte water rich in potassium.

`4:23` > **YOU:** She lets you have the first sip.

`4:25` > **YOU:** On Day Two, determined to redeem your pride,

`4:28` > **YOU:** you fire-harden a bamboo pole into a four-pronged fishing spear.

`4:31` > **YOU:** Knee-deep in the crystal reef,

`4:33` you spot a fat blue parrotfish hovering motionless beside a coral head.

`4:37` > **YOU:** You lunge dead-center at its back,

`4:39` > **YOU:** miss by thirty centimeters, and belly-flop into the salt lagoon.

`4:43` > **CRUSH:** Did you just tackle the ocean?

`4:45` > **YOU:** Light slows down in water at a refractive index of one point three three, bending the image upward toward the surface.

`4:52` > **YOU:** Because your brain assumes light travels in straight lines,

`4:55` every underwater target sits deeper and closer than it looks.

`4:58` > **CRUSH:** Aim below the belly, Einstein.

`5:00` > **YOU:** You aim a hand's width under the hologram, strike true,

`5:04` and hold up lunch while she gives you a slow clap.

`5:07` > **YOU:** On Day Three, you haul split bamboo poles to the dry dune ridge to build an A-frame shelter.

`5:12` > **YOU:** Your first vine lashing snaps,

`5:14` > **YOU:** dropping twenty kilograms of wet palm thatch straight over your head like a green wig.

`5:19` She steps in, ties square knots using braided hibiscus bark cordage,

`5:23` > **YOU:** and locks the ridgepole rock-solid.

`5:25` There is only one small catch:

`5:26` > **YOU:** the triangular floor frame is just wide enough for a single leaf mattress.

`5:31` > **YOU:** Coconut water won't last forever,

`5:33` > **YOU:** so you dig three conical pits one meter wide in the damp sand above the tideline.

`5:38` > **YOU:** You pack crushed green shoreline plants around a central cup,

`5:41` cover the pit with clear cabin plastic, and center a pebble.

`5:45` > **YOU:** Greenhouse heat evaporates pure water out of the damp sand and leaves the salt behind, dripping eight hundred milliliters per pit.

`5:52` > **YOU:** Three solar stills produce two point four liters of distilled water every day.

`5:56` > **YOU:** Combined with coconuts, you beat the dehydration clock.

`6:00` > **YOU:** By Night Four, the solar-ignited driftwood fire crackles warmly

`6:03` > **YOU:** under a sky of five thousand Bortle-One stars.

`6:06` > **FEMALE:** I was in row six. I paid fifty bucks to sit by you.

`6:10` > **CRUSH:** Best fifty dollars I ever spent.

`6:12` > **YOU:** Sitting shoulder to shoulder by the surf,

`6:14` > **YOU:** part of you secretly hopes the rescue ship takes another week.

`6:18` No cargo freighter or cruise liner will ever pass within visual range of this reef by chance.

`6:23` > **YOU:** And then you see the real problem rising on the western horizon:

`6:27` > **YOU:** a rotating black wall of cumulonimbus clouds.

`6:30` A Category Four cyclone is spinning toward the atoll at two hundred twenty kilometers per hour, twelve hours away.

`6:36` > **YOU:** The barometer in the cockpit altimeter drops twenty-four millibars.

`6:40` > **YOU:** A two-meter storm surge is coming right over a one-point-two-meter beach.

`6:44` > **CRUSH:** The whole beach is going underwater.

`6:46` > **YOU:** Raw strength cannot fight a cyclone,

`6:48` > **YOU:** and shouting cannot cross thirty-seven kilometers of ocean.

`6:51` > **YOU:** Your survival rule is simple: don't fight the ocean with muscle. Chain the physics: leverage, thermal spark, steam smoke, parabolic flash.

`7:00` You seal dry coconut tinder and the foil wrapper around the lithium battery,

`7:05` > **YOU:** and anchor the aiming tripod with heavy basalt rocks.

`7:08` Six hours early, the cyclone's outer squall line slams

`7:11` > **YOU:** into the lagoon with horizontal rain and roaring surf.

`7:14` > **YOU:** Then, through a narrow break in the storm clouds,

`7:17` > **YOU:** a twin-engine Coast Guard search plane banks thirty-seven kilometers out!

`7:21` > **YOU:** Flying its last pre-storm grid at two hundred forty knots, that plane will cross your horizon in one hundred eighty seconds.

`7:28` You both sprint toward the wreck to grab the wing slat,

`7:30` > **YOU:** when a king-tide wave rolls the fuselage tail section!

`7:33` > **YOU:** A one-hundred-eighty-kilogram aluminum structural beam drops across her boot,

`7:38` > **YOU:** pinning her ankle in the rising surf!

`7:40` > **CRUSH:** It's pinned! Leave me, flash the plane!

`7:43` > **YOU:** You grip the wet aluminum beam

`7:45` > **YOU:** and deadlift with every muscle in your back.

`7:47` One hundred eighty kilograms in suction sand does not move.

`7:51` > **YOU:** Here is the brutal math: the surge rises ten centimeters a minute.

`7:55` > **YOU:** In two minutes the water reaches her chin,

`7:57` and in two minutes the plane is gone.

`8:00` > **YOU:** The plane...

`8:01` > **YOU:** or her life.

`8:01` > **YOU:** You refuse the choice and execute the theme rule.

`8:04` Step one: Archimedes and the four-to-one driftwood lever!

`8:07` > **YOU:** You jam the two-point-four-meter ironwood spar under the beam

`8:11` > **YOU:** and roll a basalt boulder forty centimeters from the load as a fulcrum.

`8:15` > **YOU:** Throwing forty-five kilograms onto the long arm multiplies

`8:18` > **YOU:** into one hundred eighty kilograms of upward torque.

`8:21` > **YOU:** The beam lifts and she slides free!

`8:23` > **YOU:** Fifty-two seconds left!

`8:25` You half-carry her to the fire ring, pull out the foil pretzel wrapper,

`8:29` > **YOU:** and bridge the lithium phone battery leads!

`8:32` > **YOU:** Fifteen watt-hours discharge through the foil ribbon at four hundred ten degrees Celsius,

`8:37` > **YOU:** bursting the dry coconut husk core into roaring flame!

`8:40` She heaps wet green palm fronds onto the core,

`8:43` > **YOU:** boiling the sap into a towering white smoke column against the dark storm wall!

`8:48` > **YOU:** Sixteen seconds!

`8:49` The plane is already banking away,

`8:51` > **YOU:** so you lock the concave aluminum wing slat onto the driftwood tripod sight!

`8:55` > **YOU:** Catching a red ray of sunset beneath the cloud deck,

`8:58` you sweep the thirty-seven-kilometer beam across the cockpit.

`9:02` > **YOU:** Flash one.

`9:03` > **YOU:** Flash two.

`9:04` > **YOU:** Flash three!

`9:04` A surge wave sweeps your melted phone shell

`9:07` > **YOU:** and the last foil pretzel wrapper out to sea as the plane rocks its wings and drops a green flare.

`9:12` The pretzel bag did not make it.

`9:14` > **YOU:** You climb together onto the forty-meter basalt ridge above the storm surge,

`9:18` > **YOU:** where a rescue helicopter touches down at dawn.

`9:21` > **YOU:** By noon, the cockpit camera clip hits four million views under an ironic headline:

`9:26` > **YOU:** Teen Signals Coast Guard With A Dead Phone And A Broken Wing.

`9:30` > **FEMALE:** Next time, we're taking a train.

`9:32` > **YOU:** You don't need a rehearsed hallway line anymore.

`9:35` > **YOU:** You just laugh, take her hand, and walk toward the open cabin door.

`9:39` > **YOU:** Then, as you lift the salvaged nine-kilogram titanium case onto the helicopter skid,

`9:43` the flight commander freezes cold.

`9:46` > **HERO:** Control, Asset Fourteen-B and the cargo survived.

`9:49` > **YOU:** You look down at the titanium case's biometric plate.

`9:52` Laser-etched beside the red light is her exact seat number: Fourteen-B.

`9:56` > **YOU:** And on the sheared fuselage latch behind you,

`9:59` > **YOU:** the bolts weren't torn by wind.

`10:00` They were blown outward before takeoff.

`10:03` > **YOU:** The crash was never an accident.

`10:05` > **YOU:** So what is the first survival hack you would build if you were stranded on that island?

`10:10` And when that pilot reaches for the Fourteen-B case,

`10:13` > **YOU:** do you board the helicopter or run back into the jungle?

`10:16` > **YOU:** Tell us in the comments.

`10:18` > **YOU:** See you in the next what-if.
