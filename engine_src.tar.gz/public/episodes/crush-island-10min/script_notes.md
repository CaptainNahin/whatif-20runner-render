# Script Notes — What If You And Your Crush Were Stranded On An Island Alone? (`crush-island-10min`)

## 1. Premise Formula (`docs/story/STORY_BLUEPRINT.md` §3)
- **Title**: What If You And Your Crush Were Stranded On An Island Alone?
- **Target Runtime**: 10:00–10:20 (600–620s) @ 30 FPS (`~185` dynamic shots, `1859` spoken words @ ~176–180 WPM)
- **Perspective**: Strict 2nd-person (`"you"`, `"your"`), rendered with the classic Steve 3D voxel rig (never speaking `"Steve"` out loud) and Alex/Ari female 3D voxel rig for your crush.
- **What Changes**: A charter flight ditches in the South Pacific, leaving only you and your crush on an uninhabited 2 km volcanic coral atoll with zero cell towers and a dead emergency beacon.
- **What Stays the Same (The Planted Limit)**: Human kidney osmosis (2% salt cap vs 3.5% seawater), the 72-hour dehydration clock, and line-of-sight visual physics across 165 million km² of ocean.
- **Want vs Need**:
  - *External Want*: Impress your crush with flashy movie-hero stunts and get rescued fast.
  - *Internal Need*: Drop the ego, listen to her sharp observations, and combine real physics + teamwork to survive when brute force fails.

## 2. Plant & Payoff Ledger (8 Plants -> 7 Payoffs + 1 Sequel Hook)

| # | Plant (Setup & Act 1/2 Timestamp) | How It's Flagged | Payoff (Act 3/4 Timestamp) | Type |
|---|---|---|---|---|
| 1 | **Torn Seat 14B Boarding Pass** (0:05 Cold Open) | Found in your pocket on the surf | Night 4 campfire: she confesses she traded with your friend to sit in 14B next to you; Act 4: stamped `PROJECT HALCYON — TWO SUBJECTS` | Emotional + Mystery Loop |
| 2 | **Concave Aluminum Wing Slat** (1:55 Act 1) | Parabolic curve concentrates sunlight to 410°C & 37 km flash vs 3 km flat mirror | Act 3 Climax (8:05): Mounted on the driftwood tripod to strobe the rescue aircraft cockpit 37 km away | Physics Climax #4 |
| 3 | **Dead Smartphone Lithium-Ion Battery + Foil** (2:15 Act 1) | Sealed in a waterproof pouch; holds 3.0V reserve chemical charge | Act 3 Climax (7:25): Short-circuited with metallic snack foil to ignite coconut coir at 410°C after rain drowns the campfire | Physics Climax #2 |
| 4 | **Locked Titanium Cargo Case** (2:30 Act 1) | Heavy biometric vault with severed beacon wire pulled from cockpit | Act 4 Twist (9:15): Rescue pilot demands the case before checking your pulse, revealing the crash was a staged test | Sequel Open Loop |
| 5 | **Driftwood Gimbal Tripod & Dual-Notch Sight** (4:10 Act 2) | Lashed by the camp to aim a solar reflector without shaking | Act 3 Climax (8:00): Locks the wing slat onto the plane's windshield in 90 km/h gale gusts | Physics Climax #4 |
| 6 | **Dense Ironwood Pole & Basalt Wedge** (2:55 & 3:25 Act 2) | Used after your karate-chop coconut fail & Snell's-law spearfishing | Act 3 Climax (6:55): Used as a 5:1 Class-1 lever to lift a 200 kg fuselage beam off her trapped ankle before the surge hits | Physics Climax #1 |
| 7 | **Green Palm Fronds & Dry Coconut Coir Cache** (3:55 Act 2) | Saved from shelter roof thatching | Act 3 Climax (7:45): Heaped over the 410°C core fire to generate a 60 m white steam plume against black storm clouds | Physics Climax #3 |
| 8 | **Crushed Salted Pretzel Bag** (4:35 Act 2) | Shared as a gourmet 5-star dinner at the Night 4 campfire | Foil wrapper becomes the low-resistance bridge for the lithium battery ignition | Running Gag + Climax Tool |

## 3. Verified Science & Survival Fact Sheet
1. **Pacific Ocean Area**: `165,250,000 km²` — larger than all Earth's continents combined (`148,940,000 km²`).
2. **Rule of Threes**: `3 minutes` without air, `3 days` (`72 hours`) without water in tropical heat (`0.6 L/hr` sweat loss), `3 weeks` without food.
3. **Seawater Kidney Osmosis**: Seawater is `3.5%` dissolved NaCl (`35 g/L`); human kidneys max out at `~2.0%` urine salinity, requiring `1.5 L` of body water to excrete every `1.0 L` of seawater drunk.
4. **Snell's Law Water Refraction**: $n_{\text{water}} = 1.333$ vs $n_{\text{air}} = 1.000$, making submerged reef fish appear ~25% shallower and farther forward than their true position.
5. **Solar Still Distillation**: Black flight-case liner absorbs solar IR (`>65°C`), evaporating pure water vapor that condenses on cooler clear plastic at `~1.6 L/day` (`400 mL` per pit × 4 pits).
6. **Parabolic Signal Reflection**: A slightly concave polished aluminum wing skin keeps beam divergence narrow enough to deliver a visible flash at `37 km` (`20+ miles`), compared to `~3 km` for a flat hand mirror.
7. **Class-1 Lever Mechanical Advantage**: With a basalt fulcrum `0.4 m` from the `200 kg` load and `2.0 m` of effort arm ($MA = 5$), `45 kg` of downward push generates `225 kg` of lift force.

## 4. 28-Beat Structural Outline (4 Acts)
- **Act 1 (0:00–2:35 | Shots 1–46)**: Cold Open in the surf -> Title Question at 0:25 -> Pacific Search Math Card -> Rule of Threes Stopwatch -> Kidney Osmosis Compare Card -> Salvaging the 4 Survival Plants (Wing Slat, Lithium Phone + Foil, Seat 14B Pass, Titanium Case).
- **Act 2 (2:35–5:35 | Shots 47–112)**: Day 1 Coconut Karate Fail vs Basalt Wedge -> Day 2 Snell's Law Spearfishing -> Day 3 Crooked One-Bed Shelter & Driftwood Tripod -> Day 4 Solar Distillation Pits (`1.6 L/day`) -> Night 4 Campfire High Point & Seat 14B Confession -> Day 5 Ridge Climb & The Real Problem (`400 km` off-lane + Cat-4 Cyclone in `12 hours`).
- **Act 3 (5:35–8:40 | Shots 113–166)**: Barometric Drop & Storm Surge -> Shelter Washed Away & Campfire Drowned -> Rescue Plane at `37 km` (`180s` window) -> Crush's Ankle Pinned by 200 kg Beam in Rising Tide -> 4-Step Physics Cash-In (5:1 Ironwood Lever -> Lithium-Foil 410°C Spark -> Green Frond White Smoke Plume -> Tripod Parabolic 37 km Strobe).
- **Act 4 (8:40–10:15 | Shots 167–185)**: Rescue Helicopter Lands on Ridge -> Pilot Demands Titanium Case First -> `PROJECT HALCYON — TWO SUBJECTS` Twist -> Two-Question Comment CTA.

## 5. Blueprint Rubric Score (`docs/story/STORY_BLUEPRINT.md` §10)
- Hook & Title Timing: **10/10** (Cold open action at 0:00, exact title at 0:25)
- Science & Number Density: **19/20** (7 verified physics/biology mechanisms, 3 data cards + HUD stats)
- Try/Fail Escalation & Humor: **19/20** (3 distinct try/fail loops + character quips every ~22s)
- Plant/Payoff Discipline: **20/20** (8 plants, 7 cashed in sequence during climax, 1 sequel hook)
- Midpoint Turn & Emotional Core: **14/15** (Night 4 Seat 14B confession -> Day 5 Ridge cyclone turn)
- Ending & CTA: **14/15** (Project Halcyon twist + 2-question comment hook)
- **TOTAL SCORE**: **96 / 100** (Passes ≥ 80 gate)
