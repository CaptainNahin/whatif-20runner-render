// Bespoke 3D Toy-Like Island World, Round-Faced Capsule Cast & 12 Animated Survival Props for EDStudio
// Built on EDStudio's native engine/build/island.js, engine/rig.js, engine/props.js, engine/build/fx.js, and engine/oxygen.js.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { clamp, lerp, smooth, mat, mk, canvasTex, rng, walkLegs, faceToward } from '@engine/core.js';
import { makePerson, basePose, applyPose, handWorld, blink } from '@engine/rig.js';
import { makeSpeechBubble } from '@engine/props.js';
import { buildIsland, groundY } from '@engine/build/island.js';
import { makeFX } from '@engine/build/fx.js';
import { makeFlames } from '@engine/oxygen.js';

const PI = Math.PI, TAU = PI * 2;

export const ZONES = {
  crash: [14, 33],
  reef:  [-20, 29],
  camp:  [-3, 21],
  storm: [18, 31],
  ridge: [5, -24],
};

export function zoneAt(zone, dx = 0, dz = 0, dy = 0) {
  const b = ZONES[zone] || ZONES.crash;
  const x = b[0] + dx, z = b[1] + dz;
  const y = zone === 'reef' ? -0.35 + dy : groundY(x, z) + dy;
  return [x, y, z];
}

// Enhance EDStudio's round-faced toy-like capsule rig with extra expressive mouths, brows, blush, and glossy finish
export function makeToyCharacter(opts = {}) {
  const P = makePerson({
    skin: opts.skin ?? 0xf2c29a,
    top: opts.top ?? 0x1e88a8,
    collar: opts.collar ?? 0xf3e9dc,
    pants: opts.pants ?? 0x253552,
    shoes: opts.shoes ?? 0x2c221e,
    hair: opts.hair ?? 0x3a2618,
    hairStyle: opts.hairStyle ?? 'messy',
    headR: opts.headR ?? 0.162,
    glasses: opts.glasses ?? false,
  });
  // Make skin & capsule clothes slightly glossier for the signature toy-like diorama look
  P.mats.skin.roughness = 0.46;
  P.mats.faceSkin.roughness = 0.46;
  P.mats.top.roughness = 0.65;
  P.mats.pants.roughness = 0.68;

  const r = opts.headR ?? 0.162;
  const hg = P.head.g;
  // Add big expressive grin mouth + scream mouth + sweat drop on the round head
  const grinM = mat(0xffffff, 0.3);
  const grin = mk(new RoundedBoxGeometry(r * 0.34, r * 0.13, r * 0.06, 2, r * 0.03), grinM, hg, 0, -r * 0.36, r * 0.88);
  grin.visible = false;
  const scream = mk(new THREE.SphereGeometry(r * 0.15, 16, 12), mat(0x3a1210, 0.5), hg, 0, -r * 0.38, r * 0.86);
  scream.scale.set(0.95, 1.35, 0.55);
  scream.visible = false;
  const sweat = mk(new THREE.SphereGeometry(r * 0.065, 10, 8), new THREE.MeshStandardMaterial({ color: 0x7fd4ff, emissive: 0x3aa6ff, emissiveIntensity: 0.6, roughness: 0.15 }), hg, r * 0.68, r * 0.25, r * 0.65);
  sweat.scale.set(0.7, 1.4, 0.7);
  sweat.visible = false;

  // Optional ponytail / long hair back for female survivor
  if (opts.ponytail) {
    const pt = mk(new THREE.CapsuleGeometry(r * 0.24, r * 0.48, 6, 12), P.mats.hair, hg, 0, -r * 0.18, -r * 0.95);
    pt.rotation.x = 0.45;
  }
  // Optional pilot helmet visor
  if (opts.helmet) {
    const hm = mat(0x2e3d30, 0.4, { metalness: 0.3 });
    const dome = mk(new THREE.SphereGeometry(r * 1.13, 28, 16, 0, TAU, 0, PI * 0.62), hm, hg, 0, r * 0.04, -r * 0.04);
    dome.rotation.x = -0.18;
    const visor = mk(new THREE.SphereGeometry(r * 1.15, 24, 12, 0.35, PI - 0.7, PI * 0.24, PI * 0.26), new THREE.MeshStandardMaterial({ color: 0x11161d, roughness: 0.12, metalness: 0.85 }), hg, 0, r * 0.05, 0.02);
    visor.rotation.y = -PI / 2;
  }

  P.extraFace = { grin, scream, sweat, r };
  return P;
}

export function poseToyCharacter(P, pose, extra = {}) {
  applyPose(P, pose);
  const ef = P.extraFace;
  if (!ef) return;
  const m = extra.mouth || pose.mouth || (pose.smile > 0.5 ? 'smile' : 'flat');
  P.head.smile.visible = m === 'smile';
  P.head.flat.visible = m === 'flat';
  P.head.oMouth.visible = m === 'o';
  ef.grin.visible = m === 'grin';
  ef.scream.visible = m === 'scream';
  ef.sweat.visible = !!extra.sweat;
  const browTilt = extra.brows ?? 0; // -1 angry/determined, +1 worried/surprised
  P.head.brows.forEach((b, i) => {
    const s = i === 0 ? -1 : 1;
    b.rotation.z = s * (-0.14 + browTilt * 0.38);
    b.position.y = ef.r * (0.34 + Math.abs(browTilt) * 0.05);
  });
  const eyeScale = extra.wideEyes ? 1.28 : 1.0;
  P.head.eyesOpen.scale.set(1, eyeScale, 1);
}

// ------------------------------------------------------------------ 12 BESPOKE 3D PROPS
export function makeBoardingPass14B() {
  const g = new THREE.Group();
  const tex = canvasTex(512, 256, (c, w, h) => {
    c.fillStyle = '#ffd6e4'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#d81b60'; c.fillRect(0, 0, 110, h);
    c.fillStyle = '#ffffff'; c.font = 'bold 42px Inter, Arial'; c.textAlign = 'center';
    c.fillText('815', 55, 85); c.font = 'bold 28px Inter, Arial'; c.fillText('PACIFIC', 55, 135);
    c.fillStyle = '#1a1a2e'; c.font = 'bold 44px Inter, Arial'; c.textAlign = 'left';
    c.fillText('BOARDING PASS', 130, 64);
    c.fillStyle = '#d81b60'; c.font = '900 84px Inter, Arial';
    c.fillText('SEAT 14B', 130, 160);
    c.fillStyle = '#333'; c.font = 'bold 26px monospace';
    c.fillText('FLT 815 · GATE C4 · ZONE 1', 130, 215);
  });
  const card = mk(new THREE.BoxGeometry(0.26, 0.008, 0.14), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.4 }), g);
  return { g, card };
}

export function makeWingSlat() {
  const g = new THREE.Group();
  const chrome = new THREE.MeshStandardMaterial({ color: 0xe8f1f8, roughness: 0.08, metalness: 0.92, side: THREE.DoubleSide });
  const panel = mk(new THREE.CylinderGeometry(0.45, 0.45, 0.95, 24, 1, true, -0.55, 1.1), chrome, g);
  panel.rotation.z = PI / 2;
  // Volumetric sunbeam cone
  const coneGeo = new THREE.ConeGeometry(1.8, 22, 24, 1, true);
  coneGeo.translate(0, -11, 0); coneGeo.rotateX(-PI / 2);
  const coneMat = new THREE.MeshBasicMaterial({ color: 0xfff3a8, transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending });
  const beam = new THREE.Mesh(coneGeo, coneMat);
  beam.position.set(0, 0, 0.15);
  g.add(beam);
  const setBeam = (op) => { coneMat.opacity = clamp(op) * 0.42; beam.visible = op > 0.01; };
  setBeam(0);
  return { g, panel, beam, setBeam };
}

export function makeCrackedPhone() {
  const g = new THREE.Group();
  mk(new RoundedBoxGeometry(0.11, 0.014, 0.21, 2, 0.01), mat(0x1b1e26, 0.3, { metalness: 0.5 }), g);
  const scrTex = canvasTex(256, 512, (c, w, h) => {
    c.fillStyle = '#0d111a'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#ff3b30'; c.font = 'bold 48px Inter, Arial'; c.textAlign = 'center';
    c.fillText('1% BATTERY', w / 2, h / 2 - 30);
    c.fillStyle = '#ffd43b'; c.font = 'bold 34px Inter, Arial';
    c.fillText('15 Wh Li-Ion', w / 2, h / 2 + 30);
    c.strokeStyle = 'rgba(255,255,255,0.75)'; c.lineWidth = 4;
    for (const [x1, y1, x2, y2] of [[20, 40, 220, 390], [220, 100, 30, 440], [110, 210, 250, 260], [110, 210, 15, 190]]) {
      c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
    }
  });
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.096, 0.19), new THREE.MeshBasicMaterial({ map: scrTex }));
  scr.rotation.x = -PI / 2; scr.position.y = 0.008; g.add(scr);
  return { g };
}

export function makeTitaniumCase() {
  const g = new THREE.Group();
  const ti = new THREE.MeshStandardMaterial({ color: 0x9aa5b4, roughness: 0.25, metalness: 0.85 });
  const dark = mat(0x222730, 0.5);
  mk(new RoundedBoxGeometry(0.58, 0.22, 0.42, 3, 0.025), ti, g, 0, 0.11, 0);
  // Corner bumpers + latches
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    mk(new THREE.BoxGeometry(0.08, 0.23, 0.08), dark, g, sx * 0.26, 0.11, sz * 0.18);
  }
  const plateTex = canvasTex(512, 256, (c, w, h) => {
    c.fillStyle = '#252a34'; c.fillRect(0, 0, w, h);
    c.strokeStyle = '#ff3b30'; c.lineWidth = 8; c.strokeRect(10, 10, w - 20, h - 20);
    c.fillStyle = '#e2e8f0'; c.font = 'bold 34px monospace'; c.textAlign = 'center';
    c.fillText('BIOMETRIC CLASSIFIED CARGO', w / 2, 70);
    c.fillStyle = '#ffd43b'; c.font = '900 72px monospace';
    c.fillText('ASSET: 14B', w / 2, 165);
    c.fillStyle = '#94a3b8'; c.font = 'bold 28px monospace';
    c.fillText('MASS: 9.0 KG · HERMETIC SEAL', w / 2, 220);
  });
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.38, 0.19), new THREE.MeshBasicMaterial({ map: plateTex }));
  plate.rotation.x = -PI / 2; plate.position.set(0, 0.222, 0.02); g.add(plate);
  const ledMat = new THREE.MeshBasicMaterial({ color: 0xff1e1e });
  const led = new THREE.Mesh(new THREE.SphereGeometry(0.024, 12, 10), ledMat);
  led.position.set(0.21, 0.225, -0.12); g.add(led);
  const update = (t) => {
    const blinkOn = Math.sin(t * 7.5) > -0.2;
    ledMat.color.setHex(blinkOn ? 0xff2222 : 0x440505);
  };
  return { g, led, update };
}

export function makeCoconutProp(split = false) {
  const g = new THREE.Group();
  const huskM = mat(0x5cb84a, 0.75), brownM = mat(0x5c3c24, 0.85), whiteM = mat(0xfaf6f0, 0.5), waterM = new THREE.MeshStandardMaterial({ color: 0xa8e6ff, roughness: 0.15, transparent: true, opacity: 0.8 });
  if (!split) {
    const nut = mk(new THREE.SphereGeometry(0.14, 20, 16), huskM, g, 0, 0.14, 0);
    nut.scale.set(1, 1.15, 0.95);
  } else {
    for (const s of [-1, 1]) {
      const half = new THREE.Group(); half.position.set(s * 0.13, 0.09, 0); half.rotation.z = s * 0.35; g.add(half);
      mk(new THREE.SphereGeometry(0.13, 18, 12, 0, TAU, PI * 0.45, PI * 0.55), huskM, half);
      mk(new THREE.SphereGeometry(0.11, 18, 12, 0, TAU, PI * 0.45, PI * 0.55), whiteM, half);
      const w = new THREE.Mesh(new THREE.CircleGeometry(0.105, 18), waterM); w.rotation.x = -PI / 2; half.add(w);
    }
  }
  return { g };
}

export function makeBambooSpear() {
  const g = new THREE.Group();
  const bamM = mat(0xc8a951, 0.65), charM = mat(0x2c1d14, 0.8);
  mk(new THREE.CylinderGeometry(0.022, 0.025, 1.75, 10), bamM, g, 0, 0.875, 0);
  // Bamboo nodes
  for (const y of [0.3, 0.65, 1.0, 1.35]) mk(new THREE.TorusGeometry(0.025, 0.005, 6, 12), bamM, g, 0, y, 0).rotation.x = PI / 2;
  // 4 fire-hardened prongs at top
  for (const [dx, dz] of [[-0.02, -0.02], [0.02, -0.02], [-0.02, 0.02], [0.02, 0.02]]) {
    const p = mk(new THREE.ConeGeometry(0.012, 0.24, 6), charM, g, dx, 1.84, dz);
    p.rotation.z = -dx * 2.5; p.rotation.x = dz * 2.5;
  }
  return { g };
}

export function makeParrotfish(isGhost = false) {
  const g = new THREE.Group();
  const bodyM = isGhost
    ? new THREE.MeshBasicMaterial({ color: 0x48f5ff, wireframe: true, transparent: true, opacity: 0.62 })
    : new THREE.MeshStandardMaterial({ color: 0x1aa3e8, roughness: 0.35, metalness: 0.1 });
  const accentM = isGhost ? bodyM : mat(0xffc93c, 0.4);
  const body = mk(new THREE.SphereGeometry(0.22, 20, 14), bodyM, g);
  body.scale.set(1.55, 0.85, 0.55);
  const tail = mk(new THREE.ConeGeometry(0.16, 0.24, 4), accentM, g, -0.38, 0, 0);
  tail.rotation.z = -PI / 2; tail.scale.set(1, 1, 0.35);
  if (!isGhost) {
    for (const sz of [-1, 1]) {
      mk(new THREE.SphereGeometry(0.032, 10, 8), mat(0xffffff, 0.2), g, 0.22, 0.05, sz * 0.1);
      mk(new THREE.SphereGeometry(0.016, 8, 6), mat(0x111111, 0.2), g, 0.24, 0.05, sz * 0.115);
    }
  }
  const update = (t) => {
    tail.rotation.y = Math.sin(t * 9) * 0.35;
  };
  return { g, update };
}

export function makePalmThatchWig() {
  const g = new THREE.Group();
  const leafM = mat(0x3b9e3a, 0.8, { side: THREE.DoubleSide });
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    const frond = mk(new THREE.ConeGeometry(0.14, 0.62, 5), leafM, g, Math.cos(a) * 0.16, -0.08, Math.sin(a) * 0.16);
    frond.rotation.x = PI * 0.65;
    frond.rotation.y = -a;
  }
  return { g };
}

export function makeBatterySparkFoil() {
  const g = new THREE.Group();
  const pouch = mk(new RoundedBoxGeometry(0.12, 0.02, 0.18, 2, 0.005), mat(0x2a303c, 0.4, { metalness: 0.7 }), g, 0, 0.01, 0);
  const foil = mk(new THREE.TorusGeometry(0.08, 0.012, 6, 18, PI), new THREE.MeshStandardMaterial({ color: 0xe6eef8, roughness: 0.1, metalness: 0.95 }), g, 0, 0.02, 0.08);
  const glow = new THREE.Mesh(new THREE.SphereGeometry(0.09, 14, 10), new THREE.MeshBasicMaterial({ color: 0xffe066, transparent: true, opacity: 0.85 }));
  glow.position.set(0, 0.05, 0.12); g.add(glow);
  return { g, pouch, foil, glow };
}

// ------------------------------------------------------------------ 5 BESPOKE ISLAND DIORAMA ZONES
function buildFuselageWreck(root) {
  const g = new THREE.Group();
  const [cx, cz] = ZONES.crash, cy = groundY(cx, cz);
  g.position.set(cx, cy, cz);
  g.rotation.y = -0.38;
  root.add(g);

  const alum = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.32, metalness: 0.62, side: THREE.DoubleSide });
  const blueStripe = mat(0x1d4ed8, 0.4);
  const darkMetal = mat(0x334155, 0.7, { metalness: 0.5 });

  // Half-submerged torn cabin cylinder
  const hull = mk(new THREE.CylinderGeometry(2.1, 2.1, 7.8, 28, 1, true, -PI * 0.78, PI * 1.56), alum, g, 0, 1.35, -3.2);
  hull.rotation.z = PI / 2 + 0.12;
  hull.rotation.x = 0.08;

  // Airline blue stripe + FLT 815 lettering
  const signT = canvasTex(1024, 256, (c, w, h) => {
    c.fillStyle = '#e2e8f0'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#1e40af'; c.fillRect(0, 24, w, 68);
    c.fillStyle = '#dc2626'; c.fillRect(0, 96, w, 18);
    c.fillStyle = '#0f172a'; c.font = '900 84px Inter, Arial'; c.textAlign = 'center';
    c.fillText('PACIFIC AIR · FLIGHT 815', w / 2, 200);
  });
  const sidePanel = mk(new THREE.PlaneGeometry(5.6, 1.35), new THREE.MeshStandardMaterial({ map: signT, roughness: 0.4 }), g, -0.2, 1.55, -1.12);
  sidePanel.rotation.z = 0.12;

  // Oval cabin windows
  for (let i = -3; i <= 3; i++) {
    mk(new THREE.CylinderGeometry(0.18, 0.18, 0.08, 16), darkMetal, g, i * 0.72, 1.82 - i * 0.08, -1.08).rotation.x = PI / 2;
  }

  // Torn wing stub + scattered luggage suitcases on the sandbar
  const wing = mk(new THREE.BoxGeometry(3.4, 0.16, 4.8), alum, g, -1.8, 0.55, -0.5);
  wing.rotation.set(0.18, 0.25, -0.15);
  const suitColors = [0xd946ef, 0xeab308, 0x0ea5e9, 0xef4444];
  for (let i = 0; i < 4; i++) {
    const sc = mk(new RoundedBoxGeometry(0.65, 0.22, 0.45, 2, 0.03), mat(suitColors[i], 0.5), g, -3.5 + i * 2.1, 0.18, 2.2 + (i % 2) * 0.9);
    sc.rotation.y = i * 0.8;
  }

  // Sheared fuselage latch with outward-blown explosive bolts (for shots 176-179!)
  const latchGroup = new THREE.Group();
  latchGroup.position.set(2.4, 1.25, -1.2);
  g.add(latchGroup);
  mk(new THREE.BoxGeometry(0.75, 0.95, 0.12), darkMetal, latchGroup);
  for (let i = 0; i < 6; i++) {
    const bx = (i % 2 === 0 ? -0.24 : 0.24), by = -0.32 + Math.floor(i / 2) * 0.32;
    const bolt = mk(new THREE.CylinderGeometry(0.035, 0.035, 0.18, 10), alum, latchGroup, bx, by, 0.08);
    bolt.rotation.x = PI / 2 + (bx * 0.6); // flared outward!
  }

  return { g, hull, latchGroup };
}

function buildReefZone(root) {
  const g = new THREE.Group();
  const [rx, rz] = ZONES.reef;
  g.position.set(rx, -0.35, rz);
  root.add(g);

  const coralColors = [0xff6b8b, 0xffa94d, 0xa855f7, 0x38d9a9, 0xffd43b];
  const R = rng(202);
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * TAU + R() * 0.3, d = 1.4 + R() * 3.8;
    const c = mk(new THREE.DodecahedronGeometry(0.32 + R() * 0.35, 1), mat(coralColors[i % coralColors.length], 0.8), g, Math.cos(a) * d, 0.1, Math.sin(a) * d);
    c.scale.y = 0.7 + R() * 0.7;
  }

  const realFish = makeParrotfish(false);
  const ghostFish = makeParrotfish(true);
  realFish.g.position.set(0.4, 0.15, 0.6);
  ghostFish.g.position.set(0.4, 0.48, 0.45); // refracted image 33cm higher & closer!
  g.add(realFish.g, ghostFish.g);

  return { g, realFish, ghostFish };
}

function buildJungleCampZone(root) {
  const g = new THREE.Group();
  const [cx, cz] = ZONES.camp, cy = groundY(cx, cz);
  g.position.set(cx, cy, cz);
  root.add(g);

  const bamM = mat(0xb59a45, 0.75), leafM = mat(0x3a9638, 0.8, { side: THREE.DoubleSide }), stoneM = mat(0x52525b, 0.9);

  // 1. Bamboo A-Frame Shelter (-2.4, 0, -1.6)
  const shelter = new THREE.Group();
  shelter.position.set(-2.4, 0, -1.6);
  shelter.rotation.y = 0.25;
  g.add(shelter);
  for (const sz of [-1.2, 1.2]) {
    for (const sx of [-1, 1]) {
      const pole = mk(new THREE.CylinderGeometry(0.055, 0.065, 2.2, 10), bamM, shelter, sx * 0.62, 0.95, sz);
      pole.rotation.z = sx * 0.52;
    }
  }
  const ridgePole = mk(new THREE.CylinderGeometry(0.05, 0.05, 2.8, 10), bamM, shelter, 0, 1.85, 0);
  ridgePole.rotation.x = PI / 2;
  const roofL = mk(new THREE.BoxGeometry(0.08, 2.15, 2.6), leafM, shelter, -0.58, 1.02, 0); roofL.rotation.z = -0.52;
  const roofR = mk(new THREE.BoxGeometry(0.08, 2.15, 2.6), leafM, shelter, 0.58, 1.02, 0); roofR.rotation.z = 0.52;
  // Single leaf mattress inside
  mk(new RoundedBoxGeometry(0.95, 0.12, 2.1, 2, 0.04), mat(0x4ea845, 0.85), shelter, 0, 0.07, 0);

  // 2. Stone Fire Ring + Campfire (0.2, 0, 0.8)
  const fireGroup = new THREE.Group();
  fireGroup.position.set(0.2, 0, 0.8);
  g.add(fireGroup);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    mk(new THREE.DodecahedronGeometry(0.18, 0), stoneM, fireGroup, Math.cos(a) * 0.58, 0.1, Math.sin(a) * 0.58);
  }
  for (let i = 0; i < 4; i++) {
    const log = mk(new THREE.CylinderGeometry(0.06, 0.07, 0.75, 8), mat(0x6b4423, 0.9), fireGroup, 0, 0.14, 0);
    log.rotation.set(PI / 2 - 0.3, (i * PI) / 2, 0);
  }
  const flames = makeFlames({ n: 7, r: 0.36, seed: 87 });
  fireGroup.add(flames.g);
  const fireLight = new THREE.PointLight(0xff8c2b, 0, 12, 1.5);
  fireLight.position.set(0, 0.75, 0);
  fireGroup.add(fireLight);

  // 3. Three Conical Solar Water Distillation Pits (2.6, 0, -0.4)
  const stillsGroup = new THREE.Group();
  stillsGroup.position.set(2.5, 0, -0.3);
  g.add(stillsGroup);
  const plasticM = new THREE.MeshStandardMaterial({ color: 0xdbeafe, roughness: 0.08, metalness: 0.1, transparent: true, opacity: 0.52, side: THREE.DoubleSide });
  for (let i = 0; i < 3; i++) {
    const pit = new THREE.Group();
    pit.position.set((i - 1) * 1.35, 0, (i % 2) * 0.45);
    stillsGroup.add(pit);
    // Damp sand rim + dark pit depression
    mk(new THREE.TorusGeometry(0.52, 0.09, 10, 24), mat(0xc8ad7f, 0.9), pit, 0, 0.05, 0).rotation.x = PI / 2;
    mk(new THREE.CircleGeometry(0.48, 20), mat(0x6b5839, 0.95), pit, 0, 0.02, 0).rotation.x = -PI / 2;
    // Crushed green plants ring + central cup
    mk(new THREE.TorusGeometry(0.32, 0.055, 8, 18), leafM, pit, 0, 0.05, 0).rotation.x = PI / 2;
    mk(new THREE.CylinderGeometry(0.09, 0.07, 0.14, 14), mat(0x38bdf8, 0.3), pit, 0, 0.07, 0);
    // Inverted clear plastic cone + central pebble weight
    const cone = mk(new THREE.ConeGeometry(0.52, 0.22, 24, 1, true), plasticM, pit, 0, 0.04, 0);
    cone.rotation.x = PI;
    mk(new THREE.DodecahedronGeometry(0.055, 0), stoneM, pit, 0, 0.06, 0);
  }

  // 4. Driftwood Aiming Tripod + Mounted Parabolic Wing Slat (1.9, 0, 1.5)
  const tripod = new THREE.Group();
  tripod.position.set(1.9, 0, 1.5);
  g.add(tripod);
  const woodM = mat(0x7c5c3e, 0.88);
  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * TAU;
    const leg = mk(new THREE.CylinderGeometry(0.035, 0.05, 1.65, 8), woodM, tripod, Math.cos(a) * 0.34, 0.74, Math.sin(a) * 0.34);
    leg.rotation.z = Math.cos(a) * 0.36;
    leg.rotation.x = -Math.sin(a) * 0.36;
  }
  // Basalt anchor rocks at tripod base
  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * TAU + 0.4;
    mk(new THREE.DodecahedronGeometry(0.22, 0), stoneM, tripod, Math.cos(a) * 0.42, 0.12, Math.sin(a) * 0.42);
  }
  const mountedSlat = makeWingSlat();
  mountedSlat.g.position.set(0, 1.38, 0);
  tripod.add(mountedSlat.g);

  // 5. Pointed Basalt Husking Wedge Stone (-0.9, 0, 1.7)
  const wedge = mk(new THREE.ConeGeometry(0.18, 0.52, 5), stoneM, g, -0.9, 0.26, 1.7);

  return { g, shelter, ridgePole, roofL, roofR, fireGroup, flames, fireLight, stillsGroup, tripod, mountedSlat, wedge };
}

function buildStormLeverZone(root) {
  const g = new THREE.Group();
  const [sx, sz] = ZONES.storm, sy = groundY(sx, sz);
  g.position.set(sx, sy, sz);
  root.add(g);

  const alum = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, roughness: 0.35, metalness: 0.7 });
  const ironwood = mat(0x5c3a21, 0.85);
  const basalt = mat(0x3f3f46, 0.92);

  // Fallen 180kg aluminum structural I-beam
  const beamGroup = new THREE.Group();
  beamGroup.position.set(0, 0.22, 0);
  g.add(beamGroup);
  mk(new THREE.BoxGeometry(2.6, 0.28, 0.32), alum, beamGroup);
  mk(new THREE.BoxGeometry(2.62, 0.06, 0.44), alum, beamGroup, 0, 0.14, 0);
  mk(new THREE.BoxGeometry(2.62, 0.06, 0.44), alum, beamGroup, 0, -0.14, 0);

  // 40cm Basalt Fulcrum Boulder + 2.4m Ironwood Lever Spar
  const fulcrum = mk(new THREE.DodecahedronGeometry(0.28, 1), basalt, g, -0.55, 0.22, 0.35);
  const sparPivot = new THREE.Group();
  sparPivot.position.set(-0.55, 0.42, 0.35);
  g.add(sparPivot);
  const spar = mk(new THREE.CylinderGeometry(0.055, 0.07, 2.5, 10), ironwood, sparPivot, -0.55, 0, -0.1);
  spar.rotation.z = PI / 2;
  spar.rotation.y = 0.22;

  return { g, beamGroup, fulcrum, sparPivot, spar };
}

function buildRidgeHelipadZone(root) {
  const g = new THREE.Group();
  const [rx, rz] = ZONES.ridge, ry = groundY(rx, rz);
  g.position.set(rx, ry, rz);
  root.add(g);

  // Basalt cliff ledge platform overlooking the dawn ocean
  const basalt = mat(0x3f424a, 0.92);
  const pad = mk(new THREE.CylinderGeometry(5.2, 6.4, 2.2, 16), basalt, g, 0, 0.9, 0);
  const hRing = mk(new THREE.RingGeometry(2.2, 2.45, 32), new THREE.MeshBasicMaterial({ color: 0xfacc15, side: THREE.DoubleSide }), g, 0, 2.02, 0);
  hRing.rotation.x = -PI / 2;

  // 3D Coast Guard Rescue Helicopter (orange/white/navy with spinning rotors)
  const heli = new THREE.Group();
  heli.position.set(0, 2.05, -0.8);
  g.add(heli);
  const cgOrange = new THREE.MeshStandardMaterial({ color: 0xea580c, roughness: 0.32, metalness: 0.2 });
  const cgWhite = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3, metalness: 0.2 });
  const darkMetal = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.35, metalness: 0.7 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.1, metalness: 0.3, transparent: true, opacity: 0.55 });

  // Cabin + nose + tail boom
  mk(new RoundedBoxGeometry(2.2, 1.55, 3.4, 4, 0.35), cgOrange, heli, 0, 1.35, 0);
  mk(new RoundedBoxGeometry(2.24, 0.42, 3.42, 3, 0.1), cgWhite, heli, 0, 1.45, 0);
  mk(new THREE.SphereGeometry(1.05, 20, 16), glass, heli, 0, 1.32, 1.45).scale.set(0.95, 0.82, 0.9);
  mk(new THREE.CylinderGeometry(0.22, 0.42, 3.8, 12), cgOrange, heli, 0, 1.55, -3.2).rotation.x = PI / 2;
  mk(new THREE.BoxGeometry(0.12, 1.1, 0.65), cgWhite, heli, 0, 2.0, -4.9);

  // Landing skids
  for (const sx of [-0.95, 0.95]) {
    mk(new THREE.CylinderGeometry(0.05, 0.05, 3.2, 10), darkMetal, heli, sx, 0.12, 0.1).rotation.x = PI / 2;
    for (const sz of [-0.9, 0.9]) mk(new THREE.CylinderGeometry(0.04, 0.04, 0.55, 8), darkMetal, heli, sx * 0.85, 0.38, sz).rotation.z = sx * 0.25;
  }

  // Main rotor + tail rotor
  const mainRotor = new THREE.Group();
  mainRotor.position.set(0, 2.32, 0);
  heli.add(mainRotor);
  mk(new THREE.CylinderGeometry(0.14, 0.16, 0.3, 12), darkMetal, mainRotor);
  for (let i = 0; i < 4; i++) {
    const blade = mk(new THREE.BoxGeometry(4.4, 0.025, 0.22), darkMetal, mainRotor);
    blade.rotation.y = (i * PI) / 2;
  }
  const tailRotor = new THREE.Group();
  tailRotor.position.set(0.18, 2.1, -5.0);
  heli.add(tailRotor);
  for (let i = 0; i < 2; i++) {
    const b = mk(new THREE.BoxGeometry(0.02, 0.95, 0.12), darkMetal, tailRotor);
    b.rotation.x = (i * PI) / 2;
  }

  // Twin-Engine Coast Guard Search Plane + Green Parachute Flare
  const searchPlane = new THREE.Group();
  searchPlane.position.set(-18, 22, -45);
  root.add(searchPlane);
  mk(new THREE.CylinderGeometry(0.55, 0.55, 5.2, 14), cgWhite, searchPlane).rotation.z = PI / 2;
  mk(new THREE.BoxGeometry(0.9, 0.12, 7.6), cgOrange, searchPlane, 0, 0.1, 0);
  mk(new THREE.BoxGeometry(0.7, 1.1, 0.12), cgOrange, searchPlane, -2.3, 0.6, 0);

  const greenFlare = new THREE.Group();
  greenFlare.position.set(-10, 14, -28);
  greenFlare.visible = false;
  root.add(greenFlare);
  const flareOrb = new THREE.Mesh(new THREE.SphereGeometry(0.38, 16, 12), new THREE.MeshBasicMaterial({ color: 0x22c55e }));
  const flareHalo = new THREE.Mesh(new THREE.SphereGeometry(1.1, 16, 12), new THREE.MeshBasicMaterial({ color: 0x4ade80, transparent: true, opacity: 0.38 }));
  greenFlare.add(flareOrb, flareHalo);

  return { g, padY: ry + 2.02, heli, mainRotor, tailRotor, searchPlane, greenFlare };
}

export async function buildCrushIslandWorld(studio) {
  const I = await buildIsland(studio);
  // Hide the 049 promo props (library, peach orchard, wifi router, beach umbrella) so our pristine tropical survival island shines
  I.L.g.visible = false;
  I.O.trees.forEach((t) => (t.visible = false));
  I.O.ground.forEach((p) => (p.visible = false));
  I.O.sign.visible = false;
  I.router.g.visible = false;
  I.wsign.visible = false;
  I.B.umb.visible = false;

  const root = I.root;
  const wreck = buildFuselageWreck(root);
  const reef = buildReefZone(root);
  const camp = buildJungleCampZone(root);
  const storm = buildStormLeverZone(root);
  const ridge = buildRidgeHelipadZone(root);

  // Round-faced toy-like 3D capsule characters
  const you = makeToyCharacter({
    skin: 0xf2c29a,
    top: 0x0284c7,     // Ocean blue survivor shirt
    collar: 0xf8fafc,
    pants: 0x1e293b,   // Dark navy pants
    shoes: 0x334155,
    hair: 0x2c1b12,    // Messy dark brown hair tufts
    hairStyle: 'messy',
    headR: 0.165,
  });
  const crush = makeToyCharacter({
    skin: 0xf6ccb0,
    top: 0xe11d48,     // Coral rose top
    collar: 0xfff1f2,
    pants: 0x3b4d6b,   // Slate denim shorts/pants
    shoes: 0x475569,
    hair: 0x5c331e,    // Chestnut bob + ponytail
    hairStyle: 'bob',
    ponytail: true,
    headR: 0.162,
  });
  const pilot = makeToyCharacter({
    skin: 0xe2ad8c,
    top: 0x3f6212,     // Olive flight suit
    collar: 0x1a2e05,
    pants: 0x365314,
    shoes: 0x18181b,
    hair: 0x27272a,
    hairStyle: 'short',
    helmet: true,
    headR: 0.164,
  });
  pilot.root.visible = false;
  studio.scene.add(you.root, crush.root, pilot.root);

  // Handheld & world props
  const props = {
    boardingPass: makeBoardingPass14B(),
    wingSlat: makeWingSlat(),
    phone: makeCrackedPhone(),
    titaniumCase: makeTitaniumCase(),
    coconutWhole: makeCoconutProp(false),
    coconutSplit: makeCoconutProp(true),
    spear: makeBambooSpear(),
    heldFish: makeParrotfish(false),
    thatchWig: makePalmThatchWig(),
    batteryFoil: makeBatterySparkFoil(),
  };
  Object.values(props).forEach((p) => {
    p.g.visible = false;
    studio.scene.add(p.g);
  });

  // Particle FX (smoke from fuselage, sparks, water splash, dust, rain)
  const fx = makeFX(studio.scene, { max: { smoke: 360, spark: 260, drops: 420, dust: 260, glow: 120 }, nearFade: [0.4, 1.4] });

  // Speech bubbles (using EDStudio's native makeSpeechBubble)
  const BUBBLES = {
    layover:  makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ['Please tell me this is a layover.'], width: 1.15, maxChars: 22 }),
    stopmath: makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ["Stop doing math. You're making it worse."], width: 1.2, maxChars: 24 }),
    ticket:   makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ["Don't ask. It's my lucky ticket."], width: 1.15, maxChars: 22 }),
    coconut:  makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ['Coconut one. Action hero zero.'], width: 1.15, maxChars: 22 }),
    tackle:   makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ['Did you just tackle the ocean?'], width: 1.15, maxChars: 22 }),
    einstein: makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ['Aim below the belly, Einstein.'], width: 1.15, maxChars: 22 }),
    row6:     makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ['I was in row 6. I paid $50 to sit by you.'], width: 1.25, maxChars: 24, soft: true }),
    best50:   makeSpeechBubble({ name: 'YOU',   accent: '#0284c7', lines: ['Best 50 dollars I ever spent.'], width: 1.15, maxChars: 22, soft: true }),
    pinned:   makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ["It's pinned! Leave me—flash the plane!"], width: 1.25, maxChars: 24 }),
    pretzel:  makeSpeechBubble({ name: 'YOU',   accent: '#0284c7', lines: ['The pretzel bag did not make it.'], width: 1.15, maxChars: 22 }),
    train:    makeSpeechBubble({ name: 'CRUSH', accent: '#e11d48', lines: ["Next time, we're taking a train."], width: 1.15, maxChars: 22 }),
    asset14b: makeSpeechBubble({ name: 'COMMANDER', accent: '#dc2626', lines: ['Control, Asset 14B and the cargo survived.'], width: 1.28, maxChars: 24 }),
  };
  Object.values(BUBBLES).forEach((b) => {
    b.setPop(0);
    studio.scene.add(b.sprite);
  });

  // Storm rain particles (instanced streaks around camera when storm mood active)
  const rainGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.65, 4);
  const rainMat = new THREE.MeshBasicMaterial({ color: 0xcbd5e1, transparent: true, opacity: 0.45 });
  const rainCount = 260;
  const rainMesh = new THREE.InstancedMesh(rainGeo, rainMat, rainCount);
  rainMesh.visible = false;
  studio.scene.add(rainMesh);
  const rRng = rng(909);
  const rainSeeds = Array.from({ length: rainCount }, () => [(rRng() - 0.5) * 14, rRng() * 8, (rRng() - 0.5) * 14, 0.7 + rRng() * 0.6]);
  const _m4 = new THREE.Matrix4(), _q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0.15, 0, -0.38)), _s = new THREE.Vector3(1, 1, 1), _p = new THREE.Vector3();

  function updateRain(t, camPos, on) {
    rainMesh.visible = on;
    if (!on) return;
    for (let i = 0; i < rainCount; i++) {
      const [ox, oy, oz, sp] = rainSeeds[i];
      const fall = ((t * 14 * sp + oy) % 8);
      _p.set(camPos[0] + ox - fall * 0.35, Math.max(0, camPos[1] - 2 + (8 - fall)), camPos[2] + oz);
      _m4.compose(_p, _q, _s);
      rainMesh.setMatrixAt(i, _m4);
    }
    rainMesh.instanceMatrix.needsUpdate = true;
  }

  return {
    I, root, wreck, reef, camp, storm, ridge,
    you, crush, pilot, props, fx, BUBBLES,
    updateRain, groundY,
  };
}
