// Hyper-Builder Kinetic Motion-Graphics Explainer Suite for EDStudio (engine/mg/)
// Uses EDStudio's native engine/mg/ (stage.js, draw.js, charts.js, type.js, fx.js, icons.js, people.js, ease.js)
// to render high-retention animated charts, radar grids, ray-optics, osmosis diagrams, and mechanical blueprints.
import { E, tw, clamp, lerp, rng } from '@engine/mg/ease.js';
import { PAL } from '@engine/mg/stage.js';
import { circle, rrect, ring, line, shape, ellipse, glow, qpts, TAU } from '@engine/mg/draw.js';
import { bars, lineChart, gauge, meter, progressRing } from '@engine/mg/charts.js';
import { label, ktext, txt, bigNum, FONT } from '@engine/mg/type.js';
import { soundRings, burst, sparkle } from '@engine/mg/fx.js';
import { plane, battery, clockFace, check, pin } from '@engine/mg/icons.js';

// Shared Hyper-Builder dark-indigo blueprint grid backdrop with subtle parallax motion
export function drawHyperGrid(M, g, t, titleText, subText, u) {
  M.sky(g, ['#160F29', '#110B22', '#0B0716']);
  // Blueprint grid lines
  g.save();
  const shiftX = (t * 18) % 60, shiftY = (t * 12) % 60;
  g.strokeStyle = 'rgba(139, 92, 246, 0.14)';
  g.lineWidth = 1.5;
  for (let x = -60 + shiftX; x < 1140; x += 60) {
    g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 1920); g.stroke();
  }
  for (let y = -60 + shiftY; y < 1980; y += 60) {
    g.beginPath(); g.moveTo(0, y); g.lineTo(1080, y); g.stroke();
  }
  g.strokeStyle = 'rgba(56, 189, 248, 0.22)';
  g.lineWidth = 2.5;
  for (let x = -240 + shiftX * 4; x < 1320; x += 240) {
    g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 1920); g.stroke();
  }
  for (let y = -240 + shiftY * 4; y < 2160; y += 240) {
    g.beginPath(); g.moveTo(0, y); g.lineTo(1080, y); g.stroke();
  }
  g.restore();

  // Top header card (placed at y 215..370, cleanly below top-left #crush-hud at y 44..185)
  const k = clamp(u * 2.5);
  rrect(g, 70, 215, 940, 160, 28, { fill: '#1e1638', stroke: '#8b5cf6', lw: 4, shadow: { len: 80, a: 0.35 } });
  txt(g, 'HYPER BUILDER · SURVIVAL SCIENCE', 540, 254, { size: 26, weight: 800, font: FONT.body, color: '#38bdf8', track: 5 });
  ktext(g, titleText, 540, 306, { size: 50, weight: 700, color: '#ffd23f', k, mode: 'rise' });
  if (subText) txt(g, subText, 540, 348, { size: 24, weight: 600, font: FONT.body, color: '#cbd5e1', alpha: clamp(u * 3 - 0.3) });
}

// 1. SEARCH GRID RADAR (45,000 KM² Circle vs 2 KM Scan Corridor)
export function drawSearchRadar(M, g, t, u) {
  drawHyperGrid(M, g, t, 'OCEAN SEARCH GRID MATH', '20-MIN GLIDE = 45,000 KM² RADIUS VS 2 KM SCAN CORRIDOR', u);
  const cx = 540, cy = 830, maxR = 310;
  const rExpand = maxR * E.out3(clamp(u * 1.6));

  // Radar scope circles
  rrect(g, 90, 460, 900, 740, 36, { fill: '#0f172a', stroke: '#334155', lw: 4, shadow: { len: 110, a: 0.3 } });
  glow(g, cx, cy, rExpand * 1.15, '#ef4444', 0.28, true);
  for (const f of [0.33, 0.66, 1.0]) {
    ring(g, cx, cy, maxR * f, { w: 3, color: 'rgba(56,189,248,0.28)', dash: [14, 10] });
  }
  // Expanding 45,000 km2 circle
  ring(g, cx, cy, Math.max(10, rExpand), { w: 10, color: '#ef4444' });
  // Rotating radar sweep line
  const ang = t * 2.4;
  line(g, [[cx, cy], [cx + Math.cos(ang) * maxR, cy + Math.sin(ang) * maxR]], { w: 6, color: '#22c55e', glow: 18 });

  // Tiny 2 km scan corridor strip across top half
  const scanX = lerp(cx - 240, cx + 240, (t * 0.45) % 1);
  rrect(g, cx - 250, cy - 135, 500, 22, 6, { fill: 'rgba(56,189,248,0.28)', flat: true });
  plane(g, scanX, cy - 124, 0.72, { color: '#38bdf8', rot: Math.PI / 2 });

  // Center island dot
  circle(g, cx, cy, 11, { fill: '#ffd23f', glow: { r: 35, color: '#ffd23f', a: 0.7 } });
  label(g, '45,000 KM² SEARCH ZONE', cx, cy + 215, { k: clamp(u * 2), bg: '#ef4444', color: '#ffffff', size: 36, leader: [cx + 120, cy + 120] });
  label(g, '2 KM SCAN CORRIDOR', cx, cy - 220, { k: clamp(u * 2 - 0.2), bg: '#38bdf8', color: '#0f172a', size: 32, leader: [cx, cy - 124] });

  // Bottom comparison bars (y = 1480, above caption band 1550+)
  bars(g, 160, 1480, 760, 200, [
    { v: 45000, label: 'SEARCH CIRCLE (KM²)', color: '#ef4444', valueColor: '#fca5a5' },
    { v: 2400,  label: 'SINGLE PASS (2 KM)',  color: '#38bdf8', valueColor: '#7dd3fc' },
  ], { k: clamp(u * 1.8), max: 45000, labelSize: 26, valueSize: 40 });
}

// 2. RULE OF THREES & BODY WATER CLOCK (72 Hours / 4L Sweat Loss)
export function drawRuleOfThrees(M, g, t, u) {
  drawHyperGrid(M, g, t, 'THE SURVIVAL RULE OF THREES', 'AT 32°C TWO SURVIVORS LOSE 4.0 LITERS OF WATER PER DAY', u);
  const cards = [
    { y: 420, title: '3 MINUTES', sub: 'WITHOUT AIR (OXYGEN)', col: '#38bdf8', p: 1.0, badge: 'SURVIVED CRASH' },
    { y: 690, title: '3 DAYS (72 HRS)', sub: 'WITHOUT WATER AT 32°C', col: '#ef4444', p: clamp(1 - u * 0.45), badge: 'CRITICAL CLOCK' },
    { y: 960, title: '3 WEEKS', sub: 'WITHOUT FOOD (CALORIES)', col: '#22c55e', p: 0.92, badge: 'LOW PRIORITY' },
  ];
  cards.forEach((c, i) => {
    const ck = clamp(u * 2.2 - i * 0.25);
    rrect(g, 90, c.y, 900, 225, 28, { fill: '#18182f', stroke: c.col, lw: 4, shadow: { len: 70, a: 0.25 } });
    progressRing(g, 220, c.y + 112, 74, c.p * ck, { color: c.col, text: i === 1 ? '72h' : i === 0 ? '3m' : '21d' });
    txt(g, c.title, 345, c.y + 78, { size: 50, weight: 800, align: 'left', color: c.col });
    txt(g, c.sub, 345, c.y + 135, { size: 28, weight: 600, font: FONT.body, align: 'left', color: '#e2e8f0' });
    rrect(g, 345, c.y + 162, 290, 42, 21, { fill: c.col, flat: true });
    txt(g, c.badge, 490, c.y + 183, { size: 22, weight: 800, font: FONT.body, color: '#0f172a', shadow: false });
  });

  // Sweat & breathing dehydration gauge at bottom
  rrect(g, 90, 1230, 900, 260, 28, { fill: '#151c36', stroke: '#ffd23f', lw: 3 });
  gauge(g, 290, 1425, 135, clamp(u * 1.3) * 0.88, { k: clamp(u * 1.8), label: '32°C HEAT LOSS' });
  bigNum(g, (4.0 * clamp(u * 1.5)).toFixed(1), 670, 1345, { size: 115, unit: 'L / DAY', color: '#ffd23f', k: clamp(u * 1.6) });
  txt(g, 'LOST VIA SWEAT & RESPIRATION', 690, 1440, { size: 26, weight: 700, font: FONT.body, color: '#94a3b8' });
}

// 3. KIDNEY SALT OSMOSIS (35 g/L Seawater vs 20 g/L Kidney Max)
export function drawKidneyOsmosis(M, g, t, u) {
  drawHyperGrid(M, g, t, 'KIDNEY SALT OSMOSIS MATH', 'SEAWATER (35 g/L) EXCEEDS HUMAN KIDNEY LIMIT (20 g/L)', u);

  rrect(g, 90, 410, 900, 560, 30, { fill: '#131b38', stroke: '#6366f1', lw: 4, shadow: { len: 90, a: 0.3 } });
  bars(g, 170, 875, 740, 340, [
    { v: 35, label: 'SEAWATER (g/L)', color: '#ef4444', valueColor: '#fca5a5' },
    { v: 20, label: 'KIDNEY MAX (g/L)', color: '#22c55e', valueColor: '#86efac' },
    { v: 15, label: 'TOXIC SURPLUS', color: '#f59e0b', valueColor: '#fde047' },
  ], { k: clamp(u * 1.7), max: 40, valueFmt: (v) => `${Math.round(v)} g/L`, labelSize: 24, valueSize: 42 });

  // Cellular osmosis flow panel (y = 1015..1485)
  rrect(g, 90, 1015, 900, 470, 30, { fill: '#1a1230', stroke: '#ef4444', lw: 4 });
  txt(g, 'CELLULAR OSMOSIS: "LIQUID SANDPAPER"', 540, 1070, { size: 34, weight: 800, color: '#fca5a5', track: 3 });

  // Red blood cell shrinking as water is pulled out to flush +15g salt
  const shrink = 1 - 0.32 * clamp(u * 1.5);
  circle(g, 290, 1275, 115, { fill: 'rgba(239,68,68,0.18)', stroke: '#ef4444', lw: 3, flat: true });
  circle(g, 290, 1275, 110 * shrink, { fill: '#dc2626', glow: { r: 90, color: '#ef4444', a: 0.4 } });
  txt(g, 'BODY CELL', 290, 1275, { size: 28, weight: 800, color: '#ffffff' });

  // Animated extraction arrows -> Kidney Flush (-0.5 L)
  for (let i = 0; i < 3; i++) {
    const ax = lerp(430, 620, ((t * 1.1 + i * 0.33) % 1));
    circle(g, ax, 1235 + (i - 1) * 42, 14, { fill: '#38bdf8', flat: true });
  }
  line(g, [[430, 1275], [640, 1275]], { w: 10, color: '#38bdf8', k: clamp(u * 2) });
  rrect(g, 650, 1165, 290, 220, 26, { fill: '#0f172a', stroke: '#38bdf8', lw: 4 });
  txt(g, 'NET LOSS', 795, 1215, { size: 28, weight: 800, color: '#38bdf8' });
  txt(g, '−0.5 L', 795, 1285, { size: 72, weight: 800, color: '#ef4444' });
  txt(g, 'PER 1 L DRANK', 795, 1345, { size: 24, weight: 700, font: FONT.body, color: '#cbd5e1' });
}

// 4. PARABOLIC WING SLAT OPTICS (3 KM Flat Mirror vs 37 KM Concave Wing Slat + 410°C)
export function drawParabolicMirror(M, g, t, u) {
  drawHyperGrid(M, g, t, 'PARABOLIC WING SLAT OPTICS', 'CURVED ALUMINUM SLAT COLLIMATES SUNLIGHT TO 37 KM & 410°C', u);

  // Top box: Flat Pocket Mirror (scatters after 3 km)
  rrect(g, 90, 390, 900, 480, 28, { fill: '#141a32', stroke: '#64748b', lw: 3 });
  txt(g, 'FLAT POCKET MIRROR · SCATTERS AT 3 KM', 540, 440, { size: 32, weight: 800, color: '#94a3b8' });
  rrect(g, 160, 560, 24, 160, 8, { fill: '#cbd5e1', flat: true });
  for (const ang of [-0.36, -0.18, 0, 0.18, 0.36]) {
    line(g, [[184, 640], [184 + Math.cos(ang) * 340, 640 + Math.sin(ang) * 340]], { w: 6, color: '#fde047', k: clamp(u * 2), alpha: 0.45, dash: [16, 12] });
  }
  label(g, '3 KM MAX RANGE', 740, 640, { k: clamp(u * 2 - 0.2), bg: '#475569', color: '#ffffff', size: 34 });

  // Bottom box: Concave Aluminum Wing Slat (37 km beam + 410°C focal point)
  rrect(g, 90, 910, 900, 575, 28, { fill: '#17133a', stroke: '#ffd23f', lw: 4, shadow: { len: 90, a: 0.35 } });
  txt(g, 'CONCAVE WING SLAT · 37 KM HORIZON BEAM', 540, 965, { size: 34, weight: 800, color: '#ffd23f' });
  // Curved parabolic reflector arc
  ring(g, 245, 1190, 110, { w: 18, color: '#e2e8f0', a0: Math.PI * 0.65, a1: Math.PI * 1.35 });
  // Collimated high-intensity beam across horizon to search plane
  const beamK = clamp(u * 1.8);
  glow(g, 330, 1190, 95, '#ffd23f', 0.75, true);
  for (const dy of [-28, 0, 28]) {
    line(g, [[165, 1190 + dy * 2.2], [330, 1190], [910, 1190 + dy * 0.35]], { w: 9, color: '#ffd23f', k: beamK, glow: 22 });
  }
  plane(g, 895, 1190, 0.9, { color: '#38bdf8', rot: -Math.PI / 2 });
  label(g, '410°C CHAR FOCUS', 350, 1385, { k: clamp(u * 2.2), bg: '#ef4444', color: '#ffffff', size: 32, leader: [330, 1190] });
  label(g, '37 KM FLASH (12.3×)', 755, 1385, { k: clamp(u * 2.2 - 0.2), bg: '#ffd23f', color: '#0f172a', size: 34, leader: [860, 1190] });
}

// 5. COCONUT SHELL 20 MPa VS BASALT WEDGE LEVERAGE
export function drawCoconutMpa(M, g, t, u) {
  drawHyperGrid(M, g, t, 'COCONUT SHELL COMPRESSIVE STRENGTH', '20 MEGAPIASCALS = RED PAVING BRICK (KARATE CHOP FAILS)', u);

  rrect(g, 90, 400, 900, 560, 30, { fill: '#141c36', stroke: '#f59e0b', lw: 4 });
  bars(g, 170, 865, 740, 340, [
    { v: 2,  label: 'KARATE CHOP',   color: '#ef4444', valueColor: '#fca5a5' },
    { v: 20, label: 'RED BRICK',     color: '#f97316', valueColor: '#fdba74' },
    { v: 20, label: 'COCONUT SHELL', color: '#22c55e', valueColor: '#86efac' },
  ], { k: clamp(u * 1.7), max: 24, valueFmt: (v) => `${Math.round(v)} MPa`, labelSize: 26, valueSize: 42 });

  // Basalt wedge mechanical advantage diagram
  rrect(g, 90, 1005, 900, 480, 30, { fill: '#122230', stroke: '#22c55e', lw: 4 });
  txt(g, 'POINTED BASALT WEDGE · SPLITS IN 4 SECONDS', 540, 1060, { size: 34, weight: 800, color: '#86efac' });
  // Pointed basalt triangle + coconut splitting open
  shape(g, [[310, 1410], [450, 1410], [380, 1210]], { fill: '#64748b', stroke: '#cbd5e1', lw: 4 });
  const splitDX = 36 * clamp(u * 1.8);
  circle(g, 345 - splitDX, 1175, 68, { fill: '#22c55e' });
  circle(g, 415 + splitDX, 1175, 68, { fill: '#22c55e' });
  sparkle(g, 380, 1190, t, { r: 58, color: '#38bdf8' });
  bigNum(g, String(Math.round(400 * clamp(u * 1.6))), 720, 1245, { size: 115, unit: 'mL', color: '#38bdf8', k: clamp(u * 1.6) });
  txt(g, 'STERILE ELECTROLYTE WATER', 735, 1345, { size: 26, weight: 800, font: FONT.body, color: '#e2e8f0' });
}

// 6. SNELL'S LAW WATER REFRACTION (n = 1.33 Spear Aiming)
export function drawRefractionSpear(M, g, t, u) {
  drawHyperGrid(M, g, t, "SNELL'S LAW WATER REFRACTION (n = 1.33)", 'LIGHT BENDS AT SURFACE — TARGET SITS 30 CM DEEPER', u);

  rrect(g, 90, 400, 900, 1080, 32, { fill: '#0c1938', stroke: '#38bdf8', lw: 4 });
  // Waterline at y = 830
  rrect(g, 94, 830, 892, 646, 28, { fill: 'rgba(14, 116, 144, 0.38)', flat: true });
  line(g, [[94, 830], [986, 830]], { w: 8, color: '#38bdf8', dash: [20, 12] });
  txt(g, 'AIR (n = 1.00)', 230, 785, { size: 28, weight: 800, color: '#94a3b8' });
  txt(g, 'REEF WATER (n = 1.33)', 285, 875, { size: 28, weight: 800, color: '#38bdf8' });

  // Observer eye top-left (210, 520), surface refraction point (520, 830)
  circle(g, 210, 520, 34, { fill: '#ffd23f' });
  txt(g, 'YOUR EYE', 210, 460, { size: 26, weight: 800, color: '#ffd23f' });

  // Straight-line apparent sight ray -> Hologram Ghost Fish (780, 1030)
  line(g, [[210, 520], [520, 830], [780, 1030]], { w: 6, color: '#ef4444', dash: [16, 12], k: clamp(u * 1.8) });
  ellipse(g, 780, 1030, 95, 48, { fill: 'rgba(56,189,248,0.22)', stroke: '#ef4444', lw: 4, flat: true });
  txt(g, 'HOLOGRAM (−30 CM MISS)', 760, 950, { size: 26, weight: 800, color: '#fca5a5' });

  // True bent ray + True Spear Trajectory -> Real Blue Parrotfish (720, 1290)
  line(g, [[210, 520], [520, 830], [720, 1290]], { w: 9, color: '#ffd23f', k: clamp(u * 1.8), glow: 16 });
  line(g, [[250, 580], [720, 1290]], { w: 10, color: '#22c55e', k: clamp(u * 2 - 0.3) });
  ellipse(g, 720, 1290, 100, 52, { fill: '#0284c7', stroke: '#ffd23f', lw: 4 });
  circle(g, 775, 1280, 10, { fill: '#ffffff', flat: true });
  label(g, 'TRUE TARGET: AIM BELOW BELLY!', 520, 1405, { k: clamp(u * 2.2 - 0.3), bg: '#22c55e', color: '#0f172a', size: 34, leader: [720, 1290] });
}

// 7. SOLAR WATER DISTILLATION PIT (800 mL x 3 = 2.4 L/Day)
export function drawSolarStill(M, g, t, u) {
  drawHyperGrid(M, g, t, 'GREENHOUSE SOLAR DISTILLATION', '3 CONICAL SAND PITS × 800 mL = 2.4 LITERS PURE WATER / DAY', u);

  rrect(g, 90, 400, 900, 680, 32, { fill: '#151c36', stroke: '#38bdf8', lw: 4 });
  // Conical pit cross section
  shape(g, [[160, 740], [320, 990], [760, 990], [920, 740], [920, 1040], [160, 1040]], { fill: '#b45309', flat: true });
  // V-shaped clear plastic sheet sagged by central pebble at (540, 835)
  line(g, [[180, 740], [540, 835], [900, 740]], { w: 9, color: '#7dd3fc', glow: 14 });
  circle(g, 540, 815, 22, { fill: '#64748b', stroke: '#e2e8f0', lw: 3 }); // Pebble
  // Collecting cup at bottom center (540, 935)
  rrect(g, 485, 885, 110, 95, 12, { fill: '#1e293b', stroke: '#38bdf8', lw: 4 });
  const fillH = 72 * clamp(u * 1.6);
  rrect(g, 493, 972 - fillH, 94, Math.max(4, fillH), 8, { fill: '#38bdf8', flat: true });

  // Animated water drop falling from plastic apex into cup
  const dropY = lerp(840, 910, (t * 1.8) % 1);
  circle(g, 540, dropY, 10, { fill: '#38bdf8', flat: true });

  // Sun rays + rising vapor arrows
  for (const x of [310, 420, 660, 770]) {
    line(g, [[x, 470], [x, 710]], { w: 6, color: '#ffd23f', dash: [14, 10] });
    const vy = lerp(940, 790, ((t * 0.9 + x * 0.01) % 1));
    circle(g, x, vy, 8, { fill: 'rgba(125,211,252,0.75)', flat: true });
  }
  label(g, 'SALT LEFT IN SAND', 290, 985, { k: clamp(u * 2), bg: '#f59e0b', color: '#0f172a', size: 28 });
  label(g, 'PURE CONDENSATION', 780, 985, { k: clamp(u * 2 - 0.2), bg: '#38bdf8', color: '#0f172a', size: 28 });

  // Yield summary panel (y = 1120..1480)
  rrect(g, 90, 1120, 900, 360, 30, { fill: '#10243a', stroke: '#22c55e', lw: 4 });
  for (let i = 0; i < 3; i++) {
    progressRing(g, 240 + i * 300, 1265, 82, clamp(u * 1.8 - i * 0.15), { color: '#38bdf8', text: '800mL' });
    txt(g, `PIT #${i + 1}`, 240 + i * 300, 1380, { size: 28, weight: 800, color: '#cbd5e1' });
  }
  txt(g, 'TOTAL YIELD: 2.4 L / DAY (DEHYDRATION CLOCK BEATEN)', 540, 1440, { size: 30, weight: 800, color: '#86efac' });
}

// 8. CATEGORY 4 CYCLONE & +2.0M STORM SURGE MATH
export function drawCycloneSurge(M, g, t, u) {
  drawHyperGrid(M, g, t, 'CATEGORY 4 CYCLONE & STORM SURGE', '220 KM/H WINDS · −24 mbar DROP · +2.0 M SURGE OVER 1.2 M SANDBAR', u);

  rrect(g, 90, 400, 900, 490, 30, { fill: '#161432', stroke: '#ef4444', lw: 4 });
  gauge(g, 300, 720, 165, 0.92 * clamp(u * 1.6), { k: clamp(u * 1.6), label: '220 KM/H CAT-4' });
  bigNum(g, '−24', 730, 625, { size: 120, unit: 'mbar', color: '#ef4444', k: clamp(u * 1.6) });
  txt(g, 'COCKPIT ALTIMETER PRESSURE DROP', 730, 735, { size: 26, weight: 700, font: FONT.body, color: '#fca5a5' });
  txt(g, 'SURGE RISING 10 CM / MINUTE (180s WINDOW)', 540, 835, { size: 30, weight: 800, color: '#ffd23f' });

  // Cross-section of 2.0m surge over 1.2m beach (y = 930..1480)
  rrect(g, 90, 930, 900, 550, 30, { fill: '#0c1938', stroke: '#38bdf8', lw: 4 });
  // 1.2m beach sandbar mound vs 2.0m rising surge wave
  shape(g, [[120, 1440], [340, 1260], [740, 1260], [950, 1440]], { fill: '#d97706', flat: true });
  txt(g, '1.2 M CORAL SANDBAR', 540, 1365, { size: 30, weight: 800, color: '#0f172a', shadow: false });
  const surgeY = lerp(1310, 1085, clamp(u * 1.6));
  rrect(g, 94, surgeY, 892, 1476 - surgeY, 24, { fill: 'rgba(2, 132, 199, 0.58)', flat: true });
  line(g, [[94, surgeY], [986, surgeY]], { w: 10, color: '#38bdf8', glow: 16 });
  label(g, '+2.0 M STORM SURGE LEVEL', 540, surgeY - 45, { k: clamp(u * 2), bg: '#ef4444', color: '#ffffff', size: 34 });
}

// 9. 4:1 ARCHIMEDES LEVER & 410°C LITHIUM FOIL SPARK CHAIN
export function drawArchimedesLever(M, g, t, u) {
  drawHyperGrid(M, g, t, '4:1 ARCHIMEDES LEVER & 410°C SPARK', '45 KG × 4 = 180 KG TORQUE · 15 Wh FOIL SHORT = 410°C IGNITION', u);

  // Top panel: 4:1 Lever Diagram
  rrect(g, 90, 400, 900, 540, 30, { fill: '#151c36', stroke: '#22c55e', lw: 4 });
  const tilt = lerp(-0.14, 0.18, clamp(u * 1.7));
  g.save();
  g.translate(410, 770);
  // Fulcrum boulder triangle
  shape(g, [[-55, 85], [55, 85], [0, 0]], { fill: '#64748b', stroke: '#cbd5e1', lw: 4 });
  g.rotate(tilt);
  // 2.4m Ironwood lever bar (-190 to +430)
  rrect(g, -210, -24, 650, 24, 10, { fill: '#a16207', stroke: '#fde047', lw: 3 });
  // 180kg aluminum beam on short 0.4m arm (-170)
  rrect(g, -220, -135, 130, 110, 14, { fill: '#94a3b8', stroke: '#ffffff', lw: 3 });
  txt(g, '180 KG', -155, -80, { size: 30, weight: 800, color: '#0f172a', shadow: false });
  // 45kg downward push on long 1.6m arm (+370)
  circle(g, 380, -65, 42, { fill: '#22c55e' });
  txt(g, '45 KG', 380, -65, { size: 24, weight: 800, color: '#0f172a', shadow: false });
  g.restore();
  txt(g, '0.4 M LOAD ARM  :  1.6 M EFFORT ARM  =  4× FORCE MULTIPLIER', 540, 895, { size: 28, weight: 800, color: '#86efac' });

  // Bottom panel: 15 Wh Lithium Battery + Foil Wrapper -> 410°C Spark -> White Smoke
  rrect(g, 90, 980, 900, 500, 30, { fill: '#1a1230', stroke: '#ffd23f', lw: 4 });
  txt(g, 'THERMAL IGNITION CHAIN (52 SECONDS LEFT)', 540, 1038, { size: 32, weight: 800, color: '#ffd23f' });
  const steps = [
    { x: 240, l1: '15 Wh LI-ION', l2: 'BATTERY POUCH', col: '#38bdf8' },
    { x: 540, l1: 'FOIL RIBBON', l2: '410°C SPARK', col: '#ef4444' },
    { x: 830, l1: 'GREEN FRONDS', l2: 'WHITE SAP SMOKE', col: '#22c55e' },
  ];
  steps.forEach((s, i) => {
    const sk = clamp(u * 2.2 - i * 0.25);
    if (i < 2) line(g, [[s.x + 110, 1230], [steps[i + 1].x - 110, 1230]], { w: 10, color: '#ffd23f', k: sk });
    circle(g, s.x, 1230, 105 * sk, { fill: s.col, glow: { r: 120, color: s.col, a: 0.4 } });
    txt(g, s.l1, s.x, 1215, { size: 28, weight: 800, color: '#0f172a', shadow: false });
    txt(g, s.l2, s.x, 1252, { size: 22, weight: 700, color: '#0f172a', shadow: false });
  });
  burst(g, 540, 1230, (t * 1.4) % 0.9, { r: 155, n: 12, w: 8, color: '#ffd23f' });
  txt(g, '37 KM PARABOLIC WING-SLAT FLASH → COAST GUARD GREEN FLARE', 540, 1420, { size: 28, weight: 800, color: '#fde047' });
}

// 10. CLASSIFIED ASSET 14B & OUTWARD-BLOWN FUSELAGE BOLTS TWIST
export function drawBiometricTwist(M, g, t, u) {
  drawHyperGrid(M, g, t, 'CLASSIFIED TWIST: ASSET 14B', 'TITANIUM CASE BIOMETRIC PLATE MATCHES HER SEAT 14B PASS', u);

  rrect(g, 90, 410, 900, 520, 32, { fill: '#1a1128', stroke: '#ef4444', lw: 5, shadow: { len: 100, a: 0.4 } });
  txt(g, 'HERMETICALLY SEALED TITANIUM CARGO (9.0 KG)', 540, 470, { size: 30, weight: 800, color: '#94a3b8' });
  rrect(g, 190, 525, 700, 260, 24, { fill: '#0f172a', stroke: '#ef4444', lw: 4 });
  const pulse = 0.5 + 0.5 * Math.sin(t * 9);
  circle(g, 280, 655, 36, { fill: '#ef4444', glow: { r: 85 * pulse, color: '#ef4444', a: 0.85 } });
  txt(g, 'BIOMETRIC ID: SEAT 14B', 575, 625, { size: 46, weight: 900, color: '#ffd23f' });
  txt(g, '"PAID $50 TO SWITCH FROM ROW 6"', 575, 695, { size: 28, weight: 700, font: FONT.body, color: '#fca5a5' });
  txt(g, 'FUSELAGE LATCH BOLTS: BLOWN OUTWARD BEFORE TAKEOFF', 540, 860, { size: 30, weight: 800, color: '#ef4444' });

  // Final interactive dilemma cards (y = 975..1480)
  rrect(g, 90, 980, 430, 490, 28, { fill: '#13243a', stroke: '#38bdf8', lw: 4 });
  txt(g, 'OPTION A', 305, 1055, { size: 32, weight: 800, color: '#38bdf8' });
  txt(g, 'BOARD THE', 305, 1175, { size: 44, weight: 800, color: '#ffffff' });
  txt(g, 'HELICOPTER', 305, 1235, { size: 44, weight: 800, color: '#ffd23f' });
  txt(g, 'WITH COMMANDER', 305, 1320, { size: 26, weight: 700, font: FONT.body, color: '#94a3b8' });

  rrect(g, 560, 980, 430, 490, 28, { fill: '#122b24', stroke: '#22c55e', lw: 4 });
  txt(g, 'OPTION B', 775, 1055, { size: 32, weight: 800, color: '#22c55e' });
  txt(g, 'RUN BACK', 775, 1175, { size: 44, weight: 800, color: '#ffffff' });
  txt(g, 'INTO JUNGLE', 775, 1235, { size: 44, weight: 800, color: '#86efac' });
  txt(g, 'WITH YOUR CRUSH', 775, 1320, { size: 26, weight: 700, font: FONT.body, color: '#94a3b8' });
}

export const HYPER_CARDS = {
  search_radar:     drawSearchRadar,
  rule_of_threes:   drawRuleOfThrees,
  kidney_osmosis:   drawKidneyOsmosis,
  parabolic_mirror: drawParabolicMirror,
  coconut_mpa:      drawCoconutMpa,
  refraction_spear: drawRefractionSpear,
  solar_still:      drawSolarStill,
  cyclone_surge:    drawCycloneSurge,
  archimedes_lever: drawArchimedesLever,
  biometric_twist:  drawBiometricTwist,
};
