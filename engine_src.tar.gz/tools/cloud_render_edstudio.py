#!/usr/bin/env python3
"""Zero-Storage 20-Runner EDStudio Cloud Render & Google Drive Delivery Pipeline.
Supports:
  python3 tools/cloud_render_edstudio.py 90s   -> Renders 12-frame proof sheet + 90s vertical slice, uploads both to Drive, wipes cache
  python3 tools/cloud_render_edstudio.py full  -> Renders full 10-minute (620.433s) movie across 20 runners, uploads to Drive, wipes cache
"""
from __future__ import annotations

import base64
import os
import subprocess
import sys
import tarfile
import time
from pathlib import Path

sys.path.insert(0, "/data/data/com.termux/files/home/minecraft_whatif_engine")
sys.path.insert(0, "/data/data/com.termux/files/home")
import config  # noqa: E402
from tools.deliver_crush_island_10min import upload_file_to_composio_s3  # noqa: E402

ED_ROOT = Path("/data/data/com.termux/files/home/EDStudio")
OUT_DIR = ED_ROOT / "out"
SLUG = "087-crush-island-10min"
MIX_WAV = Path("/data/data/com.termux/files/home/minecraft_whatif_engine/public/episodes/crush-island-10min/mix.wav")

GH_CA = "ca_TLb6UOLTnfGH"
DRIVE_CA = "ca_20wgJd7IoZLu"
OWNER = "CaptainNahin"
REPO = "whatif-20runner-render"


def gh(tool: str, args: dict) -> dict:
    res = config.composio_execute(tool, args, connected_account_id=GH_CA, timeout=120)
    if not res.get("successful", True) and res.get("error"):
        raise RuntimeError(f"{tool} failed: {res.get('error')}")
    data = res.get("data") or {}
    return data.get("response_data") or data


def upload_and_share(local_path: Path) -> str:
    file_obj = upload_file_to_composio_s3(local_path, "GOOGLEDRIVE_UPLOAD_FILE")
    res = config.composio_execute(
        "GOOGLEDRIVE_UPLOAD_FILE",
        {"file_to_upload": file_obj},
        connected_account_id=DRIVE_CA,
        timeout=900,
    )
    data = (res.get("data") or {}).get("response_data") or res.get("data") or {}
    fid = data.get("id")
    if not fid:
        raise RuntimeError(f"Drive upload failed: {res}")
    try:
        config.composio_execute(
            "GOOGLEDRIVE_ADD_FILE_SHARING_PREFERENCE",
            {"file_id": fid, "role": "reader", "type": "anyone"},
            connected_account_id=DRIVE_CA,
            timeout=120,
        )
    except Exception:
        pass
    return f"https://drive.google.com/file/d/{fid}/view?usp=sharing"


def build_edstudio_tarball(out_tar: Path) -> None:
    out_tar.parent.mkdir(parents=True, exist_ok=True)
    files = [
        "package.json",
        f"videos/{SLUG}/story.json",
        f"videos/{SLUG}/shots.js",
        f"videos/{SLUG}/cues.json",
        f"videos/{SLUG}/caption.md",
    ]
    with tarfile.open(out_tar, "w:gz") as tf:
        for rel in files:
            p = ED_ROOT / rel
            if not p.exists():
                raise FileNotFoundError(f"Missing required EDStudio file: {p}")
            tf.add(p, arcname=rel)
        for folder in ("engine", "tools"):
            for dp, dns, fns in os.walk(ED_ROOT / folder):
                dns[:] = [d for d in dns if d != "__pycache__"]
                for fn in fns:
                    if fn.endswith((".pyc", ".log")):
                        continue
                    fp = Path(dp) / fn
                    tf.add(fp, arcname=str(fp.relative_to(ED_ROOT)))


def upsert_github_file(repo_path: str, raw_bytes: bytes, msg: str) -> None:
    args = {
        "owner": OWNER,
        "repo": REPO,
        "path": repo_path,
        "message": msg,
        "content": base64.b64encode(raw_bytes).decode("ascii"),
        "branch": "main",
    }
    try:
        existing = gh("GITHUB_GET_REPOSITORY_CONTENT", {"owner": OWNER, "repo": REPO, "path": repo_path, "ref": "main"})
        if isinstance(existing, dict) and existing.get("sha"):
            args["sha"] = existing["sha"]
    except Exception:
        pass
    gh("GITHUB_CREATE_OR_UPDATE_FILE_CONTENTS", args)


def wipe_local_cache(keep_proof: bool = False) -> None:
    subprocess.run(
        "rm -rf /tmp/remotion* /tmp/*.mp4 ~/EDStudio/out/*.mp4 ~/EDStudio/out/*.tar.gz ~/.cache/remotion* "
        "/data/data/com.termux/files/usr/tmp/*remotion* /data/data/com.termux/files/usr/tmp/.org.chromium* "
        "/data/data/com.termux/files/usr/tmp/puppeteer* ~/EDStudio/videos/*/stills/* ~/EDStudio/videos/*/out/*",
        shell=True,
    )
    if not keep_proof:
        subprocess.run("rm -rf ~/EDStudio/out/*", shell=True)


def run_pipeline(mode: str) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    dur_sec = "90" if mode == "90s" else "620.433"
    tag = "v4.0-edstudio-90s" if mode == "90s" else "v4.0-edstudio-full"

    tar_path = OUT_DIR / "engine_src.tar.gz"
    build_edstudio_tarball(tar_path)
    print(f"Built clean EDStudio payload: {tar_path} ({tar_path.stat().st_size / 1024:.1f} KB)", flush=True)
    upsert_github_file("engine_src.tar.gz", tar_path.read_bytes(), f"Upload EDStudio hybrid engine for {SLUG} ({mode})")
    upsert_github_file(
        ".github/workflows/render-episode.yml",
        (ED_ROOT / ".github" / "workflows" / "render-episode.yml").read_bytes(),
        "Deploy 20-runner EDStudio workflow",
    )
    tar_path.unlink(missing_ok=True)
    time.sleep(4)

    wfs_res = gh("GITHUB_LIST_REPOSITORY_WORKFLOWS", {"owner": OWNER, "repo": REPO})
    wf_list = wfs_res.get("workflows") or []
    wf = next((w for w in wf_list if str(w.get("path", "")).endswith("render-episode.yml")), wf_list[0])
    wf_id = int(wf["id"])

    print(f"Dispatching 20-runner EDStudio workflow (mode={mode}, duration_sec={dur_sec}, tag={tag})...", flush=True)
    gh(
        "GITHUB_CREATE_A_WORKFLOW_DISPATCH_EVENT",
        {
            "owner": OWNER,
            "repo": REPO,
            "workflow_id": wf_id,
            "ref": "main",
            "inputs": {
                "slug": SLUG,
                "workers": "20",
                "duration_sec": dur_sec,
                "release_tag": tag,
            },
        },
    )
    time.sleep(8)
    runs_res = gh("GITHUB_LIST_WORKFLOW_RUNS_FOR_A_REPOSITORY", {"owner": OWNER, "repo": REPO, "per_page": 5})
    run_id = runs_res["workflow_runs"][0]["id"]
    print(f"Tracking EDStudio 20-Runner Run #{run_id} ({mode})...", flush=True)

    for _ in range(360):
        jobs_res = gh("GITHUB_LIST_JOBS_FOR_A_WORKFLOW_RUN", {"owner": OWNER, "repo": REPO, "run_id": run_id, "per_page": 35})
        jobs = jobs_res.get("jobs") or []
        rchunks = [j for j in jobs if str(j.get("name", "")).startswith("render_chunk")]
        stitch_job = next((j for j in jobs if j.get("name") == "stitch"), None)
        rc_done = sum(1 for j in rchunks if j.get("status") == "completed" and j.get("conclusion") == "success")
        rc_fail = sum(1 for j in rchunks if j.get("status") == "completed" and j.get("conclusion") not in ("success", None))
        rc_prog = sum(1 for j in rchunks if j.get("status") == "in_progress")
        st_status = stitch_job.get("status") if stitch_job else "pending"
        st_conc = stitch_job.get("conclusion") if stitch_job else None
        print(
            f"[{time.strftime('%H:%M:%S')}] Run #{run_id}: render_chunk={rc_done}/{len(rchunks)} "
            f"(in_progress={rc_prog}, fail={rc_fail}), stitch={st_status}({st_conc})",
            flush=True,
        )
        if rc_fail > 0 and rc_prog == 0:
            raise RuntimeError(f"{rc_fail} render_chunk job(s) failed in Run #{run_id}")
        if st_status == "completed":
            if st_conc != "success":
                raise RuntimeError(f"stitch job failed: {st_conc}")
            break
        time.sleep(12)
    else:
        raise RuntimeError(f"Timed out waiting for Run #{run_id}")

    if mode == "90s":
        proof_url = f"https://github.com/{OWNER}/{REPO}/releases/download/{tag}/EDStudio_ToyLike_HyperBuilder_Proof.png"
        proof_png = OUT_DIR / "EDStudio_ToyLike_HyperBuilder_Proof.png"
        subprocess.run(["curl", "-fSL", "--retry", "3", "-o", str(proof_png), proof_url], check=True)
        proof_drive = upload_and_share(proof_png)
        print(f"EDSTUDIO_PROOF_DRIVE_URL={proof_drive}", flush=True)

        silent_url = f"https://github.com/{OWNER}/{REPO}/releases/download/{tag}/EDStudio_Silent_{tag}.mp4"
        silent_mp4 = OUT_DIR / f"EDStudio_Silent_{tag}.mp4"
        preview_mp4 = OUT_DIR / "EDStudio_Crush_Island_90s_Preview.mp4"
        subprocess.run(["curl", "-fSL", "--retry", "3", "-o", str(silent_mp4), silent_url], check=True)
        subprocess.run(
            [
                "ffmpeg", "-y", "-v", "error",
                "-i", str(silent_mp4),
                "-t", "90", "-i", str(MIX_WAV),
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
                "-movflags", "+faststart",
                str(preview_mp4),
            ],
            check=True,
        )
        silent_mp4.unlink(missing_ok=True)
        preview_drive = upload_and_share(preview_mp4)
        print(f"EDSTUDIO_90S_PREVIEW_DRIVE_URL={preview_drive}", flush=True)
        wipe_local_cache(keep_proof=True)
    else:
        silent_url = f"https://github.com/{OWNER}/{REPO}/releases/download/{tag}/EDStudio_Silent_{tag}.mp4"
        silent_mp4 = OUT_DIR / f"EDStudio_Silent_{tag}.mp4"
        full_mp4 = OUT_DIR / "EDStudio_Crush_Island_10min_Full.mp4"
        subprocess.run(["curl", "-fSL", "--retry", "3", "-o", str(silent_mp4), silent_url], check=True)
        subprocess.run(
            [
                "ffmpeg", "-y", "-v", "error",
                "-i", str(silent_mp4),
                "-i", str(MIX_WAV),
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
                "-movflags", "+faststart",
                str(full_mp4),
            ],
            check=True,
        )
        silent_mp4.unlink(missing_ok=True)
        full_drive = upload_and_share(full_mp4)
        print(f"EDSTUDIO_10MIN_FULL_DRIVE_URL={full_drive}", flush=True)
        wipe_local_cache(keep_proof=False)


if __name__ == "__main__":
    mode_arg = sys.argv[1] if len(sys.argv) > 1 else "90s"
    run_pipeline(mode_arg)
