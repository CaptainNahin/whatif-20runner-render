// Episode voice pipeline.
//   node tools/episode.mjs sections <slug>          split narration into TTS sections → sections.json (+ prints the calls to make)
//   node tools/episode.mjs fetch <slug> [s01=<url>…] download Fish audio (or auto-synthesize via Google Cloud TTS when no URLs given), trim/level it → vo/sNN.wav
//   node tools/episode.mjs tts <slug>               end-to-end Google Cloud TTS synthesis + pace + word alignment → timing.json
//   node tools/episode.mjs align <slug>             Whisper (or FFmpeg silence + char-weighted fallback) word timing → timing.json
//   node tools/episode.mjs draft <slug>             estimated timing (180 wpm) for previewing before any voice exists
//   node tools/episode.mjs script <slug>            readable script.md (speakers, timestamps) to show the user before voicing
//   node tools/episode.mjs pace <slug>              re-level/re-pace downloaded sections without new TTS calls
// Files live in public/episodes/<slug>/.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const [cmd, slug, ...rest] = process.argv.slice(2);
if (!cmd || !slug) {
  console.error('usage: node tools/episode.mjs <sections|fetch|tts|align|draft|script|pace> <slug> [...]');
  process.exit(1);
}
const DIR = path.join(ROOT, 'public', 'episodes', slug);
const read = f => JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
const write = (f, o) => fs.writeFileSync(path.join(DIR, f), JSON.stringify(o, null, 1));
const ep = read('episode.json');
const FPS = ep.fps || 30;
const DEFAULT_DIRECTION = '[calm, warm storyteller, unhurried, relaxed pace, gentle pauses between sentences]';
// House voices (Fish, drama-3) + Google Cloud TTS automatic fallback mapping.
export const HOUSE_VOICES = {
  narrator: '5c8dc6a69c0b4edfb32634db6384bf34', // Warm Storyteller -> gcloud en-US-Journey-D / en-US-Neural2-D
  male: '23c536451dd94b70b0d4ab0e8a630e1d', // "Teen" -> gcloud en-US-Neural2-D (pitch +1.5)
  female: '933563129e564b19a115bedd57b7406a', // "Sarah" -> gcloud en-US-Journey-F / en-US-Neural2-F
};
const MAX_CHARS = 1400;

/** Spoken words only: drop Fish [directions] and <tags>. */
const spoken = s => (s || '').replace(/\[[^\]]*\]/g, ' ').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
const norm = s => s.toLowerCase().replace(/[’']/g, "'").replace(/[^a-z0-9' ]+/g, ' ').trim();
const toks = s => norm(spoken(s).replace(/-/g, ' ')).split(/\s+/).filter(Boolean);

function buildSections() {
  const sections = [];
  let cur = null, breakNext = false, lastWho = null;
  const split = !ep.voice.mixSpeakers;
  ep.shots.forEach((shot, i) => {
    const text = spoken(shot.vo);
    if (!text) {
      breakNext = true;
      return;
    }
    const who = shot.who || 'narrator';
    if (split && who !== lastWho) breakNext = true;
    lastWho = who;
    if (!cur || breakNext || cur.chars + shot.vo.length > MAX_CHARS) {
      cur = { id: `s${String(sections.length + 1).padStart(2, '0')}`, shots: [], parts: [], chars: 0 };
      sections.push(cur);
      breakNext = false;
    }
    cur.shots.push(i);
    cur.parts.push({ who, text: shot.vo.trim() });
    cur.chars += shot.vo.length + 1;
    if (shot.hold > 0) breakNext = true;
  });
  const voices = { ...HOUSE_VOICES, narrator: ep.voice.id, ...(ep.voices || {}) };
  const direction = ep.voice.direction || DEFAULT_DIRECTION;
  return sections.map(s => {
    const whos = [...new Set(s.parts.map(p => p.who))];
    let text;
    if (whos.length === 1) {
      text = (s.parts[0].text.startsWith('[') || whos[0] !== 'narrator' ? '' : direction + ' ') + s.parts.map(p => p.text).join(' ');
    } else {
      let last = null;
      text = s.parts.map(p => {
        const idx = whos.indexOf(p.who);
        const head = p.who !== last ? `<|speaker:${idx}|>` + (p.who === 'narrator' && !p.text.startsWith('[') ? direction + ' ' : '') : ' ';
        last = p.who;
        return head + p.text;
      }).join('');
    }
    return { id: s.id, shots: s.shots, who: whos.length === 1 ? whos[0] : 'narrator', voice_id: whos.length === 1 ? voices[whos[0]] : whos.map(w => voices[w]), model: ep.voice.model || 'drama-3', text, url: null, file: null };
  });
}

function sh(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { encoding: 'utf8', maxBuffer: 1 << 30, ...opts });
  if (r.status !== 0) {
    console.error(r.stderr);
    process.exit(1);
  }
  return r;
}

async function download(url, out) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`download failed ${res.status} ${url}`);
  fs.writeFileSync(out, Buffer.from(await res.arrayBuffer()));
}

/** Synthesize a section via Google Cloud Text-to-Speech API when Fish Audio MCP is not connected. */
let gcloudToken = null;
function getGcloudToken() {
  if (gcloudToken) return gcloudToken;
  const r = spawnSync('gcloud', ['auth', 'print-access-token'], { encoding: 'utf8' });
  if (r.status !== 0 || !r.stdout.trim()) {
    throw new Error('gcloud auth print-access-token failed: ' + (r.stderr || 'no token'));
  }
  gcloudToken = r.stdout.trim();
  return gcloudToken;
}

function pickGcloudVoice(s) {
  const who = s.who || (s.shots?.length ? ep.shots[s.shots[0]]?.who : null) || 'narrator';
  const vid = Array.isArray(s.voice_id) ? s.voice_id[0] : s.voice_id;
  if (who === 'female' || who === 'crush' || who === 'sister' || who === 'teacher' || vid === HOUSE_VOICES.female || String(vid).includes('Journey-F') || String(vid).includes('Neural2-F')) {
    return {
      primary: { languageCode: 'en-US', name: 'en-US-Journey-F', ssmlGender: 'FEMALE' },
      fallback: { languageCode: 'en-US', name: 'en-US-Neural2-F', ssmlGender: 'FEMALE' },
      rate: 1.02,
      pitch: 0.0,
      role: 'female',
      edgeVoice: 'en-US-AriaNeural',
      edgeRate: '+2%',
      edgePitch: '+2Hz',
    };
  }
  if (who === 'male' || vid === HOUSE_VOICES.male) {
    return {
      primary: { languageCode: 'en-US', name: 'en-US-Neural2-J', ssmlGender: 'MALE' },
      fallback: { languageCode: 'en-US', name: 'en-US-Wavenet-J', ssmlGender: 'MALE' },
      rate: 1.02,
      pitch: -1.5,
      role: 'male',
      edgeVoice: 'en-US-GuyNeural',
      edgeRate: '+2%',
      edgePitch: '-6Hz',
    };
  }
  // Deep, clear, charismatic male narrator voice at natural conversational pace (speakingRate: 1.02, pitch: -3.0 semitones)
  return {
    primary: { languageCode: 'en-US', name: 'en-US-Neural2-D', ssmlGender: 'MALE' },
    fallback: { languageCode: 'en-US', name: 'en-US-Studio-Q', ssmlGender: 'MALE' },
    rate: 1.02,
    pitch: -3.0,
    role: 'narrator',
    edgeVoice: 'en-US-ChristopherNeural',
    edgeRate: '+2%',
    edgePitch: '-10Hz',
  };
}

async function synthesizeGcloudSection(s, mp3Out) {
  const cleanText = spoken(s.text);
  const v = pickGcloudVoice(s);
  const projects = [
    process.env.GOOGLE_CLOUD_PROJECT,
    'quantedge-worker-prod',
    'echoes-of-us-503117',
    'medibridge-y97a4',
    'earnest-chimera-467611-i8',
    'potent-clarity-472311-e7',
  ].filter(Boolean);

  let token = null;
  try {
    token = getGcloudToken();
  } catch {
    token = null;
  }

  if (token) {
    for (const proj of [...new Set(projects)]) {
      const callApi = async (voiceSpec, usePitch) => {
        const audioConfig = {
          audioEncoding: 'MP3',
          speakingRate: v.rate,
          sampleRateHertz: 24000,
          ...(usePitch && v.pitch ? { pitch: v.pitch } : {}),
        };
        return fetch('https://texttospeech.googleapis.com/v1/text:synthesize', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
            'x-goog-user-project': proj,
          },
          body: JSON.stringify({
            input: { text: cleanText },
            voice: voiceSpec,
            audioConfig,
          }),
        });
      };
      let usedVoice = v.primary.name;
      let res = await callApi(v.primary, !v.primary.name.includes('Journey'));
      if (!res.ok && res.status !== 403) {
        usedVoice = v.fallback.name;
        res = await callApi(v.fallback, true);
      }
      if (res.ok) {
        const data = await res.json();
        fs.writeFileSync(mp3Out, Buffer.from(data.audioContent, 'base64'));
        return `gcloud://${proj}/${usedVoice}`;
      }
    }
  }

  // Neural TTS fallback via .venv/bin/edge-tts (deep male en-US-ChristopherNeural @ -14% rate, -18Hz pitch)
  const edgeBin = path.join(ROOT, '.venv', 'bin', 'edge-tts');
  if (fs.existsSync(edgeBin)) {
    const r = spawnSync(
      edgeBin,
      [
        '--text', cleanText,
        '--voice', v.edgeVoice,
        `--rate=${v.edgeRate}`,
        `--pitch=${v.edgePitch}`,
        '--write-media', mp3Out,
      ],
      { encoding: 'utf8' }
    );
    if (r.status === 0 && fs.existsSync(mp3Out) && fs.statSync(mp3Out).size > 256) {
      return `neural-male-tts://${v.primary.name}/${v.edgeVoice}`;
    }
  }

  // Last-resort HTTPS TTS endpoint if edge-tts is unavailable
  const rawSentences = cleanText.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [cleanText];
  const chunks = [];
  for (const sent of rawSentences) {
    const t = sent.trim();
    if (!t) continue;
    if (t.length <= 180) chunks.push(t);
    else {
      const words = t.split(/\s+/);
      let cur = '';
      for (const w of words) {
        if ((cur + ' ' + w).trim().length > 180) {
          if (cur) chunks.push(cur);
          cur = w;
        } else cur = (cur + ' ' + w).trim();
      }
      if (cur) chunks.push(cur);
    }
  }
  const bufs = [];
  for (const ch of chunks) {
    const u = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q=${encodeURIComponent(ch)}`;
    const r = await fetch(u, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (!r.ok) throw new Error(`Fallback TTS failed (${r.status})`);
    bufs.push(Buffer.from(await r.arrayBuffer()));
  }
  fs.writeFileSync(mp3Out, Buffer.concat(bufs));
  return `gcloud-fallback://${v.primary.name}`;
}

function processVoice(src, dst, tempoOverride) {
  // Natural conversational pace (tempoRange [0.96, 1.05]) and crisp 0.22s sentence pauses
  const rawTempo = tempoOverride ?? ep.voice.tempo ?? 1.0;
  const tempo = Math.min(1.05, Math.max(0.92, rawTempo));
  const maxPause = ep.voice.maxPause ?? 0.25;
  const af = [
    'silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.03',
    'areverse', 'silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05', 'areverse',
    `silenceremove=stop_periods=-1:stop_duration=${maxPause}:stop_threshold=-42dB:stop_silence=0.22`,
    ...(Math.abs(tempo - 1.0) > 0.005 ? [`atempo=${tempo}`] : []),
    'loudnorm=I=-16:TP=-1.5:LRA=9',
    'afade=t=in:d=0.015',
  ].join(',');
  sh('ffmpeg', ['-y', '-v', 'error', '-i', src, '-af', af, '-ar', '48000', '-ac', '1', dst]);
}

function pace(s) {
  const mp3 = path.join(DIR, 'vo', `${s.id}.mp3`), wav = path.join(DIR, 'vo', `${s.id}.wav`);
  processVoice(mp3, wav, 1.0, s);
  const words = toks(s.text).length;
  const wpm = words / (durOf(wav) / 60);
  const target = ep.voice.targetWpm ?? 176;
  const [lo, hi] = ep.voice.tempoRange ?? [0.96, 1.05];
  const tempo = ep.voice.tempo ?? (words < 3 ? 1 : Math.min(hi, Math.max(lo, target / wpm)));
  if (Math.abs(tempo - 1.0) > 0.005) processVoice(mp3, wav, tempo, s);
  s.tempo = +tempo.toFixed(3);
  console.log(`${s.id}: ${durOf(wav).toFixed(2)} s  (${wpm.toFixed(0)} wpm read → ×${tempo.toFixed(2)} → ${(wpm * tempo).toFixed(0)} wpm)`);
}

const durOf = f => parseFloat(sh('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', f]).stdout);

/** Whisper word timestamps for one wav, transcribed in < 25 s pieces split at pauses. */
async function transcribe(asr, wav) {
  const pcm = sh('ffmpeg', ['-v', 'error', '-i', wav, '-f', 'f32le', '-ac', '1', '-ar', '16000', '-'], { encoding: 'buffer' }).stdout;
  const audio = new Float32Array(pcm.buffer, pcm.byteOffset, pcm.byteLength / 4);
  const dur = audio.length / 16000;
  const sd = sh('ffmpeg', ['-v', 'info', '-i', wav, '-af', 'silencedetect=n=-40dB:d=0.15', '-f', 'null', '-']).stderr;
  const gaps = [...sd.matchAll(/silence_start: ([\d.]+)[\s\S]*?silence_end: ([\d.]+)/g)].map(m => (parseFloat(m[1]) + parseFloat(m[2])) / 2);
  const cuts = [0];
  while (dur - cuts[cuts.length - 1] > 20) {
    const c0 = cuts[cuts.length - 1];
    const cand = gaps.filter(g => g > c0 + 6 && g < c0 + 20);
    const late = gaps.filter(g => g > c0 + 6 && g < c0 + 24);
    cuts.push(cand.length ? cand[cand.length - 1] : late.length ? late[late.length - 1] : c0 + 24);
  }
  cuts.push(dur);
  const words = [];
  for (let i = 0; i < cuts.length - 1; i++) {
    const a = Math.floor(cuts[i] * 16000), b = Math.floor(cuts[i + 1] * 16000);
    if (b - a < 1600) continue;
    const out = await asr(audio.slice(a, b), { return_timestamps: 'word' });
    for (const c of out.chunks) {
      const w = numbersToWords(norm(c.text.replace(/,(?=\d{3})/g, '')));
      if (w) words.push({ w, t0: cuts[i] + c.timestamp[0], t1: cuts[i] + (c.timestamp[1] ?? c.timestamp[0] + 0.3) });
    }
  }
  return { words, dur };
}

/** Deterministic FFmpeg silencedetect + character-weighted word aligner for platforms without onnxruntime-node (e.g. Android Termux). */
function alignFromAudioEnvelope(sw, wav, dur) {
  const sd = sh('ffmpeg', ['-v', 'info', '-i', wav, '-af', 'silencedetect=n=-38dB:d=0.08', '-f', 'null', '-']).stderr;
  const silences = [...sd.matchAll(/silence_start: ([\d.]+)[\s\S]*?silence_end: ([\d.]+)/g)].map(m => [parseFloat(m[1]), parseFloat(m[2])]);
  // Build active speech spans [a, b]
  const spans = [];
  let cur = 0.02;
  for (const [s0, s1] of silences) {
    if (s0 > cur + 0.02) spans.push([cur, s0]);
    cur = Math.max(cur, s1);
  }
  if (dur > cur + 0.02) spans.push([cur, Math.max(cur + 0.05, dur - 0.02)]);
  if (!spans.length) spans.push([0.02, Math.max(0.1, dur - 0.02)]);

  const totalSpeech = spans.reduce((acc, [a, b]) => acc + (b - a), 0);
  const weights = sw.map(w => Math.max(2.2, w.length));
  const totalWeight = weights.reduce((a, b) => a + b, 0) || 1;

  const T = [];
  let wCum = 0;
  for (let i = 0; i < sw.length; i++) {
    const targetSpeechTime = (wCum / totalWeight) * totalSpeech;
    let rem = targetSpeechTime;
    let tWord = spans[0][0];
    for (const [sa, sb] of spans) {
      const len = sb - sa;
      if (rem <= len + 1e-6) {
        tWord = sa + rem;
        break;
      }
      rem -= len;
      tWord = sb;
    }
    T.push(Math.min(dur - 0.02, Math.max(0, tWord)));
    wCum += weights[i];
  }
  return { T, unmatched: [] };
}

const ONES = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
const TENS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
function say(n) {
  if (n < 20) return ONES[n];
  if (n < 100) return TENS[Math.floor(n / 10)] + (n % 10 ? ' ' + ONES[n % 10] : '');
  if (n < 1000) return ONES[Math.floor(n / 100)] + ' hundred' + (n % 100 ? ' and ' + say(n % 100) : '');
  for (const [v, w] of [[1e9, 'billion'], [1e6, 'million'], [1e3, 'thousand']]) if (n >= v) return say(Math.floor(n / v)) + ' ' + w + (n % v ? ' ' + say(n % v) : '');
  return String(n);
}
function numbersToWords(s) {
  return s.replace(/\b(\d+)(x)?\b/g, (_, d, x) => (d.length > 12 ? d : say(parseInt(d, 10))) + (x ? ' times' : ''));
}

function alignWords(scriptWords, heard, dur) {
  const hw0 = heard.flatMap(h => h.w.split(/\s+/).map(w => ({ ...h, w })));
  const sset = new Set(scriptWords), hw = [];
  for (let j = 0; j < hw0.length; j++) {
    const pair = j + 1 < hw0.length ? hw0[j].w + hw0[j + 1].w : '';
    if (pair && sset.has(pair) && !sset.has(hw0[j].w)) { hw.push({ ...hw0[j], w: pair }); j++; }
    else hw.push(hw0[j]);
  }
  const n = scriptWords.length, m = hw.length;
  const D = Array.from({ length: n + 1 }, () => new Float32Array(m + 1));
  for (let i = 0; i <= n; i++) D[i][0] = i;
  for (let j = 0; j <= m; j++) D[0][j] = j;
  const sub = (a, b) => (a === b ? 0 : a.slice(0, 3) === b.slice(0, 3) ? 0.4 : 1);
  for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++)
    D[i][j] = Math.min(D[i - 1][j - 1] + sub(scriptWords[i - 1], hw[j - 1].w), D[i - 1][j] + 1, D[i][j - 1] + 1);
  const match = new Array(n).fill(-1);
  for (let i = n, j = m; i > 0 && j > 0;) {
    if (D[i][j] === D[i - 1][j - 1] + sub(scriptWords[i - 1], hw[j - 1].w)) { match[i - 1] = j - 1; i--; j--; }
    else if (D[i][j] === D[i - 1][j] + 1) i--;
    else j--;
  }
  const T = scriptWords.map((_, i) => (match[i] >= 0 ? hw[match[i]].t0 : null));
  for (let i = 0; i < n; i++) if (T[i] === null) {
    let a = i - 1; while (a >= 0 && T[a] === null) a--;
    let b = i + 1; while (b < n && T[b] === null) b++;
    const ta = a >= 0 ? T[a] : 0, tb = b < n ? T[b] : dur;
    T[i] = ta + ((tb - ta) * (i - a)) / (b - a);
  }
  return { T, unmatched: scriptWords.filter((_, i) => match[i] < 0) };
}

function layout(sections, sectionDur, shotOffset) {
  const LEAD = 0.12;
  const shots = ep.shots.map(() => ({ start: 0, dur: 0, section: null }));
  const secOf = {};
  sections.forEach((s, k) => s.shots.forEach(i => (secOf[i] = k)));
  const secStart = [];
  let cursor = 0.3;
  ep.shots.forEach((shot, i) => {
    const k = secOf[i];
    if (k === undefined) {
      shots[i] = { start: cursor, dur: shot.hold || 1.5, section: null };
      cursor += shots[i].dur;
      return;
    }
    const s = sections[k];
    const firstInSec = s.shots[0] === i;
    const preGap = ep.voice?.preGap ?? 0.04;
    const postGap = Math.max(shot.hold ?? 0.10, 0.08);
    if (firstInSec) secStart[k] = cursor + preGap;
    const start = firstInSec ? cursor : Math.max(shots[i - 1].start + 1.05, secStart[k] + shotOffset[i] - LEAD);
    shots[i] = { start, dur: 0, section: k };
    if (s.shots[s.shots.length - 1] === i) cursor = secStart[k] + sectionDur[k] + postGap;
    else cursor = start;
  });
  const snap = s => Math.round(s * FPS) / FPS;
  shots.forEach(s => (s.start = snap(s.start)));
  ep.shots.forEach((_, i) => {
    const next = i + 1 < shots.length ? shots[i + 1].start : snap(cursor + 0.4);
    shots[i].dur = +(next - shots[i].start).toFixed(4);
    shots[i].start = +shots[i].start.toFixed(4);
  });
  const total = +(shots[shots.length - 1].start + shots[shots.length - 1].dur).toFixed(3);
  return { fps: FPS, total, shots, sections: sections.map((s, k) => ({ file: `episodes/${slug}/vo/${s.id}.wav`, start: +(secStart[k] ?? 0).toFixed(3), dur: +sectionDur[k].toFixed(3) })) };
}

async function runSections() {
  const secs = buildSections();
  const old = fs.existsSync(path.join(DIR, 'sections.json')) ? read('sections.json') : [];
  secs.forEach(s => {
    const o = old.find(x => x.id === s.id && x.text === s.text);
    if (o) Object.assign(s, { url: o.url, file: o.file });
  });
  write('sections.json', secs);
  const bytes = secs.reduce((a, s) => a + Buffer.byteLength(s.text), 0);
  console.log(`${secs.length} sections, ${bytes} bytes (~${bytes} Fish credits), ${ep.shots.length} shots`);
  secs.forEach(s => console.log(`${s.id}  shots ${s.shots[0]}–${s.shots[s.shots.length - 1]}  ${Buffer.byteLength(s.text)} B  ${s.url ? 'HAS AUDIO' : 'needs TTS'}`));
  return secs;
}

async function runFetch(urlArgs) {
  const secs = fs.existsSync(path.join(DIR, 'sections.json')) ? read('sections.json') : await runSections();
  fs.mkdirSync(path.join(DIR, 'vo'), { recursive: true });
  if (urlArgs.length > 0) {
    for (const arg of urlArgs) {
      const [id, url] = arg.split(/=(.+)/);
      const s = secs.find(x => x.id === id);
      if (!s) throw new Error('unknown section ' + id);
      const mp3 = path.join(DIR, 'vo', `${id}.mp3`);
      await download(url, mp3);
      Object.assign(s, { url, file: `vo/${id}.wav` });
      pace(s);
    }
  } else {
    console.log('Fish Audio URLs not provided — synthesizing sections via Google Cloud TTS...');
    for (const s of secs) {
      const mp3 = path.join(DIR, 'vo', `${s.id}.mp3`);
      const wav = path.join(DIR, 'vo', `${s.id}.wav`);
      if (!s.file || !fs.existsSync(wav)) {
        const uri = await synthesizeGcloudSection(s, mp3);
        Object.assign(s, { url: uri, file: `vo/${s.id}.wav` });
        pace(s);
      }
    }
  }
  write('sections.json', secs);
}

async function runAlign() {
  const secs = read('sections.json');
  const missing = secs.filter(s => !s.file || !fs.existsSync(path.join(DIR, s.file)));
  if (missing.length) {
    console.error('sections without audio: ' + missing.map(s => s.id).join(' '));
    process.exit(1);
  }
  let asr = null;
  try {
    const { pipeline } = await import('@huggingface/transformers');
    asr = await pipeline('automatic-speech-recognition', 'Xenova/whisper-small.en', { dtype: 'fp32' });
  } catch (e) {
    console.log('Whisper ASR unavailable on this platform (' + (e?.message || e).split('\n')[0] + ') — using FFmpeg silence-envelope word alignment.');
  }
  const sectionDur = [], shotOffset = {}, allWords = [];
  for (const [k, s] of secs.entries()) {
    const wav = path.join(DIR, s.file);
    sectionDur[k] = durOf(wav);
    const sw = [], owner = [];
    s.shots.forEach(i => toks(ep.shots[i].vo).forEach(w => { sw.push(w); owner.push(i); }));
    let T, unmatched;
    if (asr) {
      const { words, dur } = await transcribe(asr, wav);
      ({ T, unmatched } = alignWords(sw, words, dur));
    } else {
      ({ T, unmatched } = alignFromAudioEnvelope(sw, wav, sectionDur[k]));
    }
    s.shots.forEach(i => (shotOffset[i] = T[owner.indexOf(i)] ?? 0));
    allWords.push({ section: s.id, words: sw.map((w, j) => ({ w, t: +T[j].toFixed(3), shot: owner[j] })) });
    console.log(`${s.id}: ${sectionDur[k].toFixed(2)} s, ${sw.length} words` + (unmatched.length ? `, unmatched: ${unmatched.slice(0, 12).join(' ')}` : ''));
  }
  const timing = layout(secs, sectionDur, shotOffset);
  attachWords(timing, secs, allWords.map(x => x.words));
  write('timing.json', timing);
  write('words.json', allWords);
  report(timing);
}

if (cmd === 'sections') {
  await runSections();
} else if (cmd === 'fetch') {
  await runFetch(rest);
} else if (cmd === 'tts' || cmd === 'gcloud-tts') {
  await runSections();
  await runFetch([]);
  await runAlign();
} else if (cmd === 'pace') {
  const secs = read('sections.json');
  secs.filter(s => s.file && fs.existsSync(path.join(DIR, 'vo', `${s.id}.mp3`))).forEach(pace);
  write('sections.json', secs);
} else if (cmd === 'align') {
  await runAlign();
} else if (cmd === 'draft') {
  const secs = buildSections();
  const WPS = 3.0;
  const sectionDur = secs.map(s => s.shots.reduce((a, i) => a + toks(ep.shots[i].vo).length / WPS + 0.15, 0));
  const shotOffset = {};
  secs.forEach(s => {
    let acc = 0;
    s.shots.forEach(i => { shotOffset[i] = acc; acc += toks(ep.shots[i].vo).length / WPS + 0.15; });
  });
  const timing = layout(secs, sectionDur, shotOffset);
  timing.draft = true;
  attachWords(timing, secs, secs.map(sec => {
    const out = [];
    sec.shots.forEach(i => { let acc = shotOffset[i]; toks(ep.shots[i].vo).forEach(w => { out.push({ w, t: acc, shot: i }); acc += 1 / WPS; }); });
    return out;
  }));
  write('timing.json', timing);
  report(timing);
} else if (cmd === 'script') {
  const tm = fs.existsSync(path.join(DIR, 'timing.json')) ? read('timing.json') : null;
  const castNames = { ...(ep.cast || {}) };
  const out = [`# ${ep.title}`, '', tm ? `${tm.draft ? 'Draft timing' : 'Voiced timing'}: ${Math.floor(tm.total / 60)}:${String(Math.round(tm.total % 60)).padStart(2, '0')}` : '', ''];
  ep.shots.forEach((shot, i) => {
    if (!shot.vo) return;
    const talker = (shot.actors || []).find(a => a.talk);
    const name = shot.who ? (talker ? (castNames[talker.id]?.name || talker.id) : shot.who).toUpperCase() : talker?.id === 'hero' ? 'YOU' : null;
    const line = shot.vo.replace(new RegExp('^' + (ep.voice.direction || DEFAULT_DIRECTION).replace(/[[\]()]/g, '\\$&') + '\\s*'), '').replace(/\[([^\]]*)\]/g, '*[$1]*').trim();
    const ts = tm ? `\`${Math.floor(tm.shots[i].start / 60)}:${String(Math.floor(tm.shots[i].start % 60)).padStart(2, '0')}\` ` : '';
    out.push(name ? `${ts}> **${name}:** ${line}` : `${ts}${line}`, '');
  });
  fs.writeFileSync(path.join(DIR, 'script.md'), out.join('\n'));
  console.log(`script.md: ${ep.shots.filter(s => s.vo).length} lines`);
} else {
  console.error('unknown command ' + cmd);
  process.exit(1);
}

function attachWords(timing, secs, wordsPerSection) {
  secs.forEach((sec, k) => {
    const s0 = timing.sections[k].start;
    for (const w of wordsPerSection[k]) {
      const sh = timing.shots[w.shot];
      (sh.words ||= []).push([w.w, +(s0 + w.t - sh.start).toFixed(3)]);
    }
  });
}

function report(timing) {
  const short = timing.shots.map((s, i) => [i, s.dur]).filter(([, d]) => d < 0.8);
  console.log(`total ${timing.total.toFixed(1)} s (${(timing.total / 60).toFixed(2)} min), ${timing.shots.length} shots, avg ${(timing.total / timing.shots.length).toFixed(2)} s/shot`);
  if (short.length) console.log('very short shots (merge or extend): ' + short.map(([i, d]) => `#${i} ${d}s`).join(', '));
}
