#!/usr/bin/env python3
"""
Rebuilds public/episodes/crush-island-10min/episode.json with full 6-set adventure
choreography, 12 story props synced to @word cues, >=80% active 3D locomotion paths,
2-3 keyframed poses + IK reaches on every non-walking shot, anti-flow camera
choreography (>=50 deg angle shift + alternating shot types), and 2D Remotion
explainer cards every 6-7 shots.
"""
import json
import math
import re
from pathlib import Path

ROOT = Path("/data/data/com.termux/files/home/minecraft_whatif_engine")
EP_PATH = ROOT / "public/episodes/crush-island-10min/episode.json"
TM_PATH = ROOT / "public/episodes/crush-island-10min/timing.json"

ep = json.loads(EP_PATH.read_text())
tm = json.loads(TM_PATH.read_text())

shots = ep["shots"]
tm_shots = tm["shots"]
assert len(shots) == len(tm_shots), f"Mismatch: {len(shots)} vs {len(tm_shots)}"

# Extract clean alphanumeric words per shot for guaranteed @word cue resolution
def clean_words(idx):
    raw = tm_shots[idx].get("words", [])
    out = []
    seen = {}
    for w, t in raw:
        m = re.match(r"^([a-zA-Z0-9']+)$", w.strip())
        if not m:
            w_clean = re.sub(r"[^a-zA-Z0-9']", "", w)
        else:
            w_clean = m.group(1)
        if not w_clean:
            continue
        key = w_clean.lower()
        cnt = seen.get(key, 0) + 1
        seen[key] = cnt
        cue = f"@{key}" if cnt == 1 else f"@{key}#{cnt}"
        out.append((cue, key, float(t)))
    return out

# Card indices spaced every 6 to 7 shots (keeps index 118 as a 3D shot so @spark ignites fire/smoke!)
CARD_INDICES = {
    5, 12, 19, 25, 32, 39, 45, 52, 59, 65,
    72, 79, 85, 92, 99, 105, 112, 119, 126, 133,
    140, 147, 154, 161, 168, 175, 181
}

CARD_SPECS = [
    {"card": "stat", "value": 165000000, "unit": "KM² OCEAN", "label": "PACIFIC SEARCH AREA LARGER THAN ALL LANDMASSES", "icon": "globe"},
    {"card": "clock", "mode": "tick", "value": "72 HRS", "label": "RULE OF THREES DEHYDRATION LIMIT", "bar": True},
    {"card": "compare", "title": "KIDNEY OSMOSIS TRAP", "unit": "G/L SALT", "left": {"label": "SEAWATER", "value": 35, "icon": "warning"}, "right": {"label": "KIDNEY MAX", "value": 15, "icon": "heart"}},
    {"card": "rules", "title": "4 SALVAGED SURVIVAL ITEMS", "prefix": "ITEM", "rules": ["CURVED ALUMINUM WING SLAT", "1% SMARTPHONE LITHIUM CELL", "SEAT 14B BOARDING PASS", "LOCKED TITANIUM CARGO CASE"], "current": 1},
    {"card": "distance", "value": 37, "unit": "KILOMETERS", "label": "PARABOLIC WING SLAT FLASH RANGE", "count": 1, "target": "flag", "time": "12M CANDELA"},
    {"card": "chain", "title": "LITHIUM FIRE IGNITION", "nodes": [{"icon": "phone", "label": "1% BATTERY"}, {"icon": "lightning", "label": "FOIL BRIDGE"}, {"icon": "warning", "label": "410°C SPARK"}]},
    {"card": "stat", "value": 3400, "unit": "KCAL / DAY", "label": "SURVIVAL CALORIE BURN IN 33°C HEAT", "icon": "heart"},
    {"card": "compare", "title": "COCONUT HUSK FORCE", "unit": "KG FORCE", "left": {"label": "DROP IMPACT", "value": 45, "icon": "fall"}, "right": {"label": "WEDGE SPLIT", "value": 180, "icon": "muscle"}},
    {"card": "distance", "value": 25, "unit": "% AIM SHIFT", "label": "SNELL'S LAW WATER REFRACTION (N = 1.333)", "count": 3, "time": "AIM LOWER"},
    {"card": "rules", "title": "A-FRAME SHELTER GEOMETRY", "prefix": "RULE", "rules": ["45° RIDGEPOLE SHEDS TROPICAL RAIN", "30 CM RAISED BED BLOCKS SAND CRABS", "INTERLOCKED PALM FROND SHINGLES"], "current": 1},
    {"card": "chain", "title": "SOLAR STILL DISTILLATION", "nodes": [{"icon": "globe", "label": "SOLAR HEAT"}, {"icon": "arrow", "label": "VAPOR CONE"}, {"icon": "check", "label": "1.4 L PURE WATER"}]},
    {"card": "clock", "mode": "slow", "value": "96 HRS", "label": "NIGHT 4 SURVIVAL MILESTONE REACHED", "bar": True},
    {"card": "stat", "value": 14, "unit": "SEAT 14B", "label": "SHE TRADED SEAT 22A JUST TO SIT BESIDE YOU", "icon": "heart"},
    {"card": "distance", "value": 400, "unit": "KILOMETERS", "label": "OUTSIDE COMMERCIAL SHIPPING LANES", "count": 1, "target": "globe", "time": "ZERO SHIPS"},
    {"card": "clock", "mode": "fast", "value": "12 HRS", "label": "CATEGORY 4 CYCLONE CLOSING AT 220 KM/H", "bar": True},
    {"card": "compare", "title": "CYCLONE PRESSURE DROP", "unit": "HPA", "left": {"label": "NORMAL SEA", "value": 1013, "icon": "globe"}, "right": {"label": "CAT-4 CORE", "value": 938, "icon": "warning"}, "lowerWins": True},
    {"card": "rules", "title": "STORM SURGE PHYSICS", "prefix": "STAGE", "rules": ["1.8 M BAROMETRIC OCEAN DOME", "BEACH CAMP FLOODS IN 18 MINUTES", "VOLCANIC RIDGE IS ONLY SAFE GROUND"], "current": 2},
    {"card": "chain", "title": "4-STEP PHYSICS CLIMAX", "nodes": [{"icon": "muscle", "label": "4:1 LEVER"}, {"icon": "lightning", "label": "410°C SPARK"}, {"icon": "flag", "label": "37 KM FLASH"}]},
    {"card": "clock", "mode": "freeze", "value": "180 SEC", "label": "3-MINUTE TURBOPROP VISUAL WINDOW", "bar": True},
    {"card": "compare", "title": "TRAPPED FOOT DILEMMA", "unit": "KG LOAD", "left": {"label": "DEADLIFT MAX", "value": 75, "icon": "muscle"}, "right": {"label": "WRECKAGE BEAM", "value": 165, "icon": "warning"}},
    {"card": "stat", "value": 180, "unit": "KG TORQUE", "label": "ARCHIMEDES 4:1 DRIFTWOOD LEVER LIFT", "icon": "muscle"},
    {"card": "chain", "title": "THERMAL SPARK IGNITION", "nodes": [{"icon": "phone", "label": "15 WH CELL"}, {"icon": "lightning", "label": "FOIL SHORT"}, {"icon": "check", "label": "ROARING FLAME"}]},
    {"card": "compare", "title": "SIGNAL RANGE", "unit": "KM RANGE", "left": {"label": "STEAM SMOKE", "value": 18, "icon": "flag"}, "right": {"label": "WING MIRROR", "value": 37, "icon": "lightning"}},
    {"card": "distance", "value": 37, "unit": "KILOMETERS", "label": "SUNBEAM LOCKS ONTO COCKPIT WINDSCREEN", "count": 1, "target": "check", "time": "16 SEC LEFT"},
    {"card": "stat", "value": 240, "unit": "SECONDS", "label": "COAST GUARD HELICOPTER SUMMIT APPROACH", "icon": "stopwatch"},
    {"card": "rules", "title": "CLASSIFIED CARGO ANOMALY", "prefix": "CLUE", "rules": ["ZERO SPECIAL CARGO ON MANIFEST", "BIOMETRIC TITANIUM CASE SURVIVED IMPACT", "PILOT RECOGNIZES SERIAL NUMBER"], "current": 3},
    {"card": "chain", "title": "THE FINAL MYSTERY", "nodes": [{"icon": "point", "label": "SEAT 14B SWITCH"}, {"icon": "warning", "label": "OFF-COURSE JET"}, {"icon": "question", "label": "STAGED CRASH?"}]},
]

# Helper to pick set for each 3D shot so sets rotate dynamically across the 6 adventure environments
def choose_set_and_time(idx):
    # Shot 118 must be cyclone_night_beach / survivor_camp with @spark fire/smoke
    if idx == 118:
        return "survivor_camp", "dusk"
    t_map = {
        "crash_surf": "morning",
        "survivor_camp": "afternoon",
        "jungle_interior": "afternoon",
        "volcanic_ridge": "day",
        "cyclone_night_beach": "dusk",
        "ridge_helipad": "golden",
    }
    if idx < 18:
        cycle = ["crash_surf", "jungle_interior", "crash_surf", "survivor_camp"]
        s = cycle[idx % len(cycle)]
        return s, t_map[s]
    elif idx < 46:
        cycle = ["crash_surf", "survivor_camp", "jungle_interior", "volcanic_ridge"]
        s = cycle[idx % len(cycle)]
        return s, t_map[s]
    elif idx < 82:
        cycle = ["jungle_interior", "survivor_camp", "crash_surf", "volcanic_ridge"]
        s = cycle[idx % len(cycle)]
        return s, t_map[s]
    elif idx < 95:
        cycle = ["survivor_camp", "crash_surf", "survivor_camp", "volcanic_ridge"]
        s = cycle[idx % len(cycle)]
        return s, ("golden" if s == "survivor_camp" else t_map[s])
    elif idx < 115:
        cycle = ["volcanic_ridge", "jungle_interior", "volcanic_ridge", "survivor_camp"]
        s = cycle[idx % len(cycle)]
        return s, t_map[s]
    elif idx < 162:
        cycle = ["cyclone_night_beach", "survivor_camp", "cyclone_night_beach", "volcanic_ridge"]
        s = cycle[idx % len(cycle)]
        return s, "dusk"
    else:
        cycle = ["ridge_helipad", "volcanic_ridge", "ridge_helipad", "cyclone_night_beach"]
        s = cycle[idx % len(cycle)]
        return s, ("golden" if s != "cyclone_night_beach" else "dusk")

# Story prop assignment per shot range (ensuring all 12 story props are held & spawned in scene)
def choose_props(idx, cues, set_name):
    cue_first = cues[0][0] if cues else 0.2
    cue_mid = cues[len(cues) // 2][0] if len(cues) > 1 else cue_first
    cue_last = cues[-1][0] if len(cues) > 2 else cue_mid

    # Explicit @spark shot at index 118
    if idx == 118:
        spark_cue = "@spark"
        for c, k, _ in cues:
            if k == "spark":
                spark_cue = c
                break
        return (
            {"R": "battery_cell", "L": "wing_slat"},
            {"R": "driftwood_lever"},
            [
                {"type": "fire", "pos": [0.1, 0, -1.5], "size": 0.65, "ignite": spark_cue},
                {"type": "smoke", "pos": [0.1, 0.2, -1.5], "size": 0.65, "h": 8.5, "ignite": spark_cue},
                {"type": "driftwood_lever", "pos": [-1.2, 0, -1.2]},
            ],
        )

    # Map ranges to the 12 required props so every prop appears multiple times synced to @word cues
    if idx < 18:
        # Waking up in crash_surf, finding smartphone & boarding_pass
        if idx % 3 == 0:
            return ({"R": "smartphone"}, {"R": "boarding_pass"}, [{"type": "titanium_case", "pos": [-1.4, 0, -1.3], "scale": 1.1}])
        elif idx % 3 == 1:
            return ({"R": "wing_slat"}, {"R": "smartphone"}, [{"type": "wing_slat", "pos": [-1.8, 0, -1.4]}])
        else:
            return ({"R": "boarding_pass"}, {"R": "titanium_case"}, [{"type": "boarding_pass", "pos": [-0.8, 0, -1.1]}])
    elif idx < 46:
        # Planting the 4 survival items: wing_slat, smartphone, boarding_pass, titanium_case + battery_cell
        mod = idx % 5
        if mod == 0:
            return ({"R": "wing_slat"}, {"R": "smartphone"}, [{"type": "wing_slat", "pos": [-1.5, 0, -1.4]}])
        elif mod == 1:
            return ({"R": "smartphone"}, {"R": "battery_cell"}, [{"type": "smartphone", "pos": [-1.1, 0, -1.2]}])
        elif mod == 2:
            return ({"R": "boarding_pass"}, {"R": "smartphone"}, [{"type": "boarding_pass", "pos": [0.9, 0, -1.2]}])
        elif mod == 3:
            return ({"R": "titanium_case"}, {"R": "wing_slat"}, [{"type": "titanium_case", "pos": [-1.3, 0, -1.4], "scale": 1.15}])
        else:
            return ({"R": "battery_cell"}, {"R": "boarding_pass"}, [{"type": "battery_cell", "pos": [0.0, 0, -1.3]}])
    elif idx < 64:
        # Coconuts & spearfishing
        if idx % 2 == 0:
            return ({"R": "coconut"}, {"R": "bamboo_pole"}, [{"type": "coconut", "pos": [-0.6, 0, -1.1], "scale": 1.2}])
        else:
            return ({"R": "spear"}, {"R": "coconut"}, [{"type": "spear", "pos": [1.1, 0, -1.2]}])
    elif idx < 84:
        # Building A-frame shelter with bamboo_pole & distilling water with solar_cup
        if idx % 2 == 0:
            return ({"R": "bamboo_pole"}, {"R": "palm_frond"}, [{"type": "bamboo_pole", "pos": [1.4, 0, -1.4]}])
        else:
            return ({"R": "solar_cup"}, {"R": "coconut"}, [{"type": "solar_cup", "pos": [-1.3, 0, -1.2], "scale": 1.25}])
    elif idx < 96:
        # Night 4 campfire high point: sharing solar_cup and Seat 14B boarding_pass
        if idx % 2 == 0:
            return ({"R": "solar_cup"}, {"R": "boarding_pass"}, [
                {"type": "fire", "pos": [0.1, 0, -1.8], "size": 0.52, "ignite": cue_first},
                {"type": "boarding_pass", "pos": [0.6, 0, -1.2]},
            ])
        else:
            return ({"R": "boarding_pass"}, {"R": "solar_cup"}, [
                {"type": "fire", "pos": [0.1, 0, -1.8], "size": 0.52},
                {"type": "solar_cup", "pos": [-0.6, 0, -1.2]},
            ])
    elif idx < 115:
        # Day 5 climbing volcanic_ridge with spear, bamboo_pole, wing_slat
        if idx % 2 == 0:
            return ({"R": "bamboo_pole"}, {"R": "spear"}, [{"type": "wing_slat", "pos": [-1.4, 0, -1.3]}])
        else:
            return ({"R": "wing_slat"}, {"R": "smartphone"}, [{"type": "bamboo_pole", "pos": [1.3, 0, -1.3]}])
    elif idx < 146:
        # Cyclone strikes & Archimedes 4:1 driftwood_lever freeing her foot
        return (
            {"R": "driftwood_lever"},
            {"R": "rescue_flare"},
            [
                {"type": "driftwood_lever", "pos": [0.4, 0, -0.8], "scale": 1.15},
                {"type": "wreckBeam", "pos": [1.3, 0, -0.7]},
            ],
        )
    elif idx < 154:
        # Short-circuiting battery_cell to ignite fire & smoke
        return (
            {"R": "battery_cell"},
            {"R": "palm_frond"},
            [
                {"type": "battery_cell", "pos": [0.0, 0, -1.3], "scale": 1.2},
                {"type": "fire", "pos": [0.1, 0, -1.5], "size": 0.72, "ignite": cue_mid},
                {"type": "smoke", "pos": [0.1, 0.2, -1.5], "size": 0.75, "h": 9.5, "ignite": cue_last},
            ],
        )
    elif idx < 162:
        # Aiming curved wing_slat on the tripod + rescue_flare
        return (
            {"R": "wing_slat"},
            {"R": "rescue_flare"},
            [
                {"type": "wing_slat", "pos": [-0.8, 0, -1.3], "scale": 1.15},
                {"type": "fire", "pos": [0.2, 0, -1.6], "size": 0.65},
                {"type": "smoke", "pos": [0.2, 0.2, -1.6], "size": 0.7, "h": 9.0},
                {"type": "rescue_flare", "pos": [1.1, 0, -1.2]},
            ],
        )
    else:
        # Act 4 Ridge helipad: rescue_flare & locked titanium_case twist
        return (
            {"R": "titanium_case"},
            {"R": "rescue_flare"},
            [
                {"type": "titanium_case", "pos": [-0.4, 0, -1.1], "scale": 1.2},
                {"type": "rescue_flare", "pos": [1.2, 0, -1.2]},
            ],
        )

# Grounded working pose triplets (all hipY = 0)
POSE_TRIPLETS = [
    ("determined", "reach", "holdOut"),
    ("focus", "examine", "point"),
    ("explain", "present", "confident"),
    ("shocked", "lookup", "pointUp"),
    ("thinking", "examine", "fistPump"),
    ("carry", "reach", "cheer"),
    ("talk", "holdOut", "point"),
    ("surprised", "focus", "determined"),
]

REACH_TARGETS = [
    "chest",
    "face",
    "hip",
    [-0.4, 1.15, 0.2],
    [0.4, 1.2, 0.2],
]

SHOT_CYCLE = ["establishing", "medium", "insert", "close", "wide", "full"]
ANGLE_CYCLE = [-50, 25, -30, 45, -15, 50, -40, 30]
GAIT_CYCLE = ["walk", "jog", "run", "walk", "jog", "walk", "run", "jog"]

card_cursor = 0
threed_cursor = 0

new_shots = []

for idx, (s, ts) in enumerate(zip(shots, tm_shots)):
    dur = float(ts.get("dur", 3.2))
    cues = clean_words(idx)
    w1 = cues[min(1, len(cues) - 1)][0] if cues else 0.3
    w2 = cues[min(max(2, len(cues) // 2), len(cues) - 1)][0] if cues else 1.2
    w3 = cues[min(max(3, (len(cues) * 3) // 4), len(cues) - 1)][0] if cues else 2.0

    # Keep base narrative & audio fields untouched
    base = {
        "id": s["id"],
        "act": s.get("act", "act1"),
        "section": s.get("section", "sec_01"),
        "vo": s["vo"],
    }
    if "who" in s:
        base["who"] = s["who"]
    if "hold" in s:
        base["hold"] = s["hold"]
    if "sfx" in s:
        base["sfx"] = s["sfx"]

    # Clean overlays so internal writer labels like PLANT/PAYOFF never appear
    if "overlays" in s and s["overlays"]:
        cleaned_ov = []
        for ov in s["overlays"]:
            ov_copy = dict(ov)
            for k in ("text", "sub", "label"):
                if k in ov_copy and isinstance(ov_copy[k], str):
                    ov_copy[k] = re.sub(r"\b(PLANT|PAYOFF)\s*:\s*", "", ov_copy[k], flags=re.I)
            # Ensure @cue in overlays is valid
            if isinstance(ov_copy.get("at"), str) and ov_copy["at"].startswith("@"):
                ov_copy["at"] = w1
            cleaned_ov.append(ov_copy)
        base["overlays"] = cleaned_ov

    # Check if this shot is a 2D Remotion explainer card
    if idx in CARD_INDICES:
        cspec = CARD_SPECS[card_cursor % len(CARD_SPECS)]
        card_cursor += 1
        base["kind"] = "card"
        for k, v in cspec.items():
            base[k] = v
        new_shots.append(base)
        continue

    # Otherwise, build a richly choreographed 3D adventure shot
    set_name, time_of_day = choose_set_and_time(idx)
    shot_type = SHOT_CYCLE[threed_cursor % len(SHOT_CYCLE)]
    cam_angle = ANGLE_CYCLE[threed_cursor % len(ANGLE_CYCLE)]
    gait = GAIT_CYCLE[threed_cursor % len(GAIT_CYCLE)]

    # 81% of 3D shots have active locomotion paths (every shot except when threed_cursor % 5 == 2, i.e. insert close-up)
    is_walking_shot = (threed_cursor % 5 != 2)
    threed_cursor += 1

    hero_hold, crush_hold, scene_props = choose_props(idx, cues, set_name)
    p1, p2, p3 = POSE_TRIPLETS[idx % len(POSE_TRIPLETS)]
    reach_hero = {"to": REACH_TARGETS[idx % len(REACH_TARGETS)]}
    reach_crush = {"to": REACH_TARGETS[(idx + 2) % len(REACH_TARGETS)]}

    # Determine camera target & actor motion so audit.ts has 0 framing/overlap/hiddenmove/snap issues
    both_target = shot_type in ("establishing", "wide", "full") or (shot_type == "medium" and idx % 2 == 0)
    focal_actor = "crush" if (s.get("who") == "female" or idx % 3 == 1) else "hero"

    # Actor starting & ending coordinates (strictly separated in X: hero in [-1.6, -0.75], crush in [0.75, 1.6])
    dir_sign = 1 if (idx % 2 == 0) else -1
    h_start = [round(-1.25 + 0.15 * dir_sign, 2), 0, round(-0.25 - 0.1 * dir_sign, 2)]
    h_end = [round(-0.85 - 0.15 * dir_sign, 2), 0, round(0.35 + 0.1 * dir_sign, 2)]
    c_start = [round(0.85 + 0.15 * dir_sign, 2), 0, round(-0.2 + 0.1 * dir_sign, 2)]
    c_end = [round(1.25 - 0.15 * dir_sign, 2), 0, round(0.4 - 0.1 * dir_sign, 2)]

    path_end_t = round(max(1.8, min(dur - 0.15, 3.2)), 2)

    hero_spec = {
        "id": "hero",
        "skin": "hero",
        "pos": h_start if is_walking_shot else [-0.95, 0, 0.0],
        "rot": 18,
        "pose": p1,
        "face": "determined" if idx >= 108 else "neutral",
        "faces": [
            {"t": w1, "face": "surprised" if idx % 2 == 0 else "determined"},
            {"t": w2, "face": "happy" if 75 <= idx < 96 else "determined"},
        ],
        "hold": hero_hold,
        "reachR": reach_hero,
        "poses": [
            {"t": w1, "pose": p2, "blend": 0.55},
            {"t": w2, "pose": p3, "blend": 0.55},
            {"t": w3, "pose": p1, "blend": 0.55},
        ],
        "lookAt": "crush" if idx % 2 == 0 else "camera",
    }

    crush_spec = {
        "id": "crush",
        "skin": "crush",
        "pos": c_start if is_walking_shot else [0.95, 0, 0.0],
        "rot": -18,
        "pose": p2,
        "face": "happy" if 70 <= idx < 96 else "surprised",
        "faces": [
            {"t": w1, "face": "happy" if idx % 2 == 1 else "surprised"},
            {"t": w2, "face": "determined" if idx >= 108 else "happy"},
        ],
        "hold": crush_hold,
        "reachR": reach_crush,
        "poses": [
            {"t": w1, "pose": p3, "blend": 0.55},
            {"t": w2, "pose": p1, "blend": 0.55},
            {"t": w3, "pose": p2, "blend": 0.55},
        ],
        "lookAt": "hero" if idx % 2 == 0 else "camera",
    }

    if is_walking_shot:
        if both_target:
            hero_spec["path"] = [
                {"t": 0, "pos": h_start, "gait": gait},
                {"t": path_end_t, "pos": h_end, "gait": gait},
            ]
            crush_spec["path"] = [
                {"t": 0, "pos": c_start, "gait": gait},
                {"t": path_end_t, "pos": c_end, "gait": gait},
            ]
        else:
            # Only move the targeted actor so non-targeted actor never triggers hiddenmove warning
            if focal_actor == "hero":
                hero_spec["path"] = [
                    {"t": 0, "pos": h_start, "gait": gait},
                    {"t": path_end_t, "pos": h_end, "gait": gait},
                ]
                crush_spec["pos"] = [1.05, 0, -0.1]
            else:
                crush_spec["path"] = [
                    {"t": 0, "pos": c_start, "gait": gait},
                    {"t": path_end_t, "pos": c_end, "gait": gait},
                ]
                hero_spec["pos"] = [-1.05, 0, -0.1]

    actors = [hero_spec, crush_spec]

    # In Act 4 on ridge_helipad, include the rescue pilot inspecting the titanium_case
    if set_name == "ridge_helipad" and idx >= 165:
        actors.append({
            "id": "pilot",
            "skin": "guard",
            "pos": [2.35, 0, -0.35],
            "rot": -32,
            "pose": "shocked" if idx >= 170 else "confident",
            "face": "shocked" if idx >= 170 else "determined",
            "faces": [
                {"t": w1, "face": "shocked"},
                {"t": w2, "face": "determined"},
            ],
            "hold": {"R": "rescue_flare"},
            "reachR": {"to": "chest"},
            "poses": [
                {"t": w1, "pose": "examine", "blend": 0.55},
                {"t": w2, "pose": "shocked", "blend": 0.55},
            ],
            "lookAt": "hero",
        })

    # Configure camera with guaranteed head/feet framing and >=50 deg angle shift
    cam_target = ["hero", "crush"] if both_target else focal_actor
    cam = {
        "shot": shot_type,
        "target": cam_target,
        "angle": cam_angle,
        "cut": True,
    }
    if shot_type == "insert":
        # Keep both the held 3D prop at chest/hand height AND the actor's head inside frame
        cam["focus"] = "chest"
        cam["dist"] = 1.65
        cam["el"] = 8
        cam["drift"] = 0.08
    elif shot_type == "close":
        cam["focus"] = "head"
        cam["dist"] = 1.45
        cam["el"] = 6
        cam["drift"] = 0.08
    elif shot_type == "medium":
        cam["focus"] = "chest"
        cam["dist"] = 3.2 if both_target else 2.45
        cam["el"] = 8
        cam["drift"] = 0.14
    elif shot_type == "full":
        cam["focus"] = "waist"
        cam["dist"] = 5.6
        cam["el"] = 10
        cam["drift"] = 0.14
    elif shot_type == "wide":
        cam["focus"] = "waist"
        cam["dist"] = 5.6
        cam["el"] = 12
        cam["drift"] = 0.18
    elif shot_type == "establishing":
        cam["focus"] = "waist"
        cam["dist"] = 6.8
        cam["el"] = 15
        cam["drift"] = 0.22

    if idx in (108, 138, 150, 172):
        cam["shake"] = 0.18

    base["kind"] = "3d"
    base["set"] = set_name
    base["time"] = time_of_day
    base["camera"] = cam
    base["actors"] = actors
    base["props"] = scene_props

    new_shots.append(base)

ep["shots"] = new_shots
ep["voice"] = {
    "id": "en-US-Neural2-D",
    "speakingRate": 1.02,
    "pitch": -3.0,
    "targetWpm": 176,
    "tempoRange": [0.96, 1.05],
}
EP_PATH.write_text(json.dumps(ep, indent=2) + "\n")
print(f"Wrote {len(new_shots)} choreographed shots to {EP_PATH}")
