// QA runner (no frames rendered):
//   node tools/qa.cjs selftest           engine self-tests (npm test)
//   node tools/qa.cjs audit <slug>       pre-render scene audit → out/<slug>/audit.json; exit 1 on errors
const path = require('path');
const fs = require('fs');
const ROOT = path.resolve(__dirname, '..');
const { createRequire } = require('module');
const req = createRequire(path.join(ROOT, 'package.json'));

function findBrowserExecutable() {
  if (process.env.REMOTION_CHROME_EXECUTABLE && fs.existsSync(process.env.REMOTION_CHROME_EXECUTABLE)) {
    return process.env.REMOTION_CHROME_EXECUTABLE;
  }
  const candidates = [
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
    '/data/data/com.termux/files/usr/bin/chromium',
    '/data/data/com.termux/files/usr/bin/chromium-browser',
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return null;
}

async function runViaNodeEsbuild(cmd, slug) {
  let esbuild;
  try {
    esbuild = req('esbuild');
  } catch {
    const bundlerReq = createRequire(req.resolve('@remotion/bundler'));
    esbuild = bundlerReq('esbuild');
  }
  const tmpDir = path.join(ROOT, 'out', '.qa_tmp');
  fs.mkdirSync(tmpDir, { recursive: true });
  const outfile = path.join(tmpDir, 'qa_bundle.cjs');
  const entryFile = path.join(tmpDir, 'qa_entry.ts');
  fs.writeFileSync(
    entryFile,
    `export { runSelfTests } from '../../src/episode/selftest';\nexport { auditEpisode, formatReport } from '../../src/episode/audit';\n`
  );
  await esbuild.build({
    entryPoints: [entryFile],
    outfile,
    bundle: true,
    platform: 'node',
    format: 'cjs',
    target: 'node18',
    logLevel: 'silent',
  });
  const mod = require(outfile);
  if (cmd === 'selftest') {
    const res = mod.runSelfTests();
    for (const r of res) console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${r.name}${r.pass ? '' : '  —  ' + r.detail}`);
    const failed = res.filter(r => !r.pass).length;
    console.log(`\n${res.length - failed}/${res.length} passed`);
    return failed ? 1 : 0;
  } else {
    const base = path.join(ROOT, 'public', 'episodes', slug);
    const ep = JSON.parse(fs.readFileSync(path.join(base, 'episode.json'), 'utf8'));
    const timing = JSON.parse(fs.readFileSync(path.join(base, 'timing.json'), 'utf8'));
    const report = mod.auditEpisode(ep, timing);
    const text = mod.formatReport(report, slug);
    const out = path.join(ROOT, 'out', slug);
    fs.mkdirSync(out, { recursive: true });
    fs.writeFileSync(path.join(out, 'audit.json'), JSON.stringify(report, null, 1));
    console.log(text);
    return report.findings.some(f => f.sev === 'error') ? 1 : 0;
  }
}

(async () => {
  const [cmd, slug] = process.argv.slice(2);
  if (!['audit', 'selftest'].includes(cmd) || (cmd === 'audit' && !slug)) {
    console.error('usage: node tools/qa.cjs selftest | audit <slug>');
    process.exit(2);
  }
  if (!process.env.QA_USE_BROWSER) {
    const code = await runViaNodeEsbuild(cmd, slug);
    process.exit(code);
  }
  try {
    const { bundle } = req('@remotion/bundler');
    const { selectComposition, openBrowser } = req('@remotion/renderer');
    const serveUrl = await bundle({ entryPoint: path.join(ROOT, 'src/index.ts'), publicDir: path.join(ROOT, 'public') });
    const browser = await openBrowser('chrome', {
      browserExecutable: browserExecutable || undefined,
      chromiumOptions: { gl: 'angle' },
    });
    let code = 0;
    try {
      const comp = await selectComposition({
        serveUrl,
        id: cmd === 'audit' ? 'Audit' : 'SelfTest',
        inputProps: cmd === 'audit' ? { slug } : {},
        puppeteerInstance: browser,
        browserExecutable: browserExecutable || undefined,
        chromiumOptions: { gl: 'angle' },
        timeoutInMilliseconds: 600000,
      });
      if (cmd === 'selftest') {
        const res = comp.props.results;
        for (const r of res) console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${r.name}${r.pass ? '' : '  —  ' + r.detail}`);
        const failed = res.filter(r => !r.pass).length;
        console.log(`\n${res.length - failed}/${res.length} passed`);
        code = failed ? 1 : 0;
      } else {
        const out = path.join(ROOT, 'out', slug);
        fs.mkdirSync(out, { recursive: true });
        fs.writeFileSync(path.join(out, 'audit.json'), JSON.stringify(comp.props.report, null, 1));
        console.log(comp.props.text);
        code = comp.props.report.findings.some(f => f.sev === 'error') ? 1 : 0;
      }
    } finally {
      await browser.close({ silent: true });
    }
    process.exit(code);
  } catch (err) {
    const code = await runViaNodeEsbuild(cmd, slug);
    process.exit(code);
  }
})();
