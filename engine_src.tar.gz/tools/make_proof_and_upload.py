#!/usr/bin/env python3
"""Render the 16-panel Visual Proof Sheet (Island_Assets_And_Cards_Proof.png),
upload it directly to Google Drive via Composio (ca_20wgJd7IoZLu), set sharing permissions,
and immediately purge local temporary files.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, "/data/data/com.termux/files/home/minecraft_whatif_engine")
sys.path.insert(0, "/data/data/com.termux/files/home")
import config  # noqa: E402
from tools.deliver_crush_island_10min import upload_file_to_composio_s3  # noqa: E402

ROOT = Path("/data/data/com.termux/files/home/minecraft_whatif_engine")
OUT_DIR = ROOT / "out"
LAB_DIR = OUT_DIR / "lab"
DRIVE_CA = "ca_20wgJd7IoZLu"

PANELS = [
    ("p01.jpg", 42, "SET 1: crash_beach (Flight 815 Wreck)"),
    ("p02.jpg", 133, "PROP INSERT: boarding_pass_14b"),
    ("p03.jpg", 573, "BUBBLE: 'Please tell me this is a layover.'"),
    ("p04.jpg", 754, "SET 2: reef_lagoon (Coral & Parrotfish)"),
    ("p05.jpg", 798, "CARD 1: search_radar (45,000 KM2 Grid)"),
    ("p06.jpg", 865, "PROP INSERT: titanium_case (14B LED)"),
    ("p07.jpg", 921, "CARD 2: kidney_osmosis (Rule of Threes)"),
    ("p08.jpg", 1085, "PROP INSERT: wing_slat (Sunbeam Cone)"),
    ("p09.jpg", 1303, "SET 3: jungle_camp (Shelter & Stills)"),
    ("p10.jpg", 1480, "PROP INSERT: cracked_phone (1% Battery)"),
    ("p11.jpg", 1636, "SET 4: storm_beach (180kg Beam & Rain)"),
    ("p12.jpg", 1715, "CARD 6: lever_battery (4:1 Lever & 410C)"),
    ("p13.jpg", 1790, "CARD 3: parabolic_mirror (3km vs 37km)"),
    ("p14.jpg", 1904, "SET 5: ridge_helipad (Dawn Helicopter)"),
    ("p15.jpg", 2480, "CARD 5: solar_still (2.4L/Day Diagram)"),
    ("p16.jpg", 2655, "CARD 4: refraction_spear (n = 1.33 Aim)"),
]


def upload_and_share(local_path: Path) -> str:
    file_obj = upload_file_to_composio_s3(local_path, "GOOGLEDRIVE_UPLOAD_FILE")
    res = config.composio_execute(
        "GOOGLEDRIVE_UPLOAD_FILE",
        {"file_to_upload": file_obj},
        connected_account_id=DRIVE_CA,
        timeout=900,
    )
    data = (res.get("data") or {}).get("response_data") or res.get("data") or {}
    fid = data.get("id")
    if not fid:
        raise RuntimeError(f"Drive upload failed: {res}")
    try:
        config.composio_execute(
            "GOOGLEDRIVE_ADD_FILE_SHARING_PREFERENCE",
            {"file_id": fid, "role": "reader", "type": "anyone"},
            connected_account_id=DRIVE_CA,
            timeout=120,
        )
    except Exception:
        pass
    return f"https://drive.google.com/file/d/{fid}/view?usp=sharing"


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    jobs_file = OUT_DIR / "proof_jobs.json"
    jobs = [
        {
            "out": name,
            "id": "Episode",
            "props": {"slug": "crush-island-10min"},
            "frame": frame,
        }
        for name, frame, _ in PANELS
    ]
    jobs_file.write_text(json.dumps(jobs, indent=2))

    env = os.environ.copy()
    env["REBUNDLE"] = "1"
    env["NO_STILLS_CACHE"] = "1"
    env["STILLS_CONCURRENCY"] = "4"
    subprocess.run(["node", "tools/stills.cjs", str(jobs_file)], cwd=str(ROOT), env=env, check=True)

    # Tile the 16 panels into a crisp 2560x1440 4x4 PNG proof sheet
    inputs = []
    for name, _, _ in PANELS:
        p = LAB_DIR / name
        if not p.exists():
            raise RuntimeError(f"Missing rendered panel: {p}")
        inputs.extend(["-i", str(p)])

    proof_png = OUT_DIR / "Island_Assets_And_Cards_Proof.png"
    filter_parts = []
    for i in range(16):
        filter_parts.append(f"[{i}:v]scale=640:360,drawbox=x=0:y=0:w=640:h=360:color=white@0.25:t=2[v{i}]")
    stack_inputs = "".join(f"[v{i}]" for i in range(16))
    filter_parts.append(f"{stack_inputs}xstack=inputs=16:layout=0_0|w0_0|w0+w1_0|w0+w1+w2_0|0_h0|w0_h0|w0+w1_h0|w0+w1+w2_h0|0_h0+h4|w0_h0+h4|w0+w1_h0+h4|w0+w1+w2_h0+h4|0_h0+h4+h8|w0_h0+h4+h8|w0+w1_h0+h4+h8|w0+w1+w2_h0+h4+h8[out]")

    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", *inputs, "-filter_complex", ";".join(filter_parts), "-map", "[out]", str(proof_png)],
        cwd=str(ROOT),
        check=True,
    )

    drive_url = upload_and_share(proof_png)
    print(f"PROOF_SHEET_DRIVE_URL={drive_url}")

    # Purge proof sheet and lab images immediately
    subprocess.run("rm -rf out/lab out/.stills_cache out/proof_jobs.json out/Island_Assets_And_Cards_Proof.png /data/data/com.termux/files/usr/tmp/.org.chromium* /data/data/com.termux/files/usr/tmp/*remotion*", shell=True, cwd=str(ROOT))


if __name__ == "__main__":
    main()
