// Build PillSprint: 1) synthesize the audio mix with the project venv, 2) render the video with Remotion,
// 3) mux the audio cleanly so there's no edge pop. Works on Windows, macOS, Linux, and Termux.
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const req = createRequire(path.join(root, 'package.json'));
const { bundle } = req('@remotion/bundler');
const { openBrowser, renderFrames, selectComposition } = req('@remotion/renderer');

const win = process.platform === 'win32';
const py = fs.existsSync(path.join(root, '.venv', 'bin', 'python'))
  ? path.join(root, '.venv', 'bin', 'python')
  : path.join(root, '.venv', 'Scripts', 'python.exe');
const q = s => (win ? `"${s}"` : s);

const browserCandidates = [
  process.env.REMOTION_CHROME_EXECUTABLE,
  '/data/data/com.termux/files/usr/bin/chromium',
  '/data/data/com.termux/files/usr/bin/chromium-browser',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/usr/bin/google-chrome',
].filter(Boolean);
const browserExecutable = browserCandidates.find(p => fs.existsSync(p));
const glBackend = process.platform === 'android' ? 'swangle' : 'angle';

function run(cmd, args) {
  const r = spawnSync(cmd, args, { cwd: root, stdio: 'inherit', shell: win });
  if (r.status !== 0) process.exit(r.status ?? 1);
}

const frames = path.join(root, 'out', 'frames');
fs.rmSync(frames, { recursive: true, force: true });
fs.mkdirSync(frames, { recursive: true });

run(q(py), ['-I', q(path.join(root, 'tools', 'sfx', 'pill_sprint.py'))]);

const bundleDir = path.join(root, 'out', 'bundle');
const serveUrl = fs.existsSync(path.join(bundleDir, 'index.html')) && !process.env.REBUNDLE
  ? bundleDir
  : await bundle({
      entryPoint: path.join(root, 'src/index.ts'),
      publicDir: path.join(root, 'public'),
      outDir: bundleDir,
    });

const browser = await openBrowser('chrome', {
  browserExecutable,
  chromeMode: 'chrome-for-testing',
  chromiumOptions: { gl: glBackend },
});

try {
  const comp = await selectComposition({
    serveUrl,
    id: 'PillSprint',
    inputProps: {},
    puppeteerInstance: browser,
    browserExecutable,
    chromeMode: 'chrome-for-testing',
    chromiumOptions: { gl: glBackend },
  });
  let rendered = 0;
  await renderFrames({
    composition: comp,
    serveUrl,
    outputDir: frames,
    inputProps: {},
    imageFormat: 'jpeg',
    jpegQuality: 95,
    puppeteerInstance: browser,
    browserExecutable,
    chromeMode: 'chrome-for-testing',
    chromiumOptions: { gl: glBackend },
    concurrency: 1,
    onFrameRendered: () => {
      rendered++;
      if (rendered % 15 === 0 || rendered === comp.durationInFrames) {
        console.log(`rendered ${rendered}/${comp.durationInFrames} frames`);
      }
    },
    onStart: () => {
      console.log(`starting PillSprint render (${comp.durationInFrames} frames)...`);
    },
  });
} finally {
  await browser.close({ silent: true });
}

run('ffmpeg', [
  '-y', '-framerate', '30', '-i', q(path.join(frames, 'element-%03d.jpeg')),
  '-i', q(path.join(root, 'public', 'audio', 'pill_sprint_mix.wav')),
  '-c:v', 'libx264', '-crf', '16', '-pix_fmt', 'yuv420p',
  '-c:a', 'aac', '-b:a', '192k', '-shortest',
  q(path.join(root, 'out', 'pill_sprint.mp4')),
]);
fs.rmSync(frames, { recursive: true, force: true });
