import fs from 'fs';
import path from 'path';

const epPath = path.resolve('public/episodes/crush-island-10min/episode.json');
const tmPath = path.resolve('public/episodes/crush-island-10min/timing.json');

const ep = JSON.parse(fs.readFileSync(epPath, 'utf8'));
const tm = JSON.parse(fs.readFileSync(tmPath, 'utf8'));

// Helper: pick valid @word cues from the shot's timing.json words
function getValidWordCues(shotIdx, count = 3) {
  const words = tm.shots[shotIdx]?.words || [];
  const valid = [];
  for (const [w, t] of words) {
    const clean = String(w).toLowerCase().replace(/[^a-z0-9']/g, '');
    if (clean.length >= 2 && /^[a-z0-9']+$/.test(clean) && !valid.some(v => v.word === clean)) {
      valid.push({ cue: `@${clean}`, word: clean, t });
    }
  }
  if (valid.length === 0) return [];
  const picked = [];
  for (let k = 0; k < Math.min(count, valid.length); k++) {
    const idx = Math.min(valid.length - 1, Math.floor((k * valid.length) / count));
    picked.push(valid[idx].cue);
  }
  return picked;
}

// Determine which shots are full-screen 2D blueprint motion-graphics cards (~40% of episode = 74 shots)
// Ensure character speech-bubble shots remain 3D shots so the bubble points to the speaker!
const SPEECH_BUBBLE_SHOTS = new Set([
  4,   // "Please tell me this is a layover."
  25,  // "Stop doing math."
  38,  // "So the ocean is basically liquid sandpaper."
  47,  // "Don't ask. It's my lucky ticket."
  69,  // "Coconut one. Action hero zero."
  82,  // "Did you just tackle the ocean?"
  86,  // "Aim below the belly, Einstein."
  105, // "I was in row six. I paid 50 bucks to sit by you."
  106, // "Best fifty dollars I ever spent."
  115, // "The whole beach is going underwater."
  130, // "It's pinned! Leave me, flash the plane!"
  168, // "Next time, we're taking a train."
  173, // "Control, Asset 14B and the cargo survived."
]);

// Curated blueprint card assignments keyed by shot index (74 shots = 40.0% of 185 shots,
// and 12 shots in 0..29 = 40.0% of the 90-second Director's Cut!)
const CARD_MAP = new Map([
  // --- First 90 Seconds (Shots 0..29: 12 blueprint cards = 40%) ---
  [5, { card: 'title', small: 'WHAT IF YOU AND YOUR CRUSH WERE', big: 'STRANDED ON AN ISLAND?' }],
  [7, { card: 'search_radar', title: 'OCEAN SEARCH GEOMETRY', sub: '360° EMPTY PACIFIC HORIZON • ZERO SHIPPING LANES' }],
  [9, { card: 'kidney_osmosis', title: 'BIOLOGY VS MOVIE MYTHS', sub: 'RULE OF THREES & DEHYDRATION CLOCK' }],
  [12, { card: 'distance', value: 12, unit: 'KILOMETERS UPWIND', label: 'SLIDE RAFTS DRIFTED AWAY IN MICROBURST', count: 1, target: 'flag', time: 'DRIFT VECTOR' }],
  [14, { card: 'rules', title: 'HIGH SCHOOL SOCIAL FILTERS ERASED', prefix: 'FILTER', rules: ['POPULARITY: GONE', 'GRADES & EXAMS: GONE', 'CELL SERVICE & WI-FI: 0 BARS'], current: 3 }],
  [16, { card: 'clock', mode: 'tick', at: 1.0, value: '72:00:00', label: 'HUMAN BODY WATER CLOCK STARTS NOW' }],
  [18, { card: 'lever_battery', title: '4-DAY SURVIVAL PHYSICS PREVIEW' }],
  [19, { card: 'parabolic_mirror', title: 'ISLAND SIGNAL OPTICS: 37 KM BEAM' }],
  [21, { card: 'search_radar', title: '20-MIN GLIDE OFF RADAR', sub: 'EXPANDING 45,000 KM² SEARCH CIRCLE VS 2 KM CORRIDOR' }],
  [22, { card: 'compare', title: 'SEARCH CORRIDOR VS OCEAN GRID', unit: 'KM', left: { label: 'SCAN WIDTH', value: 2, icon: 'eye' }, right: { label: 'SEARCH ZONE', value: 45000, icon: 'globe' }, ratioLabel: 'LARGER' }],
  [24, { card: 'solar_still', title: 'SOLAR DISTILLATION: 2.4 LITERS / DAY' }],
  [26, { card: 'refraction_spear', title: "SNELL'S LAW LAGOON SPEAR OPTICS (n = 1.33)" }],

  // --- Act I & II (Shots 30..109) ---
  [30, { card: 'kidney_osmosis', title: 'WILDERNESS RULE OF THREES' }],
  [32, { card: 'stat', value: 4, unit: 'LITERS LOST / DAY', label: 'SWEATING & BREATHING AT 32°C', icon: 'heart' }],
  [35, { card: 'kidney_osmosis', title: 'SEAWATER SALT VS HUMAN KIDNEY LIMIT' }],
  [37, { card: 'kidney_osmosis', title: 'OSMOSIS CELL DRAIN: -0.5L PER LITER DRUNK' }],
  [39, { card: 'clock', mode: 'freeze', at: 0.9, value: '72 HOURS', label: 'DEHYDRATION DEADLINE' }],
  [42, { card: 'parabolic_mirror', title: 'FLAT MIRROR (3 KM) VS CURVED WING SLAT (37 KM)' }],
  [44, { card: 'lever_battery', title: 'SALVAGED 15 Wh LITHIUM-ION POUCH' }],
  [50, { card: 'stat', value: 9, unit: 'KILOGRAMS', label: 'HERMETICALLY SEALED TITANIUM CASE • SEAT 14B', icon: 'warning' }],
  [53, { card: 'rules', title: 'THREE ISLAND PHYSICS RULES', prefix: 'RULE', rules: ['GREEN PALM FRONDS BOIL SAP INTO WHITE SMOKE', '4:1 DRIFTWOOD LEVER MULTIPLIES FORCE ×4', 'PARABOLIC WING SLAT FOCUSES 37 KM FLASH'], current: 1 }],
  [54, { card: 'lever_battery', title: 'RULE 1 & RULE 2: SMOKE + 4:1 LEVERAGE' }],
  [56, { card: 'parabolic_mirror', title: 'RULE 3: CONCAVE WING SLAT SOLAR FOCUS' }],
  [57, { card: 'stat', value: 410, unit: '°C FOCUS HEAT', label: 'CONCAVE WING SLAT CHARS DRY BARK', icon: 'lightning' }],
  [59, { card: 'parabolic_mirror', title: '360° AIMING TRIPOD HORIZON SWEEP' }],
  [61, { card: 'icon', icon: 'heart', caption: 'TEEN BRAIN PRIORITY #2', sub: 'LOOKING COOL IN FRONT OF YOUR CRUSH' }],
  [65, { card: 'compare', title: 'HAND CHOP VS COCONUT SHELL', unit: 'MPa', left: { label: 'KARATE CHOP', value: 2, icon: 'muscle' }, right: { label: 'COCONUT SHELL', value: 20, icon: 'warning' }, ratioLabel: 'STRONGER' }],
  [66, { card: 'stat', value: 20, unit: 'MEGAPASCALS (MPa)', label: 'COCONUT SHELL = RED PAVING BRICK STRENGTH', icon: 'warning' }],
  [72, { card: 'chain', title: 'BASALT WEDGE LEVERAGE', nodes: [{ icon: 'point', label: 'POINTED STONE' }, { icon: 'muscle', label: 'SPEAR HUSK' }, { icon: 'check', label: 'OPEN IN 4 SEC' }] }],
  [74, { card: 'stat', value: 400, unit: 'mL ELECTROLYTE WATER', label: 'STERILE POTASSIUM-RICH WATER PER COCONUT', icon: 'heart' }],
  [77, { card: 'chain', title: 'DAY 2: FIRE-HARDENED BAMBOO SPEAR', nodes: [{ icon: 'lightning', label: 'CHAR TIPS' }, { icon: 'point', label: '4 PRONGS' }, { icon: 'check', label: 'REEF HUNT' }] }],
  [79, { card: 'refraction_spear', title: 'TARGET ACQUIRED: BLUE PARROTFISH' }],
  [83, { card: 'refraction_spear', title: "SNELL'S LAW: REFRACTIVE INDEX n = 1.33" }],
  [84, { card: 'refraction_spear', title: 'APPARENT HOLOGRAM VS REAL FISH DEPTH' }],
  [85, { card: 'refraction_spear', title: 'AIM ONE HAND-WIDTH BELOW THE HOLOGRAM' }],
  [90, { card: 'icon', icon: 'warning', caption: 'VINE LASHING FAILURE', sub: '20 KG WET PALM THATCH DROPS LIKE A GREEN WIG' }],
  [92, { card: 'chain', title: 'HIBISCUS BARK CORDAGE', nodes: [{ icon: 'point', label: 'BRAID BARK' }, { icon: 'check', label: 'SQUARE KNOT' }, { icon: 'house', label: 'RIGID A-FRAME' }] }],
  [95, { card: 'compare', title: 'A-FRAME FLOOR WIDTH', unit: 'MATTRESS', left: { label: 'CASTAWAYS', value: 2, icon: 'stand' }, right: { label: 'LEAF BED', value: 1, icon: 'house' }, lowerWins: true, ratioLabel: 'SHARED' }],
  [97, { card: 'solar_still', title: '3 CONICAL SOLAR PITS (1.0M WIDE)' }],
  [99, { card: 'solar_still', title: 'CLEAR CABIN PLASTIC + CENTER PEBBLE' }],
  [100, { card: 'solar_still', title: 'GREENHOUSE EVAPORATION: 800 mL PER PIT' }],
  [101, { card: 'solar_still', title: '3 PITS × 800 mL = 2.4 LITERS / DAY' }],
  [104, { card: 'stat', value: 5000, unit: 'BORTLE-1 STARS', label: 'ZERO LIGHT POLLUTION ABOVE NIGHT CAMPFIRE', icon: 'globe' }],
  [109, { card: 'search_radar', title: 'ZERO FREIGHTER LANES NEAR ATOLL', sub: 'NO CHANCE VISUAL PASSING WITHIN REEF HORIZON' }],

  // --- Act III: Cyclone & 180s Rescue Window (Shots 110..163) ---
  [112, { card: 'speed', value: 220, unit: 'KM/H CYCLONE', label: 'CATEGORY-4 STORM SPINNING TOWARD ATOLL (12 HRS OUT)' }],
  [113, { card: 'stat', value: 24, unit: 'MILLIBAR DROP', label: 'COCKPIT ALTIMETER BAROMETER PLUNGING', icon: 'warning' }],
  [114, { card: 'compare', title: 'STORM SURGE VS SANDBAR ELEVATION', unit: 'M', left: { label: 'BEACH HEIGHT', value: 1.2, icon: 'flag' }, right: { label: 'STORM SURGE', value: 2.0, icon: 'warning' }, ratioLabel: 'UNDERWATER' }],
  [118, { card: 'chain', title: 'CHAIN THE ISLAND PHYSICS', nodes: [{ icon: 'muscle', label: '4:1 LEVER' }, { icon: 'lightning', label: '410°C SPARK' }, { icon: 'eye', label: '37 KM FLASH' }] }],
  [119, { card: 'lever_battery', title: 'PRE-STORM PREP: BATTERY FOIL + LEVER' }],
  [124, { card: 'search_radar', title: 'COAST GUARD PLANE AT 37 KM!', sub: 'TWIN-ENGINE SEARCH PLANE BANKING THROUGH SQUALL BREAK' }],
  [125, { card: 'clock', mode: 'fast', at: 0.5, value: '180 SEC', label: '240-KNOT PLANE CROSSES HORIZON IN 180 SECONDS' }],
  [128, { card: 'stat', value: 180, unit: 'KG ALUMINUM BEAM', label: 'KING-TIDE ROLLS WRECK BEAM ACROSS HER ANKLE', icon: 'warning' }],
  [133, { card: 'compare', title: 'RAW DEADLIFT VS 180 KG BEAM IN SUCTION SAND', unit: 'KG', left: { label: 'YOUR PULL', value: 65, icon: 'muscle' }, right: { label: 'WRECK BEAM', value: 180, icon: 'warning' }, ratioLabel: 'PINNED' }],
  [134, { card: 'clock', mode: 'fast', at: 0.4, value: '+10 CM/MIN', label: 'STORM SURGE RISING 10 CM EVERY MINUTE' }],
  [136, { card: 'clock', mode: 'freeze', at: 0.8, value: '120 SEC', label: '2 MINUTES UNTIL WATER REACHES HER CHIN & PLANE VANISHES' }],
  [140, { card: 'lever_battery', title: 'STEP 1: 4:1 ARCHIMEDES DRIFTWOOD LEVER' }],
  [143, { card: 'lever_battery', title: '45 KG PUSH × 4 = 180 KG UPWARD TORQUE' }],
  [144, { card: 'stat', value: 180, unit: 'KG UPWARD TORQUE', label: '40 CM BASALT FULCRUM MULTIPLIES FORCE ×4', icon: 'check' }],
  [146, { card: 'clock', mode: 'fast', at: 0.3, value: '52 SEC', label: '52 SECONDS LEFT BEFORE PLANE BANKS AWAY' }],
  [148, { card: 'lever_battery', title: 'BRIDGE 15 Wh BATTERY LEADS WITH FOIL WRAPPER' }],
  [149, { card: 'lever_battery', title: '15 Wh FOIL SHORT = 410°C THERMAL IGNITION' }],
  [152, { card: 'chain', title: 'WET GREEN PALM SAP BOILS', nodes: [{ icon: 'lightning', label: '410°C CORE' }, { icon: 'warning', label: 'GREEN FRONDS' }, { icon: 'check', label: 'WHITE SMOKE' }] }],
  [153, { card: 'clock', mode: 'freeze', at: 0.4, value: '16 SEC', label: '16 SECONDS REMAINING!' }],
  [155, { card: 'parabolic_mirror', title: 'LOCK CONCAVE WING SLAT ON TRIPOD SIGHT' }],
  [157, { card: 'parabolic_mirror', title: '37 KM PARABOLIC BEAM SWEEPS COCKPIT' }],
  [161, { card: 'search_radar', title: 'TARGET LOCKED: 3 FLASHES CONFIRMED', sub: 'SEARCH PLANE ROCKS WINGS & DROPS GREEN FLARE' }],

  // --- Act IV: Dawn Helicopter Rescue & 14B Twist (Shots 164..184) ---
  [166, { card: 'stat', value: 4000000, unit: 'VIRAL VIEWS BY NOON', label: 'COCKPIT CLIP HITS 4 MILLION VIEWS', icon: 'globe' }],
  [167, { card: 'title', small: 'VIRAL BREAKING HEADLINE', big: 'DEAD PHONE & BROKEN WING' }],
  [171, { card: 'stat', value: 9, unit: 'KG TITANIUM CASE', label: 'LIFTED ONTO COAST GUARD HELICOPTER SKID', icon: 'warning' }],
  [175, { card: 'rules', title: 'CLASSIFIED BIOMETRIC CARGO PLATE', prefix: 'STAMP', rules: ['BIOMETRIC SENSOR: BLINKING RED', 'PASSENGER MANIFEST TAG: NONE', 'LASER-ETCHED CODE: SEAT 14B'], current: 3 }],
  [177, { card: 'chain', title: 'FUSELAGE LATCH FORENSICS', nodes: [{ icon: 'warning', label: 'SHEARED BOLTS' }, { icon: 'lightning', label: 'BLOWN OUTWARD' }, { icon: 'eye', label: 'SABOTAGE!' }] }],
  [179, { card: 'title', small: 'THE CRASH WAS', big: 'NEVER AN ACCIDENT' }],
  [181, { card: 'chain', title: 'FINAL CHOICE ON THE HELIPAD', nodes: [{ icon: 'warning', label: 'PILOT REACHES' }, { icon: 'question', label: 'BOARD HELI?' }, { icon: 'run', label: 'RUN TO JUNGLE?' }] }],
  [183, { card: 'title', small: 'TELL US IN THE COMMENTS', big: 'BOARD OR RUN?' }],
]);

// Choose bespoke 3D set for every 3D shot
function chooseBespokeSet(i) {
  // In the first 90 seconds (0..29), showcase all 5 custom sets across the intro & previews!
  if (i <= 4) return 'crash_beach';
  if (i === 6) return 'reef_lagoon';
  if (i === 8) return 'crash_beach';
  if (i === 10) return 'reef_lagoon';
  if (i === 11) return 'crash_beach';
  if (i === 13) return 'jungle_camp';
  if (i === 15) return 'jungle_camp';
  if (i === 17) return 'storm_beach';
  if (i === 20) return 'ridge_helipad';
  if (i === 23) return 'ridge_helipad';
  if (i === 25) return 'crash_beach';
  if (i === 26) return 'jungle_camp';
  if (i === 28) return 'reef_lagoon';
  if (i === 29) return 'jungle_camp';

  // Act I Water Clock & Wreck Salvage (30..52)
  if (i >= 30 && i <= 39) return i % 2 === 0 ? 'reef_lagoon' : 'crash_beach';
  if (i >= 40 && i <= 52) return 'crash_beach';

  // Act II Camp, Coconut, Spear Fishing in Reef Lagoon, Shelter & Solar Stills (53..109)
  if (i >= 53 && i <= 75) return 'jungle_camp';
  if (i >= 76 && i <= 88) return 'reef_lagoon';
  if (i >= 89 && i <= 109) return 'jungle_camp';

  // Act III Storm Beach & Cyclone Rescue (110..163)
  if (i >= 110 && i <= 120) return i % 2 === 0 ? 'storm_beach' : 'jungle_camp';
  if (i >= 121 && i <= 163) return 'storm_beach';

  // Act IV Dawn Helipad Rescue & 14B Twist (164..184)
  return 'ridge_helipad';
}

// Macro 3D prop insert shots: close-up / insert framing on the 3D prop with actors positioned cleanly nearby
const MACRO_PROP_SHOTS = new Map([
  [1, { prop: 'boarding_pass_14b', set: 'crash_beach', label: '14B • EXIT ROW PASS', holdR: 'boarding_pass_14b' }],
  [8, { prop: 'titanium_case', set: 'crash_beach', label: '9 KG TITANIUM CASE • 14B', holdR: 'titanium_case' }],
  [11, { prop: 'wing_slat', set: 'crash_beach', label: '37 KM MIRROR WING SLAT', holdR: 'wing_slat' }],
  [15, { prop: 'cracked_phone', set: 'jungle_camp', label: '1% BATTERY • 0 BARS', holdR: 'cracked_phone' }],
  [23, { prop: 'coconut', set: 'ridge_helipad', label: '20 MPa COCONUT SHELL', holdR: 'coconut' }],
  [28, { prop: 'parrotfish', set: 'reef_lagoon', label: 'REEF LAGOON ECOSYSTEM', holdR: 'bamboo_spear' }],
  [41, { prop: 'wing_slat', set: 'crash_beach', label: '37 KM MIRROR WING SLAT', holdR: 'wing_slat' }],
  [43, { prop: 'cracked_phone', set: 'crash_beach', label: '15 Wh LITHIUM POUCH', holdR: 'cracked_phone' }],
  [45, { prop: 'boarding_pass_14b', set: 'crash_beach', label: 'SEAT 14B LUCKY TICKET', holdR: 'boarding_pass_14b' }],
  [49, { prop: 'titanium_case', set: 'crash_beach', label: '9 KG TITANIUM CASE • 14B', holdR: 'titanium_case' }],
  [55, { prop: 'driftwood_lever', set: 'jungle_camp', label: '4:1 ARCHIMEDES LEVER', holdR: 'driftwood_lever' }],
  [58, { prop: 'driftwood_tripod', set: 'jungle_camp', label: '360° AIMING TRIPOD', holdR: 'wing_slat' }],
  [64, { prop: 'coconut', set: 'jungle_camp', label: '20 MPa COCONUT SHELL', holdR: 'coconut' }],
  [71, { prop: 'coconut', set: 'jungle_camp', label: 'POINTED BASALT WEDGE', holdR: 'coconut' }],
  [78, { prop: 'bamboo_spear', set: 'reef_lagoon', label: '4-PRONG BAMBOO SPEAR', holdR: 'bamboo_spear' }],
  [80, { prop: 'parrotfish', set: 'reef_lagoon', label: 'n = 1.33 LIGHT BENDING', holdR: 'bamboo_spear' }],
  [91, { prop: 'palm_thatch_wig', set: 'jungle_camp', label: '20 KG PALM THATCH WIG', holdR: 'palm_thatch_wig' }],
  [98, { prop: 'solar_cup', set: 'jungle_camp', label: '800 mL / SOLAR STILL', holdR: 'solar_cup' }],
  [129, { prop: 'driftwood_lever', set: 'storm_beach', label: '180 KG ALUMINUM BEAM', holdR: 'driftwood_lever' }],
  [141, { prop: 'driftwood_lever', set: 'storm_beach', label: '2.4M IRONWOOD LEVER', holdR: 'driftwood_lever' }],
  [147, { prop: 'battery_spark_foil', set: 'storm_beach', label: '410°C FOIL SPARK', holdR: 'battery_spark_foil' }],
  [150, { prop: 'battery_spark_foil', set: 'storm_beach', label: 'COCONUT HUSK IGNITION', holdR: 'battery_spark_foil' }],
  [162, { prop: 'green_flare', set: 'storm_beach', label: 'COAST GUARD GREEN FLARE', holdR: 'green_flare' }],
  [174, { prop: 'titanium_case', set: 'ridge_helipad', label: 'BIOMETRIC PLATE: 14B', holdR: 'titanium_case' }],
]);

//Exact Speech Bubbles & Diegetic HUD Badges by shot index
const BUBBLE_TEXT = new Map([
  [4, { actor: 'crush', text: 'Please tell me this is a layover.' }],
  [25, { actor: 'crush', text: 'Stop doing math.' }],
  [38, { actor: 'crush', text: 'Liquid sandpaper. Got it.' }],
  [47, { actor: 'crush', text: "Don't ask. It's my lucky ticket." }],
  [69, { actor: 'crush', text: 'Coconut one. Action hero zero.' }],
  [82, { actor: 'crush', text: 'Did you just tackle the ocean?' }],
  [86, { actor: 'crush', text: 'Aim below the belly, Einstein.' }],
  [105, { actor: 'crush', text: 'I was in row six. I paid 50 bucks to sit by you.' }],
  [106, { actor: 'crush', text: 'Best fifty dollars I ever spent.' }],
  [115, { actor: 'crush', text: 'The whole beach is going underwater!' }],
  [130, { actor: 'crush', text: "It's pinned! Leave me, flash the plane!" }],
  [168, { actor: 'crush', text: "Next time, we're taking a train." }],
  [173, { actor: 'pilot', text: 'Control, Asset 14B and the cargo survived.' }],
]);

const HUD_BADGES = new Map([
  [0, { type: 'label', text: '14B • FLIGHT 815 WRECK', corner: 'tl' }],
  [1, { type: 'label', text: '14B', corner: 'tr' }],
  [2, { type: 'label', text: 'FLIGHT 815 • CORAL SANDBAR', corner: 'tl' }],
  [6, { type: 'label', text: '0 BOATS • 360° HORIZON', corner: 'tr' }],
  [11, { type: 'label', text: 'MICROBURST TAIL SHEAR', corner: 'tl' }],
  [15, { type: 'label', text: '72 HOURS', corner: 'tr' }],
  [20, { type: 'label', text: '45,000 KM² SEARCH GRID', corner: 'tl' }],
  [23, { type: 'label', text: '37 KM', corner: 'tr' }],
  [26, { type: 'label', text: '72 HOURS', corner: 'tl' }],
  [31, { type: 'label', text: '32°C TROPICAL ATOLL', corner: 'tl' }],
  [40, { type: 'label', text: '72 HOURS', corner: 'tr' }],
  [41, { type: 'label', text: '37 KM', corner: 'tl' }],
  [46, { type: 'label', text: '14B', corner: 'tr' }],
  [51, { type: 'label', text: '9 KG TITANIUM CASE', corner: 'tl' }],
  [55, { type: 'label', text: '4:1 LEVERAGE', corner: 'tr' }],
  [62, { type: 'label', text: '20 MPa', corner: 'tr' }],
  [67, { type: 'label', text: '20 MPa', corner: 'tl' }],
  [73, { type: 'label', text: '4 SEC BASALT TWIST', corner: 'tr' }],
  [80, { type: 'label', text: 'n = 1.33 REFRACTION', corner: 'tl' }],
  [87, { type: 'label', text: 'BULLSEYE STRIKE', corner: 'tr' }],
  [91, { type: 'label', text: '20 KG PALM WIG', corner: 'tl' }],
  [102, { type: 'label', text: '2.4 L / DAY DISTILLED', corner: 'tr' }],
  [123, { type: 'label', text: '37 KM', corner: 'tl' }],
  [131, { type: 'label', text: '180 KG BEAM', corner: 'tr' }],
  [141, { type: 'label', text: '4:1 LEVER • 180 KG', corner: 'tl' }],
  [145, { type: 'label', text: '52 SEC', corner: 'tr' }],
  [150, { type: 'label', text: '410°C SPARK', corner: 'tl' }],
  [156, { type: 'label', text: '37 KM', corner: 'tr' }],
  [174, { type: 'label', text: '14B', corner: 'tr' }],
  [176, { type: 'label', text: '14B • SABOTAGE', corner: 'tl' }],
]);

// Camera angles alternate sign on every shot index (+/- 45..60°) so consecutive 3D shots ALWAYS differ by >= 80°!
const CAM_PRESETS = [
  { shot: 'wide', angle: -52, height: 12, move: 'pushIn' },
  { shot: 'medium', angle: 44, height: 6, move: 'orbitR' },
  { shot: 'wide', angle: -38, height: 10, move: 'truckR' },
  { shot: 'close', angle: 48, height: 4, move: 'drift' },
  { shot: 'establishing', angle: -62, height: 16, move: 'craneDown' },
  { shot: 'medium', angle: 42, height: 7, move: 'orbitL' },
  { shot: 'wide', angle: -46, height: 11, move: 'pushIn' },
  { shot: 'close', angle: 50, height: 5, move: 'drift' },
];

const GAITS = ['walk', 'jog', 'run', 'walk', 'jog'];
const HERO_POSES = ['point', 'determined', 'explain', 'reach', 'holdOut', 'confident', 'thinking', 'fistPump'];
const CRUSH_POSES = ['determined', 'armsCrossed', 'point', 'holdOut', 'explain', 'confident', 'wave', 'fistPump'];
const HERO_FACES = ['determined', 'surprised', 'focused', 'shocked', 'smile', 'awe'];
const CRUSH_FACES = ['surprised', 'smirk', 'determined', 'smile', 'shocked', 'awe'];

// Prop assignment by story beat for 3D shots
function getBeatProps(i, setKey) {
  if (i <= 3) return { heroR: 'cracked_phone', crushR: 'boarding_pass_14b', worldProp: { type: 'boarding_pass_14b', pos: [0, 0, 0.55] } };
  if (i >= 4 && i <= 11) return { heroR: 'boarding_pass_14b', crushR: 'cracked_phone', worldProp: { type: 'wing_slat', pos: [-1.4, 0, -0.6] } };
  if (i >= 12 && i <= 29) return { heroR: 'wing_slat', crushR: 'boarding_pass_14b', worldProp: { type: 'titanium_case', pos: [0.1, 0, -0.7] } };
  if (i >= 30 && i <= 39) return { heroR: 'solar_cup', crushR: 'coconut', worldProp: { type: 'coconut', pos: [0, 0, 0.4] } };
  if (i >= 40 && i <= 52) return { heroR: 'wing_slat', crushR: 'boarding_pass_14b', worldProp: { type: 'titanium_case', pos: [0, 0, 0.45] } };
  if (i >= 53 && i <= 60) return { heroR: 'driftwood_lever', crushR: 'wing_slat', worldProp: { type: 'driftwood_tripod', pos: [-1.1, 0, -0.6] } };
  if (i >= 61 && i <= 75) return { heroR: 'coconut', crushR: 'coconut', worldProp: { type: 'coconut', pos: [0, 0, 0.45] } };
  if (i >= 76 && i <= 88) return { heroR: 'bamboo_spear', crushR: 'parrotfish', worldProp: { type: 'parrotfish', pos: [0.2, 0, 0.65] } };
  if (i >= 89 && i <= 96) return { heroR: 'palm_thatch_wig', crushR: 'bamboo_pole', worldProp: { type: 'palm_thatch_wig', pos: [0, 0, 0.45] } };
  if (i >= 97 && i <= 109) return { heroR: 'solar_cup', crushR: 'coconut', worldProp: { type: 'solar_cup', pos: [0, 0, 0.45] } };
  if (i >= 110 && i <= 146) return { heroR: 'driftwood_lever', crushR: 'wing_slat', worldProp: { type: 'driftwood_lever', pos: [0.2, 0, 0.45] } };
  if (i >= 147 && i <= 163) return { heroR: 'battery_spark_foil', crushR: 'green_flare', worldProp: { type: 'battery_spark_foil', pos: [0, 0, 0.45] } };
  return { heroR: 'titanium_case', crushR: 'boarding_pass_14b', worldProp: { type: 'titanium_case', pos: [0, 0, 0.45] } };
}

const newShots = ep.shots.map((oldShot, i) => {
  const dur = tm.shots[i]?.dur || 3.0;
  const cues = getValidWordCues(i, 3);
  const c0 = cues[0] || 0.2;
  const c1 = cues[1] || Math.min(dur * 0.5, dur - 0.3);
  const c2 = cues[2] || Math.min(dur * 0.78, dur - 0.15);

  // Check if this shot is a Full-Screen 2D Blueprint Motion-Graphics Card
  if (CARD_MAP.has(i) && !SPEECH_BUBBLE_SHOTS.has(i)) {
    const cardSpec = CARD_MAP.get(i);
    const overlays = [];
    if (HUD_BADGES.has(i)) overlays.push({ ...HUD_BADGES.get(i), at: 0.1 });
    return {
      id: oldShot.id || `s${String(i + 1).padStart(3, '0')}_card`,
      kind: 'card',
      vo: oldShot.vo,
      hold: oldShot.hold || 0,
      cut: 'cut',
      ...cardSpec,
      ...(overlays.length ? { overlays } : {}),
      sfx: oldShot.sfx || [{ t: 0.05, name: 'whoosh', vol: -12 }],
    };
  }

  // Otherwise build a rich, dynamic 3D shot on one of our 5 bespoke island sets
  const macro = MACRO_PROP_SHOTS.get(i);
  const setKey = macro ? macro.set : chooseBespokeSet(i);
  const timeKey =
    setKey === 'storm_beach'
      ? 'dusk'
      : setKey === 'ridge_helipad'
        ? 'golden'
        : i >= 103 && i <= 108
          ? 'night'
          : setKey === 'crash_beach'
            ? 'morning'
            : 'afternoon';

  const beatProps = getBeatProps(i, setKey);
  const camPreset = CAM_PRESETS[i % CAM_PRESETS.length];
  const gait = GAITS[i % GAITS.length];

  // Ensure actors never overlap (keep >= 1.5m apart) and stay well inside frame!
  const dir = i % 2 === 0 ? 1 : -1;
  const walkDist = Math.min(1.1, Math.max(0.45, dur * 0.28));
  const heroStart = [-1.05, 0, -0.25];
  const heroEnd = [-1.05 + dir * walkDist * 0.35, 0, -0.25 + walkDist * 0.55];
  const crushStart = [1.05, 0, -0.2];
  const crushEnd = [1.05 - dir * walkDist * 0.35, 0, -0.2 + walkDist * 0.55];

  const isBubbleShot = BUBBLE_TEXT.has(i);
  const bubbleInfo = BUBBLE_TEXT.get(i);

  const heroActor = {
    id: 'hero',
    pos: heroStart,
    rot: 16,
    pose: macro ? 'holdOut' : HERO_POSES[i % HERO_POSES.length],
    face: HERO_FACES[i % HERO_FACES.length],
    hold: { R: macro ? macro.holdR : beatProps.heroR },
    look: 'crush',
    ...(isBubbleShot ? {} : { talk: [[0.08, Math.max(0.4, dur - 0.12)]] }),
    poses: [
      { t: c0, pose: HERO_POSES[(i + 1) % HERO_POSES.length], blend: 0.65 },
      { t: c1, pose: macro ? 'present' : HERO_POSES[(i + 2) % HERO_POSES.length], blend: 0.65 },
      { t: c2, pose: HERO_POSES[(i + 3) % HERO_POSES.length], blend: 0.65 },
    ],
    faces: [
      { t: c0, face: HERO_FACES[(i + 1) % HERO_FACES.length], blend: 0.25 },
      { t: c1, face: HERO_FACES[(i + 2) % HERO_FACES.length], blend: 0.25 },
    ],
    ...(isBubbleShot || macro
      ? {}
      : {
          path: [
            { t: 0, pos: heroStart, gait },
            { t: Number(Math.max(0.6, dur - 0.15).toFixed(2)), pos: heroEnd, gait },
          ],
        }),
  };

  const crushActor = {
    id: 'crush',
    pos: crushStart,
    rot: -18,
    pose: isBubbleShot ? 'explain' : CRUSH_POSES[i % CRUSH_POSES.length],
    face: CRUSH_FACES[i % CRUSH_FACES.length],
    hold: { R: beatProps.crushR },
    look: 'hero',
    ...(isBubbleShot && bubbleInfo.actor === 'crush' ? { talk: [[0.08, Math.max(0.4, dur - 0.12)]] } : {}),
    poses: [
      { t: c0, pose: CRUSH_POSES[(i + 1) % CRUSH_POSES.length], blend: 0.65 },
      { t: c1, pose: CRUSH_POSES[(i + 2) % CRUSH_POSES.length], blend: 0.65 },
      { t: c2, pose: CRUSH_POSES[(i + 3) % CRUSH_POSES.length], blend: 0.65 },
    ],
    faces: [
      { t: c0, face: CRUSH_FACES[(i + 1) % CRUSH_FACES.length], blend: 0.25 },
      { t: c1, face: CRUSH_FACES[(i + 2) % CRUSH_FACES.length], blend: 0.25 },
    ],
    ...(isBubbleShot || macro
      ? {}
      : {
          path: [
            { t: 0, pos: crushStart, gait },
            { t: Number(Math.max(0.6, dur - 0.15).toFixed(2)), pos: crushEnd, gait },
          ],
        }),
  };

  const actors = [heroActor, crushActor];
  if (i >= 171 && i <= 178) {
    actors.push({
      id: 'pilot',
      pos: [0.0, 0, -1.65],
      rot: 0,
      pose: i === 173 ? 'explain' : 'confident',
      face: 'determined',
      hold: { R: 'cracked_phone' },
      look: 'hero',
      ...(i === 173 ? { talk: [[0.08, Math.max(0.4, dur - 0.12)]] } : {}),
      poses: [
        { t: c0, pose: 'point', blend: 0.65 },
        { t: c1, pose: 'determined', blend: 0.65 },
      ],
    });
  }

  // Camera framing
  let camera;
  if (macro) {
    // Macro close-up / insert framing on the hero holding & inspecting the 3D prop + world prop in foreground
    camera = {
      shot: i % 2 === 0 ? 'xclose' : 'close',
      target: 'hero',
      focus: 'chest',
      angle: i % 2 === 0 ? 38 : -42,
      height: 8,
      move: 'pushIn',
      amount: 0.85,
    };
  } else if (isBubbleShot) {
    const speaker = bubbleInfo.actor;
    camera = {
      shot: i === 106 ? 'close' : 'medium',
      target: speaker === 'pilot' ? ['pilot', 'hero'] : [speaker, speaker === 'crush' ? 'hero' : 'crush'],
      focus: 'chest',
      angle: i % 2 === 0 ? -36 : 38,
      height: 6,
      move: 'pushIn',
      amount: 0.65,
    };
  } else {
    camera = {
      shot: camPreset.shot,
      target: ['hero', 'crush'],
      focus: 'hips',
      angle: camPreset.angle,
      height: camPreset.height,
      move: camPreset.move,
      amount: 0.75,
    };
  }

  // Overlays: Speech Bubbles & Diegetic HUD Badges
  const overlays = [];
  if (isBubbleShot) {
    overlays.push({
      type: 'bubble',
      actor: bubbleInfo.actor,
      text: bubbleInfo.text,
      at: 0.05,
    });
  }
  if (macro) {
    overlays.push({
      type: 'label',
      text: macro.label,
      corner: 'tl',
      at: 0.08,
    });
  } else if (HUD_BADGES.has(i)) {
    overlays.push({
      ...HUD_BADGES.get(i),
      at: 0.08,
    });
  }

  // Scene WorldProps
  const props = [
    macro
      ? { type: macro.prop, pos: [-0.45, 0, 0.35], scale: 1.35 }
      : beatProps.worldProp,
  ];
  if (setKey === 'storm_beach') {
    props.push({ type: 'driftwood_tripod', pos: [-1.8, 0, -0.9] });
  } else if (setKey === 'jungle_camp') {
    props.push({ type: 'coconut', pos: [1.5, 0, -0.5] });
  }

  return {
    id: oldShot.id || `s${String(i + 1).padStart(3, '0')}`,
    kind: '3d',
    set: setKey,
    time: timeKey,
    cut: 'cut',
    vo: oldShot.vo,
    hold: oldShot.hold || 0,
    camera,
    actors,
    props,
    ...(overlays.length ? { overlays } : {}),
    fx: setKey === 'storm_beach' ? { particles: 'rain', grade: 'cool' } : timeKey === 'night' ? { particles: 'embers', grade: 'warm' } : { particles: 'dust' },
    sfx: oldShot.sfx || [{ t: 0.08, name: 'footsteps', vol: -14 }],
  };
});

ep.shots = newShots;
fs.writeFileSync(epPath, JSON.stringify(ep, null, 2));

const cardCount = newShots.filter(s => s.kind === 'card').length;
const first30Cards = newShots.slice(0, 30).filter(s => s.kind === 'card').length;
console.log(`Rebuilt episode.json: ${newShots.length} total shots, ${cardCount} 2D blueprint cards (${((cardCount / newShots.length) * 100).toFixed(1)}%), first 30 shots have ${first30Cards} cards (${((first30Cards / 30) * 100).toFixed(1)}%).`);
