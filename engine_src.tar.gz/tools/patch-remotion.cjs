// Ensures @remotion/renderer captures WebGL2 <canvas> surfaces reliably in headless Chromium
// across Linux container (Mesa llvmpipe/Lavapipe/ANGLE) and Android Termux environments.
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

// 1. Default chromeMode to 'chrome-for-testing' (--headless=new) for Chromium 130+
const chromeModeFile = path.join(root, 'node_modules/@remotion/renderer/dist/options/chrome-mode.js');
if (fs.existsSync(chromeModeFile)) {
  let code = fs.readFileSync(chromeModeFile, 'utf8');
  code = code.replace(
    /return chromeMode !== null && chromeMode !== void 0 \? chromeMode : 'headless-shell';/g,
    "return chromeMode !== null && chromeMode !== void 0 ? chromeMode : 'chrome-for-testing';"
  );
  fs.writeFileSync(chromeModeFile, code);
}

// 2. Copy WebGL <canvas> pixels to an overlay <img> right before Page.captureScreenshot
const screenshotFile = path.join(root, 'node_modules/@remotion/renderer/dist/screenshot-task.js');
if (fs.existsSync(screenshotFile)) {
  let code = fs.readFileSync(screenshotFile, 'utf8');
  if (!code.includes('data-remotion-gl-copy')) {
    const target = 'await (0, screenshot_background_1.setScreenshotBackground)(page, omitBackground);';
    const bridge = `${target}
    await page.evaluate(async () => {
      for (const c of Array.from(document.querySelectorAll('canvas'))) {
        try {
          const dataUrl = c.toDataURL('image/jpeg', 0.92);
          if (dataUrl && dataUrl.length > 100 && c.parentElement) {
            let img = c.parentElement.querySelector('img[data-remotion-gl-copy="1"]');
            if (!img) {
              img = document.createElement('img');
              img.setAttribute('data-remotion-gl-copy', '1');
              img.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;';
              c.parentElement.appendChild(img);
            }
            img.src = dataUrl;
            if (img.decode) await img.decode().catch(() => {});
          }
        } catch (_e) {}
      }
    }).catch(() => {});`;
    code = code.replace(target, bridge);
    fs.writeFileSync(screenshotFile, code);
  }
}
console.log('Patched @remotion/renderer for headless WebGL2 capture.');
