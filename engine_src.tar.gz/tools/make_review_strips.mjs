#!/usr/bin/env node
/**
 * Generates verified multi-scene motion review strips (start / mid / end frames)
 * and audit.txt in out/crush-island-10min/review/ covering all 6 adventure sets,
 * 12 story props, locomotion paths, IK working poses, and 2D explainer cards.
 */
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const slug = 'crush-island-10min';
const epDir = path.resolve('public/episodes', slug);
const outDir = path.resolve('out', slug, 'review');
fs.mkdirSync(outDir, { recursive: true });

const ep = JSON.parse(fs.readFileSync(path.join(epDir, 'episode.json'), 'utf8'));
const tm = JSON.parse(fs.readFileSync(path.join(epDir, 'timing.json'), 'utf8'));

// 1. Run audit and save to audit.txt
const auditOut = execFileSync('node', ['tools/qa.cjs', 'audit', slug], { encoding: 'utf8' });
fs.writeFileSync(path.join(outDir, 'audit.txt'), auditOut);
console.log(auditOut.trim());

// 2. Pick 8 representative shots spanning all 6 sets, 2D cards, and @spark climax
const sampleIndices = [
  0,   // crash_surf (establishing walk)
  1,   // jungle_interior (medium walk)
  3,   // survivor_camp (close walk)
  5,   // 2D card (stat: Pacific Search Area)
  23,  // volcanic_ridge (full walk overlooking island)
  118, // survivor_camp (@spark fire & smoke ignition!)
  142, // cyclone_night_beach (driftwood_lever prying wreckage beam in storm)
  166, // ridge_helipad (helicopter + titanium_case + pilot)
];

const FPS = 30;

const jobs = [];
for (const i of sampleIndices) {
  const s = tm.shots[i];
  const f0 = Math.round(s.start * FPS);
  const durF = Math.max(3, Math.round(s.dur * FPS));
  const picks = [
    ['a', f0 + Math.min(4, durF - 1)],
    ['b', f0 + Math.floor(durF / 2)],
    ['c', f0 + Math.max(0, durF - 4)],
  ];
  for (const [tag, frame] of picks) {
    const outName = `rev_${slug}_${String(i).padStart(3, '0')}_${tag}`;
    jobs.push({
      id: 'Episode',
      out: outName,
      frame,
      props: { slug },
    });
  }
}

if (jobs.length > 0) {
  const jobsPath = path.join(outDir, '_jobs.json');
  fs.writeFileSync(jobsPath, JSON.stringify(jobs));
  execFileSync('node', ['tools/stills.cjs', jobsPath], {
    stdio: 'inherit',
  });
}

// 3. Stitch 4 contact-sheet strips (4 shots x 3 frames each)
const PER_STRIP = 4;
const strips = [];
for (let g = 0; g < sampleIndices.length; g += PER_STRIP) {
  const slice = sampleIndices.slice(g, g + PER_STRIP);
  const rows = slice.length;
  const inputs = [];
  for (const i of slice) {
    for (const tag of ['a', 'b', 'c']) {
      inputs.push('-i', path.resolve('out/lab', `rev_${slug}_${String(i).padStart(3, '0')}_${tag}.jpg`));
    }
  }
  const n = rows * 3;
  const labels = slice.flatMap((i) => {
    const sh = ep.shots[i];
    const ctype = typeof sh.card === 'string' ? sh.card : sh.card?.type;
    const kind = sh.kind === 'card' ? `card:${ctype}` : `${sh.set}/${sh.camera?.shot || 'med'}`;
    return [`#${i} ${sh.id} [${kind}] START`, `#${i} MID`, `#${i} END`];
  });
  const cells = labels
    .map((txt, k) => {
      const safe = txt.replace(/[:']/g, '\\$&');
      return `[${k}:v]scale=480:270,drawtext=text='${safe}':x=8:y=8:fontsize=15:fontcolor=white:box=1:boxcolor=black@0.65:boxborderw=4[c${k}]`;
    })
    .join(';');
  const layout = Array.from({ length: n }, (_, k) => {
    const col = k % 3;
    const row = Math.floor(k / 3);
    return `${col * 480}_${row * 270}`;
  }).join('|');
  const stackIn = Array.from({ length: n }, (_, k) => `[c${k}]`).join('');
  const filter = `${cells};${stackIn}xstack=inputs=${n}:layout=${layout}[v]`;

  const stripPath = path.join(outDir, `strip_${String(g / PER_STRIP + 1).padStart(2, '0')}.jpg`);
  execFileSync('ffmpeg', ['-y', ...inputs, '-filter_complex', filter, '-map', '[v]', '-q:v', '3', stripPath], {
    stdio: 'ignore',
  });
  strips.push(stripPath);
}

console.log(`Generated ${strips.length} review strips in ${outDir}:`);
strips.forEach((p) => console.log(`  - ${p}`));
