---
name: project-fish-pending
description: "Fish Audio MCP was NOT connected when this copy was set up; run docs/FISH_SETUP.md the first time Fish tools appear, before any voice or thumbnail work"
metadata:
  type: project
---

This copy of the project was set up from `project instructions.md` without the Fish Audio MCP. The user will connect it afterwards.

**Why:** voice-over (TTS) and `fish`-mode thumbnails need Fish. The voice ids must be reachable from the connected team, and the thumbnail reference keys in `thumbnails/refs/refs.json` came from another Fish workspace, so they must be uploaded again.

**How to apply:**
- In any session where Fish tools are available (`get_credit_balance`, `text_to_speech`, …), run `docs/FISH_SETUP.md` first, then replace this memory with a short "Fish connected" reference.
- Until then, take episodes up to the draft preview, then ask the user to connect Fish Audio.
- Related: [[project-narrator-voice]], [[project-thumbnails-gpt-image]].
