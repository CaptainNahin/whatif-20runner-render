---
description: Make a full "What If" Minecraft 3D episode or Business Promo from a topic, then generate its 3 thumbnails
argument-hint: <video topic or promo mode, e.g. What If You Could Swap Places With Anyone | promo:auraquant | promo:primenself | promo:antigravity>
---

# /stickman: topic → finished video + 3 thumbnails (plus Business Promo & Native Ad Module)

Topic: **$ARGUMENTS**

If the topic is empty, ask for one and stop.

Make one complete narrated episode (or high-retention Business Promo / Native Ad integration) about this topic with the saved hero, then generate its 3 thumbnails. Follow `CLAUDE.md` ("Making a narrated episode") step by step; this command only fixes the choices below. Keep a task list for the whole run.

## Fixed choices

- **Hero:** the saved character, the `hero` entry in `src/cast.ts` (classic **Steve** articulated 3D Minecraft voxel character: `#00a8b5` cyan tee, `#38275e` dark indigo pants, `#4a3121` brown pixel hair, `#b58463` warm skin tone), exactly as it is. Never call the protagonist "Steve" out loud in narration (always address the viewer in second-person as "you" / "your"), don't change the outfit, and keep its signature cyan `#00a8b5` colour off everyone else (CLAUDE.md, "… belongs to the hero").
- **Supporting Cast:** articulated 3D Minecraft voxel characters in `src/cast.ts` modeled after Sunny (`bestie`), Alex (`sister`), Makena (`mom`), Noor (`dad`), Ari (`teacher`), Zuri (`coach`), Kai (`rival`), and Dr. Efe (`scientist`).
- **Idea:** the topic replaces the idea step. Skip candidate generation and pitching. Shape it into a "What If" title (keep the user's wording when it already is one), run `python -I tools/ideas/novelty.py "<title>"`, and mention any close competitor title in the summary.
- **Slug:** short kebab-case from the title, not already used in `public/episodes/`.
- **Length:** 8–10 minutes unless the user's topic says otherwise (or 30–60s for standalone Business Promo spots, or a 20–30s mid-roll native ad inside a full episode).
- **Voice, music, look:** the house defaults in `CLAUDE.md` and memory (with automatic Google Cloud TTS fallback in `tools/episode.mjs` when Fish Audio MCP is not connected).

## Business Promo & Native Ad Module (`src/cards/promo.tsx`)

Whenever the topic requests a commercial, sponsor integration, or native mid-roll segment, weave a 3D Minecraft scene (e.g. `hero` and `scientist` / `bestie` reacting to a live holo-board in `set: "lab"` or `set: "city"`) directly into a sleek 2D Remotion motion-graphics card from `src/cards/promo.tsx`:

1. **AuraQuant v5 APEX (`card: "auraquant"` or `card: "promo", brand: "auraquant"`)**
   - **Positioning:** Algorithmic TradingView quant indicator & execution signals with live win-rate, profit-factor, and dynamic ATR stop-loss explainer cards.
2. **PrimeNself Studio (`card: "primenself"` or `card: "promo", brand: "primenself"`)**
   - **Positioning:** $500 flat-rate, 48-hour B2B website redesign & conversion engineering agency.
3. **Antigravity Creator Studio / CaptainNahin (`card: "antigravity"` or `card: "promo", brand: "antigravity"`)**
   - **Positioning:** Autonomous 3D Minecraft + Remotion 4 + Cloud Build AI video production pipeline by CaptainNahin.

## Run

1. **Script** (`docs/story/STORY_BLUEPRINT.md`): beat sheet, script, plant ledger, fact check and score in `script_notes.md`.
2. **Shot list:** `episode.json`, then `node tools/episode.mjs draft <slug>`, `npm test` and `node tools/qa.cjs audit <slug>`. Fix every error.
3. **One checkpoint before spending credits.** Check the Fish balance (`get_credit_balance`) and show the user, in one message:
   - the title and a short synopsis;
   - the script score and the path to `script.md`;
   - the credit estimate: voice (`node tools/episode.mjs sections <slug>` bytes) plus thumbnails (3 × the per-image cost in `thumbnails/config.json`, fish mode only).
   
   Wait for one OK. That OK covers the voice and the 3 thumbnails; don't ask again for either. If the balance is too low, say so and stop there. If Fish isn't connected yet, `node tools/episode.mjs tts <slug>` synthesizes voiceovers and word cues automatically via Google Cloud TTS.
4. **Voice, align, pre-render review:** CLAUDE.md steps 5–7, including the independent reviewer rounds. Build only on "ready for final render".
5. **Build and check:** steps 8–9 (`node tools/build-episode.mjs <slug>` locally or `./cloud_render.sh <slug>` on Google Cloud Build `E2_HIGHCPU_32`). Re-render broken ranges until the sheets are clean.
6. **Thumbnails:** step 10, with the video now finished:
   - write `thumbnails/<slug>/brief.json` with exactly 3 variants (one scene per variant, drawn from the episode's strongest moments), then `node tools/thumb-prompt.mjs <slug>`;
   - `fish` mode: run `estimate_image_edit`, then submit all 3 jobs (already approved at the checkpoint), poll them together, and save each to `thumbnails/<slug>/out/<id>_2k_medium.png`. Review each at full size and at ~360 px; regenerate one only if it fails the step-10 checks (spelling, hero colour, voxel-only cast, no stray text), and only within the approved credits;
   - `chatgpt` mode: send `CHATGPT.md` and the three prompt files instead.
7. **Update `final/README.md`** with the new episode row.

## Deliver

Keep the final message short:
1. send the video, `final/<Episode title>.mp4`, with SendUserFile (`display: "render"`);
2. send the 3 thumbnails with SendUserFile in one call, captioned A / B / C with their text;
3. one or two lines: title, length, and any warning you accepted. Ask which thumbnail to pick (`node tools/thumb-prompt.mjs <slug> --pick <id>`).
