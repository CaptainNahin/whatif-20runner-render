# Fish Audio: first-connect checklist

This copy of the project was set up before the Fish Audio MCP was connected. Run this checklist once, the first time Fish tools are available in a session. Their names end in `get_credit_balance`, `text_to_speech`, `get_voice`, `search_voices`, `list_my_workspaces`, `create_media_upload` and `get_media_model`. If they appear only as deferred tools, load them with ToolSearch first.

Until then, everything except voice-over and Fish-made thumbnails works:
- ideas, scripts, shot lists and `draft` previews;
- short shots with Python sound;
- audits, reviews and preview renders.

If the user asks for an episode before Fish is connected, go up to the preview (CLAUDE.md long-form step 4). Then ask them to connect Fish Audio and start a new chat in this folder.

Run this checklist again whenever the Fish account changes: the voice ids and thumbnail references must be reachable from the connected team.

## Choices made at setup

- Narrator voice: Warm Storyteller (the default)
- Thumbnails: `fish` mode (`thumbnails/config.json`)

## Steps

1. **Connection.** Call `get_credit_balance` and tell the user which team is connected and its credit balance. The connection is bound to the team chosen when Fish was authorized; to use another team, the user reconnects Fish.

2. **House voices.** Call `get_voice` for each id in `HOUSE_VOICES` (`tools/episode.mjs`):
   - narrator "Warm Storyteller" `5c8dc6a69c0b4edfb32634db6384bf34`;
   - male "Teen" `23c536451dd94b70b0d4ab0e8a630e1d`;
   - female "Sarah" `933563129e564b19a115bedd57b7406a`.

   Each one must resolve. If one doesn't, use `search_voices` to find 2–3 close matches (calm warm English storyteller; young friendly male; young natural female) and let the user pick. Then update the id everywhere it appears: `HOUSE_VOICES`, the **Voice** section of `CLAUDE.md`, `public/episodes/pipetest/episode.json` (`voice.id`), and the voice memory.

3. **Narrator audition.** Do this only if the setup choice above says "audition".
   1. Pick three narrator candidates with `search_voices` (calm, warm, storyteller, English) and add Warm Storyteller as a fourth.
   2. `get_voice` returns a free sample URL for each. Download the samples into `voice_auditions/` (`curl.exe -L -o voice_auditions/<n>_<name>.mp3 "<url>"`) and send them with SendUserFile.
   3. If the user wants a fair side-by-side test, offer to read one ~250-byte paragraph with each voice. That costs about 1 credit per byte, ~1,000 credits in all. Get their OK, then call `text_to_speech` with model `drama-3` and the house direction `[calm, warm storyteller, unhurried, relaxed pace, gentle pauses between sentences]`.
   4. Once the user picks, update `HOUSE_VOICES.narrator`, the **Voice** section of `CLAUDE.md`, `pipetest`'s `voice.id` and the voice memory.

4. **Voice smoke test.**
   1. Call `text_to_speech` with `dry_run: true`: one short sentence, the narrator voice, `drama-3`. This free quote proves the call shape.
   2. Ask the user before spending ~60 credits on a real call.
   3. Download the returned `audio_url` with `curl.exe -L -o voice_auditions/fish_test.mp3 "<url>"`. `ffprobe` must show a duration over 1 s. This is the same download `node tools/episode.mjs fetch` does for every section.

5. **Thumbnail model.** Skip this step in `chatgpt` mode.
   1. Call `get_media_model` with the `model_id` in `thumbnails/config.json` (`gpt-image-2.5-flare`).
   2. Check that it accepts the `parameters` there (16:9, 2K, medium) and `ref` image inputs, and keep its `parameter_schema`.
   3. If the model is gone or renamed, call `list_media_models`, propose the closest GPT Image model, and ask before you change `config.json`.

6. **Thumbnail references.** Skip this step in `chatgpt` mode. The `object_key`s in `thumbnails/refs/refs.json` belong to the Fish workspace the project was packed from, so upload the three images again, in order. Uploads are free.
   1. `list_my_workspaces` gives the `workspace_id`.
   2. For each `thumbnails/refs/<file>`, call `create_media_upload` with `file_name` (`ref1_paused.webp`, etc.), the exact byte size and `image/webp`.
   3. PUT the file to the returned `upload_url`: `curl.exe -X PUT -H "Content-Type: image/webp" --data-binary "@thumbnails/refs/<file>" "<upload_url>"`.
   4. Write each new `object_key` into `refs.json`, keeping the order, and set `uploaded` to today's date.

7. **Finish.**
   - Delete the "Fish Audio is not connected yet" note at the top of `CLAUDE.md`.
   - Replace the memory file `project-fish-pending.md` with a short `reference` memory: "Fish Audio connected <date>, team <name>, thumbnail refs uploaded <date>". Update its line in `MEMORY.md`.
   - Add "Last run: <date>, team <name>" under the title of this file and keep the file, for the next account change.
   - Tell the user what was checked, what changed, and what it cost.

## Costs to keep in mind

- Voice: 1 credit per UTF-8 byte of text. A 10-minute script is about 9–12k credits. Check `get_credit_balance` before voicing.
- Thumbnails (`fish` mode): 1,601 credits per 2K variant, so 3 variants are about 4.8k per episode.
- Fish AI video models are not used for episodes. A clip costs 1.4k–53k credits, and the procedural engine is free.
