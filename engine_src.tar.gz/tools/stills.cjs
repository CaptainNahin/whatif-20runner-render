// Bundle once, render many stills (~1 s each instead of ~15 s per CLI call).
// Usage: node tools/stills.cjs jobs.json   → out/lab/<out>.jpg (or .png if out ends with .png / format==="png")
// jobs.json: [{ "out": "city_1", "id": "SetLab", "props": {...}, "frame": 0 }]  (id defaults to SetLab)
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const ROOT = path.resolve(__dirname, '..');
const { createRequire } = require('module');
const req = createRequire(path.join(ROOT, 'package.json'));
const { bundle } = req('@remotion/bundler');
const { selectComposition, renderFrames, renderStill, openBrowser } = req('@remotion/renderer');

function findBrowserExecutable() {
  if (process.env.REMOTION_CHROME_EXECUTABLE && fs.existsSync(process.env.REMOTION_CHROME_EXECUTABLE)) {
    return process.env.REMOTION_CHROME_EXECUTABLE;
  }
  const candidates = [
    '/data/data/com.termux/files/usr/bin/chromium',
    '/data/data/com.termux/files/usr/bin/chromium-browser',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return undefined;
}

function buildEpisodeFrameHashLookup(slug, reviewFlag) {
  try {
    const epDir = path.join(ROOT, 'public', 'episodes', slug);
    const ep = JSON.parse(fs.readFileSync(path.join(epDir, 'episode.json'), 'utf8'));
    const tm = JSON.parse(fs.readFileSync(path.join(epDir, 'timing.json'), 'utf8'));
    const fps = tm.fps || ep.fps || 30;
    const shotHashes = ep.shots.map((s, i) => {
      const prev = i > 0 ? ep.shots[i - 1] : null;
      const tms = tm.shots[i] || {};
      const payload = JSON.stringify({ s, prevSet: prev?.set, prevTime: prev?.time, tms, reviewFlag });
      return crypto.createHash('sha1').update(payload).digest('hex').slice(0, 16);
    });
    return frame => {
      for (let i = 0; i < tm.shots.length; i++) {
        const s = tm.shots[i];
        const f0 = i === 0 ? 0 : Math.round(s.start * fps);
        const f1 = Math.round((s.start + s.dur) * fps);
        if (frame >= f0 && frame < f1) {
          return `${slug}_${i}_${shotHashes[i]}_f${frame - f0}`;
        }
      }
      return `${slug}_f${frame}`;
    };
  } catch {
    return null;
  }
}

(async () => {
  const jobs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const t0 = Date.now();
  const browserExecutable = findBrowserExecutable();
  const gl = process.platform === 'android' ? 'swangle' : 'angle';
  const bundleDir = path.join(ROOT, 'out', 'bundle');
  const hasBundle = fs.existsSync(path.join(bundleDir, 'index.html')) && !process.env.REBUNDLE;
  const serveUrl = hasBundle
    ? bundleDir
    : await bundle({
        entryPoint: path.join(ROOT, 'src/index.ts'),
        publicDir: path.join(ROOT, 'public'),
        outDir: bundleDir,
      });

  // Always sync latest episode JSON/timing files into bundleDir/public/episodes so cached bundle is never stale
  if (hasBundle) {
    const srcEpDir = path.join(ROOT, 'public', 'episodes');
    const dstEpDir = path.join(bundleDir, 'public', 'episodes');
    if (fs.existsSync(srcEpDir)) {
      fs.mkdirSync(dstEpDir, { recursive: true });
      for (const slug of fs.readdirSync(srcEpDir)) {
        const sDir = path.join(srcEpDir, slug);
        if (!fs.statSync(sDir).isDirectory()) continue;
        const dDir = path.join(dstEpDir, slug);
        fs.mkdirSync(dDir, { recursive: true });
        for (const f of ['episode.json', 'timing.json']) {
          if (fs.existsSync(path.join(sDir, f))) {
            fs.copyFileSync(path.join(sDir, f), path.join(dDir, f));
          }
        }
      }
    }
  }

  console.log('bundled in', ((Date.now() - t0) / 1000).toFixed(1), 's');
  fs.mkdirSync(path.join(ROOT, 'out/lab'), { recursive: true });
  const cacheDir = path.join(ROOT, 'out', '.stills_cache');
  fs.mkdirSync(cacheDir, { recursive: true });

  // Group jobs by (id, props, isPng) so batches sharing a composition use persistent-tab renderFrames()
  const groups = new Map();
  for (const j of jobs) {
    const cid = j.id || 'SetLab';
    const isPng = j.format === 'png' || String(j.out).endsWith('.png');
    const outName = String(j.out).endsWith('.png') || String(j.out).endsWith('.jpg')
      ? j.out
      : j.out + (isPng ? '.png' : '.jpg');
    const outPath = path.join(ROOT, 'out/lab', outName);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    const key = JSON.stringify([cid, j.props || {}, isPng]);
    if (!groups.has(key)) {
      const hashFn = cid === 'Episode' && j.props?.slug
        ? buildEpisodeFrameHashLookup(j.props.slug, !!j.props.review)
        : null;
      groups.set(key, { cid, props: j.props || {}, isPng, hashFn, byFrame: new Map(), list: [] });
    }
    const g = groups.get(key);
    const frame = j.frame || 0;
    const ext = isPng ? '.png' : '.jpg';
    const cacheFile = g.hashFn && !process.env.NO_STILLS_CACHE
      ? path.join(cacheDir, g.hashFn(frame) + ext)
      : null;

    if (cacheFile && fs.existsSync(cacheFile) && fs.statSync(cacheFile).size > 1024) {
      fs.copyFileSync(cacheFile, outPath);
      console.log('ok (cached)', outName);
      continue;
    }

    if (!g.byFrame.has(frame)) g.byFrame.set(frame, []);
    g.byFrame.get(frame).push({ outName, outPath, rawOut: j.out, cacheFile });
    g.list.push({ frame, outName, outPath, rawOut: j.out, cacheFile });
  }

  const pendingGroups = [...groups.values()].filter(g => g.byFrame.size > 0);
  if (!pendingGroups.length) {
    process.exit(0);
  }

  const browser = await openBrowser('chrome', {
    browserExecutable,
    chromeMode: 'chrome-for-testing',
    chromiumOptions: { gl },
  });

  const concurrency = Math.max(1, parseInt(process.env.STILLS_CONCURRENCY || (process.platform === 'android' ? '6' : '8'), 10));

  for (const g of pendingGroups) {
    try {
      const comp = await selectComposition({
        serveUrl,
        id: g.cid,
        inputProps: g.props,
        puppeteerInstance: browser,
        browserExecutable,
        chromeMode: 'chrome-for-testing',
        chromiumOptions: { gl },
        timeoutInMilliseconds: 600000,
      });

      const uniqueFrames = [...g.byFrame.keys()].sort((a, b) => a - b);
      if (uniqueFrames.length > 1) {
        const CHUNK = 1000;
        for (let i = 0; i < uniqueFrames.length; i += CHUNK) {
          const chunkFrames = uniqueFrames.slice(i, i + CHUNK);
          await renderFrames({
            composition: comp,
            serveUrl,
            outputDir: null,
            inputProps: g.props,
            frames: chunkFrames,
            imageFormat: g.isPng ? 'png' : 'jpeg',
            jpegQuality: g.isPng ? undefined : 88,
            muted: true,
            puppeteerInstance: browser,
            browserExecutable,
            chromeMode: 'chrome-for-testing',
            chromiumOptions: { gl },
            concurrency,
            timeoutInMilliseconds: 600000,
            onStart: () => {},
            onFrameUpdate: () => {},
            onFrameBuffer: (buf, frame) => {
              const targets = g.byFrame.get(frame) || [];
              for (const t of targets) {
                fs.writeFileSync(t.outPath, buf);
                if (t.cacheFile) {
                  try { fs.writeFileSync(t.cacheFile, buf); } catch {}
                }
                console.log('ok', t.outName);
              }
            },
          });
        }
      } else {
        const item = g.list[0];
        const t1 = Date.now();
        await renderStill({
          composition: comp,
          serveUrl,
          output: item.outPath,
          inputProps: g.props,
          frame: item.frame,
          imageFormat: g.isPng ? 'png' : 'jpeg',
          jpegQuality: g.isPng ? undefined : 88,
          puppeteerInstance: browser,
          browserExecutable,
          chromeMode: 'chrome-for-testing',
          chromiumOptions: { gl },
          overwrite: true,
          timeoutInMilliseconds: 600000,
        });
        if (item.cacheFile && fs.existsSync(item.outPath)) {
          try { fs.copyFileSync(item.outPath, item.cacheFile); } catch {}
        }
        console.log('ok', item.outName, ((Date.now() - t1) / 1000).toFixed(1), 's');
      }
    } catch (e) {
      for (const item of g.list) {
        if (!fs.existsSync(item.outPath)) {
          console.log('FAIL', item.rawOut, String(e && e.message).slice(0, 600));
        }
      }
    }
  }

  await browser.close({ silent: true });
})();
