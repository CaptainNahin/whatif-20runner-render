// Bundle once, render many stills (~1 s each instead of ~15 s per CLI call).
// Usage: node tools/stills.cjs jobs.json   → out/lab/<out>.jpg (or .png if out ends with .png / format==="png")
// jobs.json: [{ "out": "city_1", "id": "SetLab", "props": {...}, "frame": 0 }]  (id defaults to SetLab)
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const ROOT = path.resolve(__dirname, '..');
const { createRequire } = require('module');
const req = createRequire(path.join(ROOT, 'package.json'));
const { bundle } = req('@remotion/bundler');
const { selectComposition, renderFrames, renderStill, openBrowser } = req('@remotion/renderer');

function findBrowserExecutable() {
  if (process.env.REMOTION_CHROME_EXECUTABLE && fs.existsSync(process.env.REMOTION_CHROME_EXECUTABLE)) {
    return process.env.REMOTION_CHROME_EXECUTABLE;
  }
  const candidates = [
    '/data/data/com.termux/files/usr/bin/chromium',
    '/data/data/com.termux/files/usr/bin/chromium-browser',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return undefined;
}

function computeShotHashes(ep, tm, reviewFlag) {
  return ep.shots.map((s, i) => {
    const prev = i > 0 ? ep.shots[i - 1] : null;
    const tms = tm.shots[i] || {};
    const payload = JSON.stringify({ s, prevSet: prev?.set, prevTime: prev?.time, tms, reviewFlag });
    return crypto.createHash('sha1').update(payload).digest('hex').slice(0, 16);
  });
}

function buildEpisodeFrameHashLookup(slug, reviewFlag) {
  try {
    const epDir = path.join(ROOT, 'public', 'episodes', slug);
    const ep = JSON.parse(fs.readFileSync(path.join(epDir, 'episode.json'), 'utf8'));
    const tm = JSON.parse(fs.readFileSync(path.join(epDir, 'timing.json'), 'utf8'));
    const fps = tm.fps || ep.fps || 30;
    const shotHashes = computeShotHashes(ep, tm, reviewFlag);

    const videoPath = path.join(ROOT, 'out', slug, 'video.mp4');
    const videoEpPath = path.join(ROOT, 'out', slug, 'video_episode.json');
    let videoShotHashes = null;
    if (fs.existsSync(videoPath) && fs.existsSync(videoEpPath)) {
      try {
        const vEp = JSON.parse(fs.readFileSync(videoEpPath, 'utf8'));
        videoShotHashes = computeShotHashes(vEp, tm, reviewFlag);
      } catch {}
    }

    return frame => {
      for (let i = 0; i < tm.shots.length; i++) {
        const s = tm.shots[i];
        const f0 = i === 0 ? 0 : Math.round(s.start * fps);
        const f1 = Math.round((s.start + s.dur) * fps);
        if (frame >= f0 && frame < f1) {
          const shot = ep.shots[i] || {};
          const tLocal = Math.max(0, (frame - Math.round(s.start * fps)) / fps);
          const banner = `#${i} ${shot.id || ''}  t=${tLocal.toFixed(2)}/${s.dur.toFixed(2)}s  [${shot.kind === 'card' ? 'card:' + shot.card : shot.set}]`;
          return {
            key: `${slug}_${i}_${shotHashes[i]}_f${frame - f0}`,
            shotIdx: i,
            matchesVideo: !!(videoShotHashes && videoShotHashes[i] === shotHashes[i]),
            videoPath: fs.existsSync(videoPath) ? videoPath : null,
            banner,
          };
        }
      }
      return { key: `${slug}_f${frame}`, shotIdx: -1, matchesVideo: false, videoPath: null, banner: '' };
    };
  } catch {
    return null;
  }
}

function extractFramesFromVideo(videoPath, items) {
  // Batch extract frames in chunks of 60 using ffmpeg select filter + review banner drawbox
  const BATCH = 60;
  for (let b = 0; b < items.length; b += BATCH) {
    const slice = items.slice(b, b + BATCH);
    for (const it of slice) {
      const ts = (it.frame / 30).toFixed(4);
      const r = spawnSync('ffmpeg', [
        '-y', '-v', 'error',
        '-ss', ts,
        '-i', videoPath,
        '-frames:v', '1',
        '-vf', 'drawbox=x=0:y=0:w=iw:h=42:color=black@0.68:t=fill',
        '-q:v', '3',
        it.outPath,
      ]);
      if (r.status === 0 && fs.existsSync(it.outPath) && fs.statSync(it.outPath).size > 1024) {
        if (it.cacheFile) {
          try { fs.copyFileSync(it.outPath, it.cacheFile); } catch {}
        }
        console.log('ok', it.outName);
      }
    }
  }
}

(async () => {
  const jobs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const t0 = Date.now();
  const browserExecutable = findBrowserExecutable();
  const gl = process.platform === 'android' ? 'swangle' : 'angle';
  const bundleDir = path.join(ROOT, 'out', 'bundle');
  const hasBundle = fs.existsSync(path.join(bundleDir, 'index.html')) && !process.env.REBUNDLE;
  const serveUrl = hasBundle
    ? bundleDir
    : await bundle({
        entryPoint: path.join(ROOT, 'src/index.ts'),
        publicDir: path.join(ROOT, 'public'),
        outDir: bundleDir,
      });

  if (hasBundle) {
    const srcEpDir = path.join(ROOT, 'public', 'episodes');
    const dstEpDir = path.join(bundleDir, 'public', 'episodes');
    if (fs.existsSync(srcEpDir)) {
      fs.mkdirSync(dstEpDir, { recursive: true });
      for (const slug of fs.readdirSync(srcEpDir)) {
        const sDir = path.join(srcEpDir, slug);
        if (!fs.statSync(sDir).isDirectory()) continue;
        const dDir = path.join(dstEpDir, slug);
        fs.mkdirSync(dDir, { recursive: true });
        for (const f of ['episode.json', 'timing.json']) {
          if (fs.existsSync(path.join(sDir, f))) {
            fs.copyFileSync(path.join(sDir, f), path.join(dDir, f));
          }
        }
      }
    }
  }

  console.log('bundled in', ((Date.now() - t0) / 1000).toFixed(1), 's');
  fs.mkdirSync(path.join(ROOT, 'out/lab'), { recursive: true });
  const cacheDir = path.join(ROOT, 'out', '.stills_cache');
  fs.mkdirSync(cacheDir, { recursive: true });

  const groups = new Map();
  const videoExtractByPath = new Map();

  for (const j of jobs) {
    const cid = j.id || 'SetLab';
    const isPng = j.format === 'png' || String(j.out).endsWith('.png');
    const outName = String(j.out).endsWith('.png') || String(j.out).endsWith('.jpg')
      ? j.out
      : j.out + (isPng ? '.png' : '.jpg');
    const outPath = path.join(ROOT, 'out/lab', outName);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    const key = JSON.stringify([cid, j.props || {}, isPng]);
    if (!groups.has(key)) {
      const hashFn = cid === 'Episode' && j.props?.slug
        ? buildEpisodeFrameHashLookup(j.props.slug, !!j.props.review)
        : null;
      groups.set(key, { cid, props: j.props || {}, isPng, hashFn, byFrame: new Map(), list: [] });
    }
    const g = groups.get(key);
    const frame = j.frame || 0;
    const ext = isPng ? '.png' : '.jpg';
    const info = g.hashFn ? g.hashFn(frame) : null;
    const cacheFile = info && !process.env.NO_STILLS_CACHE
      ? path.join(cacheDir, info.key + ext)
      : null;

    if (cacheFile && fs.existsSync(cacheFile) && fs.statSync(cacheFile).size > 1024) {
      fs.copyFileSync(cacheFile, outPath);
      console.log('ok (cached)', outName);
      continue;
    }

    if (info && info.matchesVideo && info.videoPath && !isPng) {
      if (!videoExtractByPath.has(info.videoPath)) videoExtractByPath.set(info.videoPath, []);
      videoExtractByPath.get(info.videoPath).push({ frame, outName, outPath, cacheFile });
      continue;
    }

    if (!g.byFrame.has(frame)) g.byFrame.set(frame, []);
    g.byFrame.get(frame).push({ outName, outPath, rawOut: j.out, cacheFile });
    g.list.push({ frame, outName, outPath, rawOut: j.out, cacheFile });
  }

  for (const [vPath, items] of videoExtractByPath.entries()) {
    extractFramesFromVideo(vPath, items);
  }

  const pendingGroups = [...groups.values()].filter(g => g.byFrame.size > 0);
  if (!pendingGroups.length) {
    process.exit(0);
  }

  const browser = await openBrowser('chrome', {
    browserExecutable,
    chromeMode: 'chrome-for-testing',
    chromiumOptions: { gl },
  });

  const concurrency = Math.max(1, parseInt(process.env.STILLS_CONCURRENCY || (process.platform === 'android' ? '6' : '8'), 10));

  for (const g of pendingGroups) {
    try {
      const comp = await selectComposition({
        serveUrl,
        id: g.cid,
        inputProps: g.props,
        puppeteerInstance: browser,
        browserExecutable,
        chromeMode: 'chrome-for-testing',
        chromiumOptions: { gl },
        timeoutInMilliseconds: 600000,
      });

      const uniqueFrames = [...g.byFrame.keys()].sort((a, b) => a - b);
      if (uniqueFrames.length > 1) {
        const CHUNK = 1000;
        for (let i = 0; i < uniqueFrames.length; i += CHUNK) {
          const chunkFrames = uniqueFrames.slice(i, i + CHUNK);
          await renderFrames({
            composition: comp,
            serveUrl,
            outputDir: null,
            inputProps: g.props,
            frames: chunkFrames,
            imageFormat: g.isPng ? 'png' : 'jpeg',
            jpegQuality: g.isPng ? undefined : 88,
            muted: true,
            puppeteerInstance: browser,
            browserExecutable,
            chromeMode: 'chrome-for-testing',
            chromiumOptions: { gl },
            concurrency,
            timeoutInMilliseconds: 600000,
            onStart: () => {},
            onFrameUpdate: () => {},
            onFrameBuffer: (buf, frame) => {
              const targets = g.byFrame.get(frame) || [];
              for (const t of targets) {
                fs.writeFileSync(t.outPath, buf);
                if (t.cacheFile) {
                  try { fs.writeFileSync(t.cacheFile, buf); } catch {}
                }
                console.log('ok', t.outName);
              }
            },
          });
        }
      } else {
        const item = g.list[0];
        const t1 = Date.now();
        await renderStill({
          composition: comp,
          serveUrl,
          output: item.outPath,
          inputProps: g.props,
          frame: item.frame,
          imageFormat: g.isPng ? 'png' : 'jpeg',
          jpegQuality: g.isPng ? undefined : 88,
          puppeteerInstance: browser,
          browserExecutable,
          chromeMode: 'chrome-for-testing',
          chromiumOptions: { gl },
          overwrite: true,
          timeoutInMilliseconds: 600000,
        });
        if (item.cacheFile && fs.existsSync(item.outPath)) {
          try { fs.copyFileSync(item.outPath, item.cacheFile); } catch {}
        }
        console.log('ok', item.outName, ((Date.now() - t1) / 1000).toFixed(1), 's');
      }
    } catch (e) {
      for (const item of g.list) {
        if (!fs.existsSync(item.outPath)) {
          console.log('FAIL', item.rawOut, String(e && e.message).slice(0, 600));
        }
      }
    }
  }

  await browser.close({ silent: true });
})();
