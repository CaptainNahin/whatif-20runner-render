// Bundle once, render many stills (~1 s each instead of ~15 s per CLI call).
// Usage: node tools/stills.cjs jobs.json   → out/lab/<out>.jpg (or .png if out ends with .png / format==="png")
// jobs.json: [{ "out": "city_1", "id": "SetLab", "props": {...}, "frame": 0 }]  (id defaults to SetLab)
const path = require('path');
const fs = require('fs');
const ROOT = path.resolve(__dirname, '..');
const { createRequire } = require('module');
const req = createRequire(path.join(ROOT, 'package.json'));
const { bundle } = req('@remotion/bundler');
const { selectComposition, renderStill, openBrowser } = req('@remotion/renderer');

function findBrowserExecutable() {
  if (process.env.REMOTION_CHROME_EXECUTABLE && fs.existsSync(process.env.REMOTION_CHROME_EXECUTABLE)) {
    return process.env.REMOTION_CHROME_EXECUTABLE;
  }
  const candidates = [
    '/data/data/com.termux/files/usr/bin/chromium',
    '/data/data/com.termux/files/usr/bin/chromium-browser',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return undefined;
}

(async () => {
  const jobs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const t0 = Date.now();
  const browserExecutable = findBrowserExecutable();
  const gl = process.platform === 'android' ? 'swangle' : 'angle';
  const bundleDir = path.join(ROOT, 'out', 'bundle');
  const serveUrl = fs.existsSync(path.join(bundleDir, 'index.html')) && !process.env.REBUNDLE
    ? bundleDir
    : await bundle({
        entryPoint: path.join(ROOT, 'src/index.ts'),
        publicDir: path.join(ROOT, 'public'),
        outDir: bundleDir,
      });
  console.log('bundled in', ((Date.now() - t0) / 1000).toFixed(1), 's');
  const browser = await openBrowser('chrome', {
    browserExecutable,
    chromeMode: 'chrome-for-testing',
    chromiumOptions: { gl },
  });
  fs.mkdirSync(path.join(ROOT, 'out/lab'), { recursive: true });
  for (const j of jobs) {
    const t1 = Date.now();
    try {
      const comp = await selectComposition({
        serveUrl,
        id: j.id || 'SetLab',
        inputProps: j.props,
        puppeteerInstance: browser,
        browserExecutable,
        chromeMode: 'chrome-for-testing',
        chromiumOptions: { gl },
      });
      const isPng = j.format === 'png' || String(j.out).endsWith('.png');
      const outName = String(j.out).endsWith('.png') || String(j.out).endsWith('.jpg')
        ? j.out
        : j.out + (isPng ? '.png' : '.jpg');
      const out = path.join(ROOT, 'out/lab', outName);
      await renderStill({
        composition: comp,
        serveUrl,
        output: out,
        inputProps: j.props,
        frame: j.frame || 0,
        imageFormat: isPng ? 'png' : 'jpeg',
        jpegQuality: isPng ? undefined : 88,
        puppeteerInstance: browser,
        browserExecutable,
        chromeMode: 'chrome-for-testing',
        chromiumOptions: { gl },
        overwrite: true,
      });
      console.log('ok', outName, ((Date.now() - t1) / 1000).toFixed(1), 's');
    } catch (e) {
      console.log('FAIL', j.out, String(e && e.message).slice(0, 600));
    }
  }
  await browser.close({ silent: true });
})();
