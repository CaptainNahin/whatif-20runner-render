#!/usr/bin/env python3
import json
import os
import subprocess

TIMING_PATH = "/data/data/com.termux/files/home/minecraft_whatif_engine/public/episodes/crush-island-10min/timing.json"
MIX_WAV_PATH = "/data/data/com.termux/files/home/minecraft_whatif_engine/public/episodes/crush-island-10min/mix.wav"
ED_ROOT = "/data/data/com.termux/files/home/EDStudio"
VID_DIR = os.path.join(ED_ROOT, "videos", "087-crush-island-10min")

os.makedirs(VID_DIR, exist_ok=True)

with open(TIMING_PATH, "r") as f:
    timing = json.load(f)

shots_raw = timing["shots"]
total_dur = float(timing["total"])

# Map specific science/math explanation shots (every ~20-25 seconds) to Hyper Builder mode,
# and all character/action/prop shots to Toy-Like 3D mode.
HYPER_SHOT_MAP = {
    7:   ("search_radar",     "45,000 KM²", "SEARCH GRID MATH"),
    12:  ("search_radar",     "12 KM DRIFT", "UPWIND SLIDE RAFTS"),
    15:  ("rule_of_threes",   "72 HOURS",    "BODY WATER CLOCK"),
    21:  ("search_radar",     "45,000 KM²", "20-MIN GLIDE RADIUS"),
    22:  ("search_radar",     "2 KM PASS",   "RESCUE SCAN CORRIDOR"),
    26:  ("refraction_spear", "ODDS: 0.01%", "SURVIVAL PROBABILITY"),
    30:  ("rule_of_threes",   "3-3-3 RULE",  "AIR · WATER · FOOD"),
    32:  ("rule_of_threes",   "4.0 L / DAY", "32°C SWEAT LOSS"),
    35:  ("kidney_osmosis",   "35 g/L SALT", "SEAWATER VS KIDNEYS"),
    37:  ("kidney_osmosis",   "−0.5 L CELL", "OSMOSIS DEHYDRATION"),
    42:  ("parabolic_mirror", "37 KM BEAM",  "PARABOLIC WING SLAT"),
    44:  ("archimedes_lever", "15 Wh LI-ION","CRACKED PHONE BATTERY"),
    50:  ("biometric_twist",  "9.0 KG CASE", "BIOMETRIC TITANIUM"),
    54:  ("archimedes_lever", "4:1 LEVER",   "3 ISLAND PHYSICS RULES"),
    57:  ("parabolic_mirror", "410 °C FOCUS","SOLAR BARK IGNITION"),
    66:  ("coconut_mpa",      "20 MPa",      "COCONUT VS RED BRICK"),
    74:  ("coconut_mpa",      "400 mL",      "STERILE ELECTROLYTES"),
    83:  ("refraction_spear", "n = 1.33",    "SNELL'S LAW REFRACTION"),
    85:  ("refraction_spear", "−30 CM DEEP", "APPARENT VS TRUE FISH"),
    94:  ("solar_still",      "1 MATTRESS",  "A-FRAME GEOMETRY"),
    100: ("solar_still",      "800 mL / PIT","GREENHOUSE DISTILLATION"),
    101: ("solar_still",      "2.4 L / DAY", "3 SOLAR WATER STILLS"),
    109: ("search_radar",     "0 SHIPS",     "OUTSIDE SHIPPING LANES"),
    112: ("cyclone_surge",    "220 KM/H",    "CATEGORY 4 CYCLONE"),
    114: ("cyclone_surge",    "+2.0 M SURGE","OVER 1.2 M SANDBAR"),
    118: ("archimedes_lever", "PHYSICS CHAIN","LEVER · SPARK · BEAM"),
    125: ("search_radar",     "180 SEC",     "240-KNOT HORIZON PASS"),
    134: ("cyclone_surge",    "10 CM / MIN", "RISING KING-TIDE MATH"),
    140: ("archimedes_lever", "4:1 TORQUE",  "ARCHIMEDES FULCRUM"),
    144: ("archimedes_lever", "180 KG LIFT", "45 KG × 4 MULTIPLIER"),
    149: ("archimedes_lever", "410 °C FOIL", "15 Wh SHORT-CIRCUIT"),
    157: ("parabolic_mirror", "37 KM FLASH", "COCKPIT BEAM SWEEP"),
    166: ("search_radar",     "4.0M VIEWS",  "VIRAL RESCUE CLIP"),
    175: ("biometric_twist",  "ASSET 14B",   "LASER-ETCHED BIOMETRIC"),
    178: ("biometric_twist",  "SABOTAGE",    "BOLTS BLOWN OUTWARD"),
    182: ("biometric_twist",  "YOUR CHOICE", "BOARD HELI OR RUN?"),
}

# Build flat words list [{w, t0, t1, shot}] and shots metadata list
flat_words = []
shots_meta = []

for idx, s in enumerate(shots_raw):
    t0 = round(float(s["start"]), 3)
    dur = round(float(s["dur"]), 3)
    t1 = round(t0 + dur, 3)
    w_list = s.get("words", [])
    phrase = " ".join(w[0] for w in w_list)

    for wi, (w_text, w_rel) in enumerate(w_list):
        wt0 = round(t0 + float(w_rel), 3)
        if wi + 1 < len(w_list):
            wt1 = round(t0 + float(w_list[wi + 1][1]), 3)
        else:
            wt1 = round(min(t1, wt0 + 0.45), 3)
        if wt1 <= wt0:
            wt1 = round(wt0 + 0.18, 3)
        flat_words.append({"w": w_text, "t0": wt0, "t1": wt1, "shot": idx})

    is_hb = idx in HYPER_SHOT_MAP
    hb_card = HYPER_SHOT_MAP[idx][0] if is_hb else None
    hud_num = HYPER_SHOT_MAP[idx][1] if is_hb else (
        "SEAT 14B" if idx <= 6 else
        "45,000 KM²" if idx <= 27 else
        "72 HOURS" if idx <= 39 else
        "37 KM BEAM" if idx <= 59 else
        "20 MPa" if idx <= 75 else
        "n = 1.33" if idx <= 88 else
        "2.4 L / DAY" if idx <= 102 else
        "5,000 STARS" if idx <= 109 else
        "220 KM/H" if idx <= 125 else
        "180 KG BEAM" if idx <= 145 else
        "52 SEC LEFT" if idx <= 163 else
        "ASSET 14B"
    )
    hud_label = HYPER_SHOT_MAP[idx][2] if is_hb else (
        "DAY 1 · CRASH SANDBAR" if idx <= 51 else
        "DAY 1 · SURVIVOR CAMP" if idx <= 75 else
        "DAY 2 · CRYSTAL REEF" if idx <= 88 else
        "DAY 3 · DUNE SHELTER" if idx <= 102 else
        "NIGHT 4 · STARFIRE" if idx <= 109 else
        "DAY 4 · CYCLONE SURGE" if idx <= 163 else
        "DAY 5 · BASALT HELIPAD"
    )

    shots_meta.append({
        "index": idx,
        "t0": t0,
        "t1": t1,
        "dur": dur,
        "style": "hyperbuilder" if is_hb else "toylike",
        "card": hb_card,
        "hudNum": hud_num,
        "hudLabel": hud_label,
        "phrase": phrase,
    })

story = {
    "title": {
        "html": "What If You And Your <em>Crush</em> Were Stranded On An Island Alone?",
        "in": 0.0,
        "out": 2.25
    },
    "tone": "science",
    "fps": 30,
    "motionBlur": 1,
    "duration": total_dur,
    "look": {
        "toneMapping": "neutral",
        "exposure": 1.08,
        "bloom": 0.16,
        "bloomThreshold": 0.92,
        "vignette": 0.28,
        "grain": 0.02,
        "warm": 0.45,
        "saturation": 1.12,
        "fill": 0.55
    },
    "end": {
        "html": "Do you board the <em>helicopter</em>… or run back into the <em>jungle</em>?",
        "small": "COMMENT YOUR FIRST SURVIVAL HACK BELOW",
        "in": round(total_dur - 4.2, 3)
    },
    "finalFade": [round(total_dur - 4.4, 3), round(total_dur - 3.6, 3), 0.45],
    "shots": shots_meta,
    "words": flat_words,
}

with open(os.path.join(VID_DIR, "story.json"), "w") as f:
    json.dump(story, f, indent=2)

# Write caption.md (required by EDStudio render.mjs house rules, zero links)
caption_md = """What if you and your crush were stranded on an uninhabited island alone after a plane crash? 🏝️✈️

From the 45,000 km² search-grid problem and kidney salt osmosis to spearfishing with Snell's law (n = 1.33) and lifting a 180 kg storm beam with a 4:1 Archimedes lever — would you board that rescue helicopter after seeing the 14B biometric case, or run back into the jungle? 👇

Send this to the person you'd want stranded with you!

#animation #whatif #survival #science #storytime
"""
with open(os.path.join(VID_DIR, "caption.md"), "w") as f:
    f.write(caption_md)

# Write cues.json so audio/synth.py can also validate/generate if needed
cues = {
    "duration": 90.0,
    "music": {
        "instrument": "pluck",
        "bpm": 112,
        "gain_db": -22,
        "sections": [
            {"t0": 0.5, "t1": 90.0, "prog": [["A2", "E3", "A3", "C4"], ["F2", "C3", "F3", "A3"], ["C2", "G2", "C3", "E3"], ["G2", "D3", "G3", "B3"]]}
        ]
    },
    "sfx": [
        {"t": 0.3, "kind": "splash", "gain_db": -14},
        {"t": 6.2, "kind": "hiss", "gain_db": -16},
        {"t": 18.1, "kind": "pop", "gain_db": -15}
    ]
}
with open(os.path.join(VID_DIR, "cues.json"), "w") as f:
    json.dump(cues, f, indent=2)

# Symlink mix.wav -> videos/087-crush-island-10min/audio.wav (0 extra disk space used!)
audio_dst = os.path.join(VID_DIR, "audio.wav")
if os.path.lexists(audio_dst):
    os.unlink(audio_dst)
os.symlink(MIX_WAV_PATH, audio_dst)

print(f"Generated story.json ({len(shots_meta)} shots, {len(flat_words)} timed words, duration={total_dur}s) and symlinked audio.wav.")
