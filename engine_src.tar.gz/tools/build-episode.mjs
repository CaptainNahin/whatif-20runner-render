// Build a narrated episode:
//   node tools/build-episode.mjs <slug> [--frames=a-b] [--no-audio] [--concurrency=N] [--force]
// 1) Unless --no-audio (or --frames on a range re-render when mix.wav already exists), run episode_audio.py -> public/episodes/<slug>/mix.wav
// 2) Render JPEG frames into out/<slug>/frames/ (kept across runs so a range re-render only overwrites a..b)
// 3) Mux all frames + mix.wav -> out/<slug>/video.mp4 (and final/<Episode title>.mp4 on a full render)
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const req = createRequire(path.join(root, 'package.json'));
const { bundle } = req('@remotion/bundler');
const { openBrowser, renderFrames, selectComposition } = req('@remotion/renderer');

const win = process.platform === 'win32';
const py = fs.existsSync(path.join(root, '.venv', 'bin', 'python'))
  ? path.join(root, '.venv', 'bin', 'python')
  : path.join(root, '.venv', 'Scripts', 'python.exe');
const q = s => (win ? `"${s}"` : s);

const browserCandidates = [
  process.env.REMOTION_CHROME_EXECUTABLE,
  '/data/data/com.termux/files/usr/bin/chromium',
  '/data/data/com.termux/files/usr/bin/chromium-browser',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/usr/bin/google-chrome',
].filter(Boolean);
const browserExecutable = browserCandidates.find(p => fs.existsSync(p));
const glBackend = process.env.REMOTION_GL || 'swangle';

const args = process.argv.slice(2);
const slug = args.find(a => !a.startsWith('--'));
if (!slug) {
  console.error('usage: node tools/build-episode.mjs <slug> [--frames=a-b] [--no-audio] [--concurrency=N] [--force]');
  process.exit(2);
}
const range = (args.find(a => a.startsWith('--frames=')) || '').slice(9);
const concStr = (args.find(a => a.startsWith('--concurrency=')) || '').slice(14);
const conc = concStr ? Math.max(1, parseInt(concStr, 10)) : (process.platform === 'android' ? 2 : 8);
const noAudio = args.includes('--no-audio');
const force = args.includes('--force');
const resume = args.includes('--resume');

function run(cmd, a) {
  const r = spawnSync(cmd, a, { cwd: root, stdio: 'inherit', shell: win });
  if (r.status !== 0) process.exit(r.status ?? 1);
}

const epDir = path.join(root, 'public', 'episodes', slug);
const outDir = path.join(root, 'out', slug);
const frames = path.join(outDir, 'frames');
const mix = path.join(epDir, 'mix.wav');
fs.mkdirSync(frames, { recursive: true });

if (!force) {
  run('node', [q(path.join(root, 'tools', 'qa.cjs')), 'audit', slug]);
}

if (!noAudio && (!range || !fs.existsSync(mix))) {
  run(q(py), ['-I', q(path.join(root, 'tools', 'sfx', 'episode_audio.py')), slug]);
}

if (!range && !resume) {
  fs.rmSync(frames, { recursive: true, force: true });
  fs.mkdirSync(frames, { recursive: true });
}

const bundleDir = path.join(root, 'out', 'bundle');
const bundleHtml = path.join(bundleDir, 'index.html');
const epTiming = path.join(epDir, 'timing.json');
const bundleStale = !fs.existsSync(bundleHtml)
  || !!process.env.REBUNDLE
  || !fs.existsSync(path.join(bundleDir, 'public', 'episodes', slug, 'timing.json'))
  || (fs.existsSync(epTiming) && fs.statSync(epTiming).mtimeMs > fs.statSync(bundleHtml).mtimeMs);

if (bundleStale) {
  fs.rmSync(bundleDir, { recursive: true, force: true });
}

const serveUrl = !bundleStale
  ? bundleDir
  : await bundle({
      entryPoint: path.join(root, 'src/index.ts'),
      publicDir: path.join(root, 'public'),
      outDir: bundleDir,
    });

function padFrames() {
  const files = fs.readdirSync(frames).filter(f => /^element-\d+\.jpeg$/.test(f));
  if (!files.length) return 5;
  const pad = 5;
  for (const f of files) {
    const n = f.match(/\d+/)[0].padStart(pad, '0');
    const want = `element-${n}.jpeg`;
    if (f !== want) fs.renameSync(path.join(frames, f), path.join(frames, want));
  }
  return pad;
}

// Probe composition duration first
let totalDurationFrames = 0;
{
  const probeBrowser = await openBrowser('chrome', {
    browserExecutable,
    chromeMode: 'chrome-for-testing',
    chromiumOptions: { gl: glBackend },
  });
  try {
    const comp = await selectComposition({
      serveUrl,
      id: 'Episode',
      inputProps: { slug },
      puppeteerInstance: probeBrowser,
      browserExecutable,
      chromeMode: 'chrome-for-testing',
      chromiumOptions: { gl: glBackend },
      timeoutInMilliseconds: 600000,
    });
    totalDurationFrames = comp.durationInFrames;
  } finally {
    await probeBrowser.close({ silent: true });
  }
}

const fullRange = range
  ? (() => {
      const [a, b] = range.split('-').map(x => parseInt(x, 10));
      return [a, Number.isFinite(b) ? b : a];
    })()
  : [0, totalDurationFrames - 1];

// Render in 600-frame browser sessions so WebGL memory never accumulates on 10+ minute episodes
const CHUNK_SIZE = 600;
padFrames();
const existingSet = new Set(
  fs.readdirSync(frames)
    .filter(f => /^element-\d+\.jpeg$/.test(f))
    .map(f => parseInt(f.match(/\d+/)[0], 10))
);

for (let cStart = fullRange[0]; cStart <= fullRange[1]; cStart += CHUNK_SIZE) {
  const chunkEnd = Math.min(fullRange[1], cStart + CHUNK_SIZE - 1);
  // Only render the missing tail of this chunk; isolated holes are filled one frame at a time.
  const missing = [];
  for (let f = cStart; f <= chunkEnd; f++) if (!existingSet.has(f)) missing.push(f);
  if (!missing.length) {
    console.log(`[${slug}] skipping already rendered chunk ${cStart}-${chunkEnd} (${chunkEnd + 1}/${totalDurationFrames})`);
    continue;
  }
  const subRanges = [];
  for (const f of missing) {
    const last = subRanges[subRanges.length - 1];
    if (last && last[1] === f - 1) last[1] = f; else subRanges.push([f, f]);
  }
  for (const [sStart, cEnd] of subRanges) {

  const browser = await openBrowser('chrome', {
    browserExecutable,
    chromeMode: 'chrome-for-testing',
    chromiumOptions: { gl: glBackend },
  });
  try {
    const comp = await selectComposition({
      serveUrl,
      id: 'Episode',
      inputProps: { slug },
      puppeteerInstance: browser,
      browserExecutable,
      chromeMode: 'chrome-for-testing',
      chromiumOptions: { gl: glBackend },
      timeoutInMilliseconds: 600000,
    });
    let chunkRendered = 0;
    const chunkTotal = cEnd - sStart + 1;
    await renderFrames({
      composition: comp,
      serveUrl,
      outputDir: frames,
      inputProps: { slug },
      imageFormat: 'jpeg',
      jpegQuality: 92,
      muted: true,
      frameRange: [sStart, cEnd],
      puppeteerInstance: browser,
      browserExecutable,
      chromeMode: 'chrome-for-testing',
      chromiumOptions: { gl: glBackend },
      concurrency: conc,
      timeoutInMilliseconds: 600000,
      onFrameRendered: () => {
        chunkRendered++;
        if (chunkRendered % 60 === 0 || chunkRendered === chunkTotal) {
          console.log(`[${slug}] chunk ${sStart}-${cEnd}: ${chunkRendered}/${chunkTotal} (overall ${sStart + chunkRendered}/${totalDurationFrames}) ${new Date().toISOString()}`);
        }
      },
      onStart: () => {
        console.log(`starting Episode(${slug}) chunk ${sStart}-${cEnd} (${chunkTotal} frames, concurrency=${conc})...`);
      },
    });
  } finally {
    await browser.close({ silent: true });
  }
  padFrames();
  }
}

const pad = padFrames();

const outMp4 = path.join(outDir, 'video.mp4');
const ff = ['-y', '-framerate', '30'];
if (fullRange[0] > 0) ff.push('-start_number', String(fullRange[0]));
ff.push('-i', q(path.join(frames, `element-%0${pad}d.jpeg`)));
if (!range && fs.existsSync(mix)) ff.push('-i', q(mix), '-c:a', 'aac', '-b:a', '192k', '-shortest');
ff.push('-c:v', 'libx264', '-crf', range ? '15' : '17', '-pix_fmt', 'yuv420p', '-g', '30', '-video_track_timescale', '90000', q(outMp4));
run('ffmpeg', ff);

if (!range) {
  const ep = JSON.parse(fs.readFileSync(path.join(epDir, 'episode.json'), 'utf8'));
  const safe = (ep.title || slug).replace(/[<>:"/\\|?*]+/g, ' ').replace(/\s+/g, ' ').trim();
  const finalDir = path.join(root, 'final');
  fs.mkdirSync(finalDir, { recursive: true });
  const dst = path.join(finalDir, `${safe}.mp4`);
  fs.copyFileSync(outMp4, dst);
  console.log('final ->', dst);
}
