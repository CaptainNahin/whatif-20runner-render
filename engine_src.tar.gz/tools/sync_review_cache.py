#!/usr/bin/env python3
"""
Waits for the 4-runner `review_pack` job in the active GitHub Actions workflow run
to publish `crush-island-10min-stills-cache.tar.gz`, extracts it into `out/.stills_cache`,
and runs Round 1 of `node tools/review.mjs crush-island-10min`.
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, "/data/data/com.termux/files/home")
import config  # noqa: E402

ROOT = Path("/data/data/com.termux/files/home/minecraft_whatif_engine")
SLUG = "crush-island-10min"
OWNER = "CaptainNahin"
REPO = "whatif-20runner-render"
GH_CA = "ca_TLb6UOLTnfGH"


def gh(tool: str, args: dict) -> dict:
    res = config.composio_execute(tool, args, connected_account_id=GH_CA, timeout=120)
    data = res.get("data") or {}
    return data.get("response_data") or data


def main() -> None:
    run_id = None
    for _ in range(120):
        runs_res = gh("GITHUB_LIST_WORKFLOW_RUNS_FOR_A_REPOSITORY", {"owner": OWNER, "repo": REPO, "per_page": 5})
        runs = runs_res.get("workflow_runs") or []
        if not runs:
            time.sleep(10)
            continue
        run = runs[0] if run_id is None else next((r for r in runs if r["id"] == run_id), runs[0])
        run_id = run["id"]

        jobs_res = gh("GITHUB_LIST_JOBS_FOR_A_WORKFLOW_RUN", {"owner": OWNER, "repo": REPO, "run_id": run_id, "per_page": 40})
        jobs = jobs_res.get("jobs") or []
        rpack = next((j for j in jobs if j.get("name") == "review_pack"), None)
        rslices = [j for j in jobs if str(j.get("name", "")).startswith("review_slice")]
        rchunks = [j for j in jobs if str(j.get("name", "")).startswith("render_chunk")]

        rs_done = sum(1 for j in rslices if j.get("status") == "completed")
        rc_done = sum(1 for j in rchunks if j.get("status") == "completed")
        rp_status = rpack.get("status") if rpack else "pending"
        rp_conc = rpack.get("conclusion") if rpack else None

        print(
            f"[{time.strftime('%H:%M:%S')}] Run #{run_id}: review_slice={rs_done}/{len(rslices)}, "
            f"review_pack={rp_status}({rp_conc}), render_chunk={rc_done}/{len(rchunks)}",
            flush=True,
        )

        if rp_status == "completed":
            if rp_conc != "success":
                raise SystemExit(f"review_pack failed: {rp_conc}")
            break
        time.sleep(20)
    else:
        raise SystemExit("Timed out waiting for review_pack")

    tag = f"v2.0-{SLUG}-action"
    cache_tar = ROOT / "out" / f"{SLUG}-stills-cache.tar.gz"
    url = f"https://github.com/{OWNER}/{REPO}/releases/download/{tag}/{SLUG}-stills-cache.tar.gz"
    print(f"Downloading {url} -> {cache_tar} ...", flush=True)
    subprocess.run(["curl", "-fSL", "--retry", "3", "-o", str(cache_tar), url], check=True)
    subprocess.run(["tar", "-xzf", str(cache_tar), "-C", str(ROOT / "out")], check=True)
    print("Extracted .stills_cache! Running Round-1 `node tools/review.mjs crush-island-10min`...", flush=True)
    subprocess.run(["node", str(ROOT / "tools" / "review.mjs"), SLUG], cwd=str(ROOT), check=True)
    print("ROUND_1_REVIEW_MJS_COMPLETE", flush=True)


if __name__ == "__main__":
    main()
