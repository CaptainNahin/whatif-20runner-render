#!/usr/bin/env python3
"""Offload 90-second Director's Cut (frames 0..2699, 135 frames/runner across 20 GitHub Actions runners),
mux with the first 90s of mix.wav into Crush_Island_Director_Cut_90s.mp4, upload directly to Google Drive
via Composio (ca_20wgJd7IoZLu), and immediately purge all local temporary files so zero MB remain on phone.
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, "/data/data/com.termux/files/home/minecraft_whatif_engine")
sys.path.insert(0, "/data/data/com.termux/files/home")
import config  # noqa: E402
from tools.deliver_crush_island_10min import upload_file_to_composio_s3  # noqa: E402
from tools.github_offload_render import OWNER, gh, push_to_github_and_dispatch  # noqa: E402

ROOT = Path("/data/data/com.termux/files/home/minecraft_whatif_engine")
SLUG = "crush-island-10min"
REPO = "whatif-20runner-render"
DRIVE_CA = "ca_20wgJd7IoZLu"
OUT_DIR = ROOT / "out"
MIX_WAV = ROOT / "public" / "episodes" / SLUG / "mix.wav"


def upload_and_share(local_path: Path) -> str:
    file_obj = upload_file_to_composio_s3(local_path, "GOOGLEDRIVE_UPLOAD_FILE")
    res = config.composio_execute(
        "GOOGLEDRIVE_UPLOAD_FILE",
        {"file_to_upload": file_obj},
        connected_account_id=DRIVE_CA,
        timeout=900,
    )
    data = (res.get("data") or {}).get("response_data") or res.get("data") or {}
    fid = data.get("id")
    if not fid:
        raise RuntimeError(f"Drive upload failed: {res}")
    try:
        config.composio_execute(
            "GOOGLEDRIVE_ADD_FILE_SHARING_PREFERENCE",
            {"file_id": fid, "role": "reader", "type": "anyone"},
            connected_account_id=DRIVE_CA,
            timeout=120,
        )
    except Exception:
        pass
    return f"https://drive.google.com/file/d/{fid}/view?usp=sharing"


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    push_to_github_and_dispatch(REPO, SLUG, private=False)
    # Remove local tarball right after push
    (OUT_DIR / f"{SLUG}_engine_src.tar.gz").unlink(missing_ok=True)

    time.sleep(8)
    runs_res = gh("GITHUB_LIST_WORKFLOW_RUNS_FOR_A_REPOSITORY", {"owner": OWNER, "repo": REPO, "per_page": 5})
    runs = runs_res.get("workflow_runs") or []
    if not runs:
        raise RuntimeError("No workflow run found after dispatch")
    run_id = runs[0]["id"]
    print(f"Tracking 20-runner 90s Director Cut Run #{run_id} ...", flush=True)

    for _ in range(120):
        jobs_res = gh("GITHUB_LIST_JOBS_FOR_A_WORKFLOW_RUN", {"owner": OWNER, "repo": REPO, "run_id": run_id, "per_page": 35})
        jobs = jobs_res.get("jobs") or []
        rchunks = [j for j in jobs if str(j.get("name", "")).startswith("render_chunk")]
        stitch_job = next((j for j in jobs if j.get("name") == "stitch"), None)
        rc_done = sum(1 for j in rchunks if j.get("status") == "completed" and j.get("conclusion") == "success")
        rc_prog = sum(1 for j in rchunks if j.get("status") == "in_progress")
        st_status = stitch_job.get("status") if stitch_job else "pending"
        st_conc = stitch_job.get("conclusion") if stitch_job else None
        print(
            f"[{time.strftime('%H:%M:%S')}] Run #{run_id}: render_chunk={rc_done}/{len(rchunks)} "
            f"(in_progress={rc_prog}), stitch={st_status}({st_conc})",
            flush=True,
        )
        if st_status == "completed":
            if st_conc != "success":
                raise RuntimeError(f"stitch job failed: {st_conc}")
            break
        time.sleep(15)
    else:
        raise RuntimeError("Timed out waiting for 90s Director Cut stitch job")

    tag = f"v3.0-{SLUG}-90s"
    rel_url = f"https://github.com/{OWNER}/{REPO}/releases/download/{tag}/Crush_Island_Director_Cut_90s_silent.mp4"
    silent_mp4 = OUT_DIR / "Crush_Island_Director_Cut_90s_silent.mp4"
    final_mp4 = OUT_DIR / "Crush_Island_Director_Cut_90s.mp4"

    subprocess.run(["curl", "-fSL", "--retry", "3", "-o", str(silent_mp4), rel_url], check=True)
    subprocess.run(
        [
            "ffmpeg", "-y", "-v", "error",
            "-i", str(silent_mp4),
            "-t", "90", "-i", str(MIX_WAV),
            "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
            str(final_mp4),
        ],
        check=True,
    )
    silent_mp4.unlink(missing_ok=True)

    drive_url = upload_and_share(final_mp4)
    print(f"DIRECTOR_CUT_90S_DRIVE_URL={drive_url}", flush=True)

    # Strict Storage Override cleanup right after Drive upload finishes
    subprocess.run(
        "rm -rf out/* final/*.mp4 /tmp/remotion* /tmp/react-motion* ~/.cache/remotion* "
        "/data/data/com.termux/files/usr/tmp/*remotion* /data/data/com.termux/files/usr/tmp/.org.chromium* "
        "/data/data/com.termux/files/usr/tmp/puppeteer*",
        shell=True,
        cwd=str(ROOT),
    )


if __name__ == "__main__":
    main()
