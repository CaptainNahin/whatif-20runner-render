#!/usr/bin/env python3
"""
Polls the active 20-runner GitHub Actions workflow run for crush-island-10min,
downloads the stitched 1080p @ 30fps silent video and Drive stream from release
v2.0-crush-island-10min-action, muxes with public/episodes/crush-island-10min/mix.wav,
saves to /data/data/com.termux/files/home/storage/shared/Download/What_If_Stranded_With_Crush_10Min_Action.mp4,
and uploads to Google Drive via Composio (ca_20wgJd7IoZLu).
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, "/data/data/com.termux/files/home")
import config  # noqa: E402

ROOT = Path("/data/data/com.termux/files/home/minecraft_whatif_engine")
SLUG = "crush-island-10min"
OWNER = "CaptainNahin"
REPO = "whatif-20runner-render"
GH_CA = "ca_TLb6UOLTnfGH"
GD_CA = "ca_20wgJd7IoZLu"

OUT_DIR = ROOT / "out" / SLUG
OUT_DIR.mkdir(parents=True, exist_ok=True)
MIX_WAV = ROOT / "public" / "episodes" / SLUG / "mix.wav"
DL_TARGET = Path("/data/data/com.termux/files/home/storage/shared/Download/What_If_Stranded_With_Crush_10Min_Action.mp4")
FINAL_TARGET = ROOT / "final" / "What_If_Stranded_With_Crush_10Min_Action.mp4"


def gh(tool: str, args: dict) -> dict:
    res = config.composio_execute(tool, args, connected_account_id=GH_CA, timeout=120)
    data = res.get("data") or {}
    return data.get("response_data") or data


def download_url(url: str, dest: Path) -> None:
    print(f"Downloading {url} -> {dest} ...", flush=True)
    subprocess.run(["curl", "-fSL", "--retry", "3", "-o", str(dest), url], check=True)


def main() -> None:
    run_id = None
    for attempt in range(180):
        runs_res = gh("GITHUB_LIST_WORKFLOW_RUNS_FOR_A_REPOSITORY", {"owner": OWNER, "repo": REPO, "per_page": 5})
        runs = runs_res.get("workflow_runs") or []
        if not runs:
            time.sleep(15)
            continue
        run = runs[0] if run_id is None else next((r for r in runs if r["id"] == run_id), runs[0])
        run_id = run["id"]
        status = run.get("status")
        conclusion = run.get("conclusion")

        jobs_res = gh("GITHUB_LIST_JOBS_FOR_A_WORKFLOW_RUN", {"owner": OWNER, "repo": REPO, "run_id": run_id, "per_page": 30})
        jobs = jobs_res.get("jobs") or []
        done_jobs = sum(1 for j in jobs if j.get("status") == "completed")
        in_prog = sum(1 for j in jobs if j.get("status") == "in_progress")
        print(
            f"[{time.strftime('%H:%M:%S')}] Run #{run_id} status={status} conclusion={conclusion} "
            f"(jobs completed={done_jobs}/{len(jobs)}, in_progress={in_prog})",
            flush=True,
        )

        if status == "completed":
            if conclusion != "success":
                failed = [f"{j['name']}({j.get('conclusion')})" for j in jobs if j.get("conclusion") != "success"]
                raise SystemExit(f"Workflow #{run_id} failed! Failed jobs: {failed}")
            break
        time.sleep(25)
    else:
        raise SystemExit("Timed out waiting for 20-runner workflow")

    tag = f"v2.0-{SLUG}-action"
    base_rel = f"https://github.com/{OWNER}/{REPO}/releases/download/{tag}"
    silent_master = OUT_DIR / f"{SLUG}-action-silent.mp4"
    silent_drive = OUT_DIR / f"{SLUG}-action-drive-silent.mp4"

    download_url(f"{base_rel}/{SLUG}-silent.mp4", silent_master)
    download_url(f"{base_rel}/{SLUG}-drive-silent.mp4", silent_drive)

    muxed_master = OUT_DIR / "video.mp4"
    muxed_drive = OUT_DIR / "What_If_Stranded_With_Crush_10Min_Action.mp4"

    print("Muxing full high-bitrate master MP4 with mix.wav...", flush=True)
    subprocess.run([
        "ffmpeg", "-y", "-v", "error",
        "-i", str(silent_master),
        "-i", str(MIX_WAV),
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
        str(muxed_master),
    ], check=True)

    print("Muxing Drive-optimized 1080p stream MP4 with mix.wav...", flush=True)
    subprocess.run([
        "ffmpeg", "-y", "-v", "error",
        "-i", str(silent_drive),
        "-i", str(MIX_WAV),
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
        str(muxed_drive),
    ], check=True)

    FINAL_TARGET.parent.mkdir(parents=True, exist_ok=True)
    DL_TARGET.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(muxed_master, FINAL_TARGET)
    shutil.copy2(muxed_master, DL_TARGET)

    print(f"Saved local master MP4: {DL_TARGET} ({DL_TARGET.stat().st_size / (1024*1024):.2f} MB)", flush=True)
    probe = subprocess.check_output([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration,size",
        "-show_entries", "stream=codec_name,width,height,r_frame_rate",
        "-of", "default=nw=1",
        str(DL_TARGET),
    ], text=True)
    print("=== FFPROBE VERIFICATION ===\n" + probe.strip(), flush=True)

    print(f"Uploading {muxed_drive} ({muxed_drive.stat().st_size / (1024*1024):.2f} MB) to Google Drive...", flush=True)
    up_res = config.composio_upload_and_execute(
        "GOOGLEDRIVE_UPLOAD_FILE",
        file_Args={"file_to_upload": str(muxed_drive)},
        extra_args={},
        connected_account_id=GD_CA,
        timeout=600,
    )
    if not up_res.get("successful", False):
        raise RuntimeError(f"Drive upload failed: {up_res}")
    data = (up_res.get("data") or {}).get("response_data") or up_res.get("data") or {}
    fid = data.get("id")
    print(f"Uploaded to Google Drive! file_id={fid}", flush=True)

    config.composio_execute(
        "GOOGLEDRIVE_ADD_FILE_SHARING_PREFERENCE",
        {"file_id": fid, "role": "reader", "type": "anyone"},
        connected_account_id=GD_CA,
        timeout=60,
    )
    drive_url = f"https://drive.google.com/file/d/{fid}/view?usp=sharing"

    manifest = {
        "local_download_path": str(DL_TARGET),
        "engine_final_path": str(FINAL_TARGET),
        "local_size_mb": round(DL_TARGET.stat().st_size / (1024 * 1024), 2),
        "drive_size_mb": round(muxed_drive.stat().st_size / (1024 * 1024), 2),
        "drive_file_id": fid,
        "drive_url": drive_url,
    }
    (OUT_DIR / "action_delivery_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("=== ACTION DELIVERY MANIFEST ===")
    print(json.dumps(manifest, indent=2), flush=True)


if __name__ == "__main__":
    main()
