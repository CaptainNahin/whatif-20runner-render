What if you and your crush were stranded on an uninhabited island alone after a plane crash? 🏝️✈️

From the 45,000 km² search-grid problem and kidney salt osmosis to spearfishing with Snell's law (n = 1.33) and lifting a 180 kg storm beam with a 4:1 Archimedes lever — would you board that rescue helicopter after seeing the 14B biometric case, or run back into the jungle? 👇

Send this to the person you'd want stranded with you!

#animation #whatif #survival #science #storytime
