// 087-crush-island-10min — "What If You And Your Crush Were Stranded On An Island Alone?"
// Hybrid EDStudio production combining round-faced `toy-like` 3D capsule characters & island dioramas
// with `hyper builder` kinetic motion-graphics science explainers every 20-25 seconds,
// paired with synchronized #FFD700 word-highlighted bottom captions, speech bubbles, and 185 dynamic shots.
import * as THREE from 'three';
import { clamp, lerp, smooth, easeIO, faceToward } from '@engine/core.js';
import { basePose, handWorld, blink } from '@engine/rig.js';
import { createMG } from '@engine/mg/stage.js';
import { HYPER_CARDS } from '@engine/mg/crush_hyper_builder.js';
import { buildCrushIslandWorld, ZONES, zoneAt, poseToyCharacter } from '@engine/sets/crush_island.js';

const PI = Math.PI, TAU = PI * 2;
const V3 = (x, y, z) => new THREE.Vector3(x, y, z);
const lerp3 = (a, b, u) => [lerp(a[0], b[0], u), lerp(a[1], b[1], u), lerp(a[2], b[2], u)];

const OVERLAY_CSS = `
@font-face { font-family: 'Fredoka'; font-weight: 700; src: url(/node_modules/@fontsource/fredoka/files/fredoka-latin-700-normal.woff2) format('woff2'); }
@font-face { font-family: 'Inter'; font-weight: 700; src: url(/node_modules/@fontsource/inter/files/inter-latin-700-normal.woff2) format('woff2'); }
@font-face { font-family: 'Inter'; font-weight: 800; src: url(/node_modules/@fontsource/inter/files/inter-latin-800-normal.woff2) format('woff2'); }

#crush-hud {
  position: absolute; left: 48px; top: 44px; z-index: 5;
  background: rgba(14, 18, 36, 0.88); border: 2.5px solid rgba(56, 189, 248, 0.65);
  border-radius: 22px; padding: 14px 24px; font-family: 'Inter', sans-serif;
  box-shadow: 0 10px 28px rgba(0,0,0,0.55); pointer-events: none;
}
#crush-hud .mode-pill {
  display: inline-block; font-size: 15px; font-weight: 800; letter-spacing: 0.14em;
  padding: 4px 12px; border-radius: 99px; margin-bottom: 6px;
  background: #0284c7; color: #fff;
}
#crush-hud .mode-pill.hb { background: #8b5cf6; color: #ffd23f; }
#crush-hud .hud-num {
  font-family: 'Fredoka', sans-serif; font-weight: 700; font-size: 52px;
  line-height: 1.05; color: #ffd700; text-shadow: 0 3px 10px rgba(0,0,0,0.7);
}
#crush-hud .hud-sub {
  font-size: 17px; font-weight: 800; letter-spacing: 0.12em; color: #e2e8f0; margin-top: 3px;
}

#crush-cap {
  position: absolute; left: 54px; right: 54px; top: 1565px; z-index: 6;
  text-align: center; pointer-events: none;
}
#crush-cap .cap-box {
  display: inline-block; max-width: 960px;
  background: rgba(10, 14, 28, 0.86); border: 2px solid rgba(255, 215, 0, 0.42);
  border-radius: 26px; padding: 18px 32px;
  font-family: 'Fredoka', 'Inter', sans-serif; font-weight: 700; font-size: 46px;
  line-height: 1.24; color: #f8fafc;
  box-shadow: 0 12px 34px rgba(0,0,0,0.68);
  text-shadow: 0 3px 6px rgba(0,0,0,0.9);
}
#crush-cap .w-active {
  color: #FFD700; display: inline-block; margin: 0 8px;
  transform: scale(1.12);
  text-shadow: 0 0 18px rgba(255, 215, 0, 0.65), 0 3px 6px rgba(0,0,0,0.95);
}
#crush-cap .w-past { color: #cbd5e1; }
`;

export async function build(studio, story) {
  const { scene, camera, setCamera } = studio;
  camera.far = 1200;
  camera.updateProjectionMatrix();

  // Hide default core.js HUD/subtitles so our synchronized #FFD700 word-highlight caption bar & diegetic HUD own the UI cleanly
  for (const id of ['hud', 'sub']) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  }
  const st = document.createElement('style');
  st.textContent = OVERLAY_CSS;
  document.head.appendChild(st);

  const ui = document.getElementById('ui');
  const hudEl = document.createElement('div');
  hudEl.id = 'crush-hud';
  hudEl.innerHTML = `<div class="mode-pill" id="ch-mode">TOY-LIKE 3D</div><div class="hud-num" id="ch-num">SEAT 14B</div><div class="hud-sub" id="ch-sub">DAY 1 · CRASH SANDBAR</div>`;
  ui.appendChild(hudEl);

  const capEl = document.createElement('div');
  capEl.id = 'crush-cap';
  capEl.innerHTML = `<div class="cap-box" id="ch-cap-box"></div>`;
  ui.appendChild(capEl);

  const chMode = document.getElementById('ch-mode');
  const chNum = document.getElementById('ch-num');
  const chSub = document.getElementById('ch-sub');
  const chCapBox = document.getElementById('ch-cap-box');

  // Build 3D Toy-Like Island World + 2D Hyper-Builder Motion-Graphics Stage (with keepGL: true!)
  const W = await buildCrushIslandWorld(studio);
  const M = await createMG(studio, { keepGL: true });
  M.cv.style.display = 'none';
  M.cv.style.zIndex = '2';

  // Group words by shot for fast O(1) caption rendering
  const wordsByShot = new Map();
  for (const w of story.words || []) {
    if (!wordsByShot.has(w.shot)) wordsByShot.set(w.shot, []);
    wordsByShot.get(w.shot).push(w);
  }

  // Helper to place a speech bubble above a character's head, scaled for the camera distance
  function showBubble(key, rig, camPos, pop = 1, dy = 1.65) {
    const b = W.BUBBLES[key];
    if (!b) return;
    const p = rig.root.position;
    b.sprite.position.set(p.x, p.y + dy, p.z);
    const dist = Math.hypot(camPos[0] - p.x, camPos[1] - (p.y + dy), camPos[2] - p.z);
    const scaleK = clamp(dist / 4.2, 0.65, 2.2) * pop;
    b.setPop(scaleK);
  }

  // Attach a prop to a character's hand (side -1 = left/armA, +1 = right/armB)
  function attachToHand(propG, rig, side = 1, offset = [0, 0, 0], rot = [0, 0, 0]) {
    propG.visible = true;
    const hp = handWorld(rig, side);
    propG.position.set(hp.x + offset[0], hp.y + offset[1], hp.z + offset[2]);
    propG.rotation.set(rot[0], rig.root.rotation.y + rot[1], rot[2]);
  }

  const shots = story.shots || [];

  function updateCaptionsAndHud(t, shot) {
    // Hide HUD during opening title card (0..2.25s)
    const afterTitle = t >= 2.25 ? 1 : smooth((t - 1.8) / 0.45);
    hudEl.style.opacity = String(afterTitle);
    const isHB = shot.style === 'hyperbuilder';
    chMode.textContent = isHB ? 'HYPER BUILDER · 2D SCIENCE' : 'TOY-LIKE · 3D DIORAMA';
    chMode.className = isHB ? 'mode-pill hb' : 'mode-pill';
    chNum.textContent = shot.hudNum || '72 HOURS';
    chSub.textContent = shot.hudLabel || 'SURVIVAL CLOCK';

    const sw = wordsByShot.get(shot.index) || [];
    if (!sw.length) {
      capEl.style.opacity = '0';
      return;
    }
    capEl.style.opacity = '1';
    // Find active word index in this shot
    let activeIdx = 0;
    for (let i = 0; i < sw.length; i++) {
      if (t >= sw[i].t0) activeIdx = i;
    }
    // Show a clean window of up to 8 words around activeIdx
    const winSize = 8;
    const wStart = Math.floor(activeIdx / winSize) * winSize;
    const slice = sw.slice(wStart, wStart + winSize);
    chCapBox.innerHTML = slice.map((wObj, k) => {
      const idx = wStart + k;
      const cls = idx === activeIdx ? 'w-active' : idx < activeIdx ? 'w-past' : 'w-future';
      return `<span class="${cls}">${wObj.w.toUpperCase()}</span>`;
    }).join(' ');
  }

  function update(t) {
    // 1. Find current shot
    let shot = shots[0];
    for (let i = 0; i < shots.length; i++) {
      if (t >= shots[i].t0) shot = shots[i];
      else break;
    }
    const idx = shot.index;
    const u = clamp((t - shot.t0) / Math.max(0.1, shot.dur));
    const e = easeIO(u);

    updateCaptionsAndHud(t, shot);

    // Reset transient props & speech bubbles each frame (deterministic stateless evaluation)
    Object.values(W.props).forEach((p) => (p.g.visible = false));
    Object.values(W.BUBBLES).forEach((b) => b.setPop(0));
    W.pilot.root.visible = false;
    W.camp.mountedSlat.setBeam(0);
    W.ridge.greenFlare.visible = false;

    // 2. Check if this shot is a HYPER BUILDER 2D kinetic motion-graphics scene
    if (shot.style === 'hyperbuilder') {
      M.cv.style.display = 'block';
      const g = M.g;
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.globalAlpha = 1;
      const drawFn = HYPER_CARDS[shot.card] || HYPER_CARDS.search_radar;
      drawFn(M, g, t, u);
      M.vignette(g);
      M.grain(g);
      return;
    }

    // 3. Otherwise render TOY-LIKE 3D Diorama Scene!
    M.cv.style.display = 'none';

    // Select island mood & ocean state by narrative act
    let mood = 'day', stormAmt = 0.0, fireH = 0.0;
    if (idx <= 5) { mood = 'golden'; }
    else if (idx >= 103 && idx <= 109) { mood = 'night'; fireH = 0.85; }
    else if (idx >= 110 && idx <= 163) { mood = 'storm'; stormAmt = idx >= 121 ? 1.0 : 0.45; fireH = idx >= 150 ? 1.35 : 0.0; }
    else if (idx >= 164) { mood = 'dawn'; }
    else if (idx >= 52 && idx <= 59) { mood = 'golden'; fireH = idx >= 57 ? 0.55 : 0.0; }

    W.I.setMood(mood);
    W.I.S.ocean.U.uT.value = t;
    W.I.S.ocean.U.uCalm.value = 1 - stormAmt * 0.5;
    W.I.S.ocean.U.uStorm.value = stormAmt;
    W.I.foam.tex.offset.x = t * 0.08;
    W.camp.flames.update(t, fireH, { maxW: 0.48 });
    W.camp.fireLight.intensity = fireH * 10;
    W.reef.realFish.update(t);
    W.reef.ghostFish.update(t);
    W.props.titaniumCase.update(t);
    W.ridge.mainRotor.rotation.y = t * 24;
    W.ridge.tailRotor.rotation.x = t * 32;

    // Default poses for You & Crush
    const pYou = basePose(), pCrush = basePose();
    pYou.eyes = blink(t, 1);
    pCrush.eyes = blink(t, 2);
    let fYou = { mouth: 'flat', brows: 0, wideEyes: false, sweat: false };
    let fCrush = { mouth: 'flat', brows: 0, wideEyes: false, sweat: false };

    // Determine active zone & stage dynamic action per shot range
    let zone = 'crash';
    if ([6, 10, 28, 34, 78, 79, 80, 81, 82, 84, 86, 87, 88].includes(idx)) zone = 'reef';
    else if ((idx >= 13 && idx <= 16) || (idx >= 29 && idx <= 31) || (idx >= 52 && idx <= 77) || (idx >= 89 && idx <= 120)) zone = 'camp';
    else if ((idx >= 17 && idx <= 18) || (idx >= 121 && idx <= 163)) zone = 'storm';
    else if ((idx >= 20 && idx <= 27 && idx !== 25) || (idx >= 164 && idx <= 175) || idx >= 180) zone = 'ridge';

    const Z = ZONES[zone];
    W.I.aimSun(Z[0], 1.5, Z[1], 22);

    // Camera start/end points & character choreography by story beat
    let cam0 = [Z[0] + 3.2, 2.2, Z[1] + 4.8], cam1 = [Z[0] + 2.4, 2.0, Z[1] + 4.0];
    let look0 = [Z[0], 1.1, Z[1]], look1 = [Z[0], 1.15, Z[1]];
    let fov = 48;
    let activeBubble = null;

    if (idx === 0 || idx === 1) {
      // Waking up in warm surf clutching soaked Seat 14B boarding pass
      const [ux, uy, uz] = zoneAt('crash', -1.2, 2.4);
      Object.assign(pYou, { x: ux, y: uy - 0.25, z: uz, rotY: 0.3, crouch: 0.28, lean: 0.35, armB: { sx: -1.1, sz: 0.15, el: -1.15, free: 0 } });
      fYou = { mouth: 'o', brows: 0.7, wideEyes: true, sweat: true };
      const [cx, cy, cz] = zoneAt('crash', 1.6, 1.8);
      Object.assign(pCrush, { x: cx, y: cy - 0.22, z: cz, rotY: -0.4, crouch: 0.25, lean: 0.25 });
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);
      attachToHand(W.props.boardingPass.g, W.you, 1, [0, 0.04, 0.08], [-0.4, 0, 0.2]);
      const hp = handWorld(W.you, 1);
      cam0 = [hp.x + 0.35, hp.y + 0.42, hp.z + 0.75];
      cam1 = [hp.x + 0.18, hp.y + 0.28, hp.z + 0.48];
      look0 = [hp.x, hp.y + 0.02, hp.z];
      look1 = [hp.x, hp.y + 0.04, hp.z];
      fov = 40;
    } else if (idx === 2) {
      // Wide dynamic crane shot of sheared Flight 815 fuselage hissing with gray smoke
      const [ux, uy, uz] = zoneAt('crash', -1.4 + u * 0.6, 2.2 - u * 0.4);
      Object.assign(pYou, { x: ux, y: uy, z: uz, rotY: PI, dist: u * 1.4, speed: 0.4, headPitch: -0.15 });
      const [cx, cy, cz] = zoneAt('crash', 1.5, 1.9);
      Object.assign(pCrush, { x: cx, y: cy - 0.18, z: cz, rotY: -2.4, crouch: 0.2, lean: 0.2 });
      fYou = { mouth: 'o', brows: 0.6, wideEyes: true };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);
      cam0 = [Z[0] - 4.8, uy + 2.6, Z[1] + 6.5];
      cam1 = [Z[0] + 3.8, uy + 3.2, Z[1] + 5.4];
      look0 = [Z[0], uy + 1.4, Z[1] - 2.2];
      look1 = [Z[0] - 0.4, uy + 1.6, Z[1] - 2.8];
      fov = 52;
    } else if (idx === 3 || idx === 4) {
      // Crush sits up in the foam: "Please tell me this is a layover."
      const [ux, uy, uz] = zoneAt('crash', -1.1 + u * 0.4, 1.9);
      const [cx, cy, cz] = zoneAt('crash', 1.1, 1.8);
      Object.assign(pYou, { x: ux, y: uy, z: uz, rotY: faceToward(ux, uz, cx, cz), dist: u * 0.5, speed: 0.22 });
      Object.assign(pCrush, {
        x: cx, y: cy - 0.12 * (1 - u), z: cz,
        rotY: faceToward(cx, cz, ux, uz),
        crouch: 0.15 * (1 - u), lean: 0.1,
        armA: { sx: -0.65, sz: 0.35, el: -0.8, free: 0 },
        armB: { sx: -0.45, sz: 0.25, el: -0.6, free: 0 },
      });
      fCrush = { mouth: idx === 4 ? 'o' : 'flat', brows: 0.65, wideEyes: true };
      fYou = { mouth: 'smile', brows: 0.3 };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);
      if (idx === 4) activeBubble = ['layover', W.crush];
      cam0 = [cx - 0.9, cy + 1.45, cz + 2.65];
      cam1 = [cx - 0.45, cy + 1.38, cz + 2.15];
      look0 = [cx, cy + 1.05, cz];
      look1 = [cx - 0.2, cy + 1.12, cz];
      fov = 44;
    } else if (idx === 25) {
      // Crush: "Stop doing math. You're making it worse." while you draw search circles in the sand
      const [ux, uy, uz] = zoneAt('crash', -0.9, 1.6);
      const [cx, cy, cz] = zoneAt('crash', 0.85, 1.5);
      Object.assign(pYou, { x: ux, y: uy, z: uz, rotY: 0.6, crouch: 0.22, lean: 0.35, armB: { sx: -0.95, sz: 0.2, el: -0.7, free: 0 } });
      Object.assign(pCrush, { x: cx, y: cy, z: cz, rotY: -0.75, armA: { sx: -0.4, sz: 0.35, el: -1.4, free: 0 }, armB: { sx: -0.4, sz: 0.35, el: -1.4, free: 0 } });
      fCrush = { mouth: 'o', brows: -0.6, wideEyes: true };
      fYou = { mouth: 'smile', brows: 0.5, sweat: true };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);
      activeBubble = ['stopmath', W.crush];
      cam0 = [cx - 1.4, cy + 1.5, cz + 2.8];
      cam1 = [cx - 0.8, cy + 1.42, cz + 2.3];
      look0 = [(ux + cx) / 2, cy + 1.1, (uz + cz) / 2];
      look1 = [cx - 0.2, cy + 1.15, cz];
      fov = 45;
    } else if (idx >= 40 && idx <= 51) {
      // Stripping fuselage for 4 salvage items: Wing Slat (41), Cracked Phone (43), Seat 14B Pass (45-47), Titanium Case (48-51)
      const [ux, uy, uz] = zoneAt('crash', -0.85 + Math.sin(u * PI) * 0.35, 1.2);
      const [cx, cy, cz] = zoneAt('crash', 0.95, 1.3);
      Object.assign(pYou, { x: ux, y: uy, z: uz, rotY: 0.25, lean: 0.18, armB: { sx: -1.05, sz: 0.2, el: -0.85, free: 0 }, armA: { sx: -0.75, sz: 0.15, el: -0.65, free: 0 } });
      Object.assign(pCrush, { x: cx, y: cy, z: cz, rotY: -0.35, armA: { sx: -0.85, sz: 0.2, el: -0.9, free: 0 } });
      fYou = { mouth: idx >= 48 ? 'o' : 'smile', brows: idx >= 48 ? 0.6 : -0.3, wideEyes: idx >= 48 };
      fCrush = { mouth: idx === 47 ? 'grin' : 'smile', brows: 0.2 };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);

      if (idx === 41) {
        attachToHand(W.props.wingSlat.g, W.you, 1, [-0.15, 0.05, 0.22], [0.2, 0.3, 0]);
        W.props.wingSlat.setBeam(0.75);
      } else if (idx === 43) {
        attachToHand(W.props.phone.g, W.you, 1, [0, 0.04, 0.12], [-0.35, 0, 0]);
      } else if (idx >= 45 && idx <= 47) {
        attachToHand(W.props.boardingPass.g, W.crush, -1, [0, 0.05, 0.12], [-0.3, 0, 0]);
        if (idx === 47) activeBubble = ['ticket', W.crush];
      } else if (idx >= 48) {
        W.props.titaniumCase.g.visible = true;
        W.props.titaniumCase.g.position.set((ux + cx) / 2, uy + 0.02 + u * 0.18, uz + 0.45);
        W.props.titaniumCase.g.rotation.y = 0.2;
      }
      cam0 = [Z[0] - 1.8, uy + 1.55, Z[1] + 3.7];
      cam1 = [Z[0] + 1.4, uy + 1.35, Z[1] + 2.9];
      look0 = [(ux + cx) / 2, uy + 0.95, uz];
      look1 = [(ux + cx) / 2, uy + 0.85, uz + 0.2];
      fov = 44;
    } else if (idx >= 52 && idx <= 59) {
      // Testing the 3 island physics rules at camp: smoke, 4:1 lever, 410°C wing-slat beam, aiming tripod
      const [ux, uy, uz] = zoneAt('camp', 1.1, 1.3);
      const [cx, cy, cz] = zoneAt('camp', -0.6, 1.1);
      Object.assign(pYou, { x: ux, y: uy, z: uz, rotY: -0.45, armB: { sx: -1.1, sz: 0.22, el: -0.7, free: 0 } });
      Object.assign(pCrush, { x: cx, y: cy, z: cz, rotY: 0.45, armA: { sx: -0.7, sz: 0.2, el: -0.8, free: 0 } });
      fYou = { mouth: 'grin', brows: -0.3 };
      fCrush = { mouth: 'smile', brows: 0.2 };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);
      W.camp.mountedSlat.setBeam(1.0);
      W.camp.mountedSlat.g.rotation.y = Math.sin(t * 1.4) * 0.45;
      cam0 = [Z[0] - 2.2, uy + 1.75, Z[1] + 4.4];
      cam1 = [Z[0] + 2.5, uy + 1.55, Z[1] + 3.6];
      look0 = [Z[0] + 0.8, uy + 1.0, Z[1] + 1.2];
      look1 = [Z[0] + 1.4, uy + 1.15, Z[1] + 1.4];
      fov = 46;
    } else if (idx >= 60 && idx <= 75) {
      // Coconut karate-chop fail (60-70) vs Crush's 4-second basalt wedge twist (71-75)!
      const [ux, uy, uz] = zoneAt('camp', -1.45, 1.65);
      const [cx, cy, cz] = zoneAt('camp', -0.35, 1.65);
      const chop = idx >= 63 && idx <= 65 ? Math.sin(u * PI) : 0;
      const hurt = idx >= 65 && idx <= 70;
      Object.assign(pYou, {
        x: ux, y: uy, z: uz, rotY: 0.4,
        lean: chop * 0.35,
        armB: { sx: -1.35 + chop * 0.9, sz: 0.2, el: hurt ? -1.8 : -0.4, free: 0 },
        armA: { sx: hurt ? -1.1 : -0.4, sz: 0.25, el: hurt ? -1.5 : -0.5, free: 0 },
      });
      Object.assign(pCrush, {
        x: cx, y: cy, z: cz, rotY: -0.4,
        crouch: idx >= 71 && idx <= 73 ? 0.22 : 0,
        lean: idx >= 71 && idx <= 73 ? 0.28 : 0.05,
        armA: { sx: -0.95, sz: 0.2, el: -0.8, free: 0 },
        armB: { sx: -0.95, sz: 0.2, el: -0.8, free: 0 },
      });
      fYou = hurt ? { mouth: 'scream', brows: 0.8, wideEyes: true, sweat: true } : { mouth: 'grin', brows: -0.5 };
      fCrush = { mouth: idx === 69 ? 'grin' : 'smile', brows: 0.15 };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);

      if (idx <= 72) {
        W.props.coconutWhole.g.visible = true;
        W.props.coconutWhole.g.position.set(Z[0] - 0.9, uy + 0.36, Z[1] + 1.7);
      } else {
        W.props.coconutSplit.g.visible = true;
        W.props.coconutSplit.g.position.set(Z[0] - 0.9, uy + 0.36, Z[1] + 1.7);
      }
      if (idx === 69) activeBubble = ['coconut', W.crush];
      cam0 = [Z[0] - 2.3, uy + 1.5, Z[1] + 3.9];
      cam1 = [Z[0] + 0.4, uy + 1.35, Z[1] + 3.4];
      look0 = [Z[0] - 0.9, uy + 0.85, Z[1] + 1.65];
      look1 = [Z[0] - 0.8, uy + 0.95, Z[1] + 1.65];
      fov = 44;
    } else if (idx >= 76 && idx <= 88) {
      // Day 2 Spearfishing in Crystal Reef Lagoon: Belly-flop miss (80-82) -> Snell's law aim below belly (86-88)
      const [ux, uy, uz] = zoneAt('reef', -0.9 + u * 0.35, 0.7);
      const [cx, cy, cz] = zoneAt('reef', 1.25, 0.9);
      const flop = idx === 81;
      Object.assign(pYou, {
        x: ux, y: flop ? uy - 0.32 * u : uy, z: uz,
        rotY: 0.35,
        crouch: flop ? 0.35 * u : 0.12,
        lean: flop ? 0.85 * u : 0.22,
        armB: { sx: idx === 88 ? -2.4 : -1.25 - Math.sin(u * PI) * 0.45, sz: 0.2, el: -0.35, free: 0 },
      });
      Object.assign(pCrush, {
        x: cx, y: cy, z: cz, rotY: -0.55,
        armA: { sx: idx === 88 ? -1.1 : -0.4, sz: 0.25, el: -1.1, free: 0 },
        armB: { sx: idx === 88 ? -1.1 : -0.4, sz: 0.25, el: -1.1, free: 0 },
      });
      fYou = flop ? { mouth: 'o', brows: 0.8, wideEyes: true, sweat: true } : { mouth: idx >= 87 ? 'grin' : 'flat', brows: -0.4 };
      fCrush = { mouth: 'grin', brows: 0.2 };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);
      attachToHand(W.props.spear.g, W.you, 1, [0, -0.3, 0.15], [idx === 88 ? 0.1 : 1.15, 0, 0]);
      if (idx >= 87) {
        W.props.heldFish.g.visible = true;
        const hp = handWorld(W.you, 1);
        W.props.heldFish.g.position.set(hp.x, hp.y + 0.55, hp.z + 0.25);
      }
      if (idx === 82) activeBubble = ['tackle', W.crush];
      if (idx === 86) activeBubble = ['einstein', W.crush];
      cam0 = [Z[0] - 2.4, uy + 1.7, Z[1] + 3.8];
      cam1 = [Z[0] + 1.8, uy + 1.45, Z[1] + 3.2];
      look0 = [Z[0] + 0.2, uy + 0.65, Z[1] + 0.6];
      look1 = [Z[0] + 0.1, uy + 0.85, Z[1] + 0.6];
      fov = 46;
    } else if (idx >= 89 && idx <= 102) {
      // Day 3 A-Frame Shelter Vine-Snap Palm Thatch Wig Gag (89-95) & 3 Solar Water Distillation Pits (96-102)
      const inStills = idx >= 96;
      const [ux, uy, uz] = zoneAt('camp', inStills ? 1.55 : -1.85, inStills ? 0.6 : -0.7);
      const [cx, cy, cz] = zoneAt('camp', inStills ? 3.25 : -0.95, inStills ? 0.5 : -0.65);
      Object.assign(pYou, {
        x: ux, y: uy, z: uz, rotY: 0.35,
        crouch: inStills ? 0.24 : 0.08,
        lean: inStills ? 0.28 : 0.1,
        armB: { sx: -1.1, sz: 0.25, el: -0.75, free: 0 },
      });
      Object.assign(pCrush, {
        x: cx, y: cy, z: cz, rotY: -0.45,
        crouch: inStills ? 0.22 : 0.05,
        armA: { sx: -1.0, sz: 0.2, el: -0.85, free: 0 },
      });
      const wigOn = idx === 90 || idx === 91;
      fYou = wigOn ? { mouth: 'o', brows: 0.8, wideEyes: true, sweat: true } : { mouth: 'smile', brows: 0.1 };
      fCrush = { mouth: 'grin', brows: 0.15 };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);
      if (wigOn) {
        W.props.thatchWig.g.visible = true;
        W.props.thatchWig.g.position.set(ux, uy + 1.58, uz);
        W.props.thatchWig.g.rotation.y = t * 1.5;
      }
      cam0 = [ux - 1.9, uy + 1.65, uz + 3.4];
      cam1 = [cx + 1.6, uy + 1.45, cz + 2.8];
      look0 = [(ux + cx) / 2, uy + 0.95, (uz + cz) / 2];
      look1 = [(ux + cx) / 2, uy + 0.85, (uz + cz) / 2];
      fov = 46;
    } else if (idx >= 103 && idx <= 109) {
      // Night 4 Campfire Under 5,000 Bortle-1 Stars: "I was in row 6. I paid $50 to sit by you."
      const [ux, uy, uz] = zoneAt('camp', -0.25, 1.55);
      const [cx, cy, cz] = zoneAt('camp', 0.48, 1.52);
      Object.assign(pYou, { x: ux, y: uy - 0.34, z: uz, rotY: 0.35, footFwd: 0.42, headYaw: 0.35 });
      Object.assign(pCrush, { x: cx, y: cy - 0.34, z: cz, rotY: -0.35, footFwd: 0.42, headYaw: -0.35 });
      fYou = { mouth: 'smile', brows: 0.2 };
      fCrush = { mouth: 'smile', brows: 0.25 };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);
      if (idx === 105) activeBubble = ['row6', W.crush];
      if (idx === 106) activeBubble = ['best50', W.you];
      cam0 = [Z[0] - 1.2, uy + 1.15, Z[1] + 3.5];
      cam1 = [Z[0] + 1.1, uy + 1.05, Z[1] + 3.1];
      look0 = [(ux + cx) / 2, uy + 0.65, (uz + cz) / 2 - 0.3];
      look1 = [(ux + cx) / 2, uy + 0.72, (uz + cz) / 2 - 0.2];
      fov = 42;
    } else if (idx >= 121 && idx <= 163) {
      // Act III Cyclone Climax: 180kg Beam Pinning Her Ankle -> 4:1 Archimedes Lever -> 410°C Foil Battery Spark -> 37 km Parabolic Wing-Slat Flash -> Green Flare!
      const [sx, sy, sz] = zoneAt('storm', 0, 0);
      const lifted = idx >= 143;
      const liftAngle = idx >= 141 && idx <= 145 ? lerp(0, 0.32, clamp((idx - 141 + u) / 4)) : lifted ? 0.32 : 0;
      W.storm.sparPivot.rotation.z = -liftAngle;
      W.storm.beamGroup.position.y = 0.22 + Math.sin(liftAngle) * 0.42;

      if (idx <= 146) {
        // At the storm beam & 4:1 lever
        const [ux, uy, uz] = [sx - 1.35, sy, sz + 0.35];
        const [cx, cy, cz] = [sx + 0.55, sy - (lifted ? 0 : 0.25), sz + 0.15];
        Object.assign(pYou, {
          x: ux, y: uy, z: uz, rotY: 0.65,
          crouch: 0.18 + Math.sin(u * PI) * 0.15,
          lean: 0.38,
          armA: { sx: -1.15, sz: 0.2, el: -0.65, free: 0 },
          armB: { sx: -1.15, sz: 0.2, el: -0.65, free: 0 },
        });
        Object.assign(pCrush, {
          x: cx, y: cy, z: cz, rotY: -0.55,
          crouch: lifted ? 0.05 : 0.3,
          armA: { sx: -0.75, sz: 0.3, el: -0.8, free: 0 },
        });
        fYou = { mouth: lifted ? 'grin' : 'scream', brows: -0.6, wideEyes: true, sweat: true };
        fCrush = { mouth: lifted ? 'smile' : 'scream', brows: 0.75, wideEyes: true };
        poseToyCharacter(W.you, pYou, fYou);
        poseToyCharacter(W.crush, pCrush, fCrush);
        if (idx === 130) activeBubble = ['pinned', W.crush];
        cam0 = [sx - 2.4, sy + 1.55, sz + 3.6];
        cam1 = [sx + 1.5, sy + 1.35, sz + 2.9];
        look0 = [sx - 0.3, sy + 0.65, sz + 0.2];
        look1 = [sx - 0.1, sy + 0.75, sz + 0.2];
      } else {
        // At the fire ring & aiming tripod (147..163): 410°C battery foil spark, towering smoke, 3x parabolic wing-slat flash & green flare!
        const [ux, uy, uz] = zoneAt('camp', 1.35, 1.45);
        const [cx, cy, cz] = zoneAt('camp', -0.35, 1.25);
        Object.assign(pYou, { x: ux, y: uy, z: uz, rotY: -0.35, armB: { sx: -1.25, sz: 0.2, el: -0.65, free: 0 } });
        Object.assign(pCrush, { x: cx, y: cy, z: cz, rotY: 0.35, armA: { sx: -1.05, sz: 0.25, el: -0.75, free: 0 } });
        fYou = { mouth: idx >= 158 ? 'grin' : 'o', brows: -0.5, wideEyes: true };
        fCrush = { mouth: 'grin', brows: 0.3, wideEyes: true };
        poseToyCharacter(W.you, pYou, fYou);
        poseToyCharacter(W.crush, pCrush, fCrush);
        if (idx >= 147 && idx <= 150) {
          attachToHand(W.props.batteryFoil.g, W.you, 1, [0, 0.05, 0.12], [0, 0, 0]);
        }
        if (idx >= 155) {
          W.camp.mountedSlat.setBeam(1.0);
          W.camp.mountedSlat.g.rotation.y = Math.sin(t * 4.5) * 0.55;
        }
        if (idx >= 162) {
          W.ridge.greenFlare.visible = true;
          W.ridge.greenFlare.position.set(ZONES.camp[0] - 4, uy + 7.5 - u * 1.2, ZONES.camp[1] - 16);
        }
        if (idx === 163) activeBubble = ['pretzel', W.you];
        cam0 = [ZONES.camp[0] - 2.2, uy + 1.65, ZONES.camp[1] + 4.3];
        cam1 = [ZONES.camp[0] + 2.4, uy + 1.45, ZONES.camp[1] + 3.5];
        look0 = [ZONES.camp[0] + 0.7, uy + 1.05, ZONES.camp[1] + 1.2];
        look1 = [ZONES.camp[0] + 1.2, uy + 1.25, ZONES.camp[1] + 1.3];
      }
      fov = 46;
    } else if (idx >= 164) {
      // Act IV Rescue Helicopter on 40m Basalt Ridge & Classified Asset 14B Biometric Twist!
      const [rx, ry, rz] = [ZONES.ridge[0], W.ridge.padY, ZONES.ridge[1]];
      W.ridge.heli.position.y = idx === 165 ? lerp(5.5, 2.05, e) : 2.05;

      if (idx >= 176 && idx <= 179) {
        // Flashback macro zoom onto Flight 815's sheared fuselage latch bolts blown outward before takeoff!
        const [wx, wy, wz] = zoneAt('crash', 2.1, -1.1);
        cam0 = [wx + 0.4, wy + 1.45, wz + 2.2];
        cam1 = [wx + 0.15, wy + 1.32, wz + 1.35];
        look0 = [wx, wy + 1.25, wz];
        look1 = [wx, wy + 1.25, wz];
        fov = 38;
      } else {
        const walkZ = lerp(2.6, 1.35, clamp((idx - 164 + u) / 8));
        Object.assign(pYou, { x: rx - 0.55, y: ry, z: rz + walkZ, rotY: PI, dist: u * 0.9, speed: idx <= 170 ? 0.3 : 0, armB: { sx: -0.85, sz: 0.2, el: -0.75, free: 0 } });
        Object.assign(pCrush, { x: rx + 0.55, y: ry, z: rz + walkZ, rotY: PI, dist: u * 0.9, speed: idx <= 170 ? 0.3 : 0, armA: { sx: -0.65, sz: 0.2, el: -0.65, free: 0 } });
        fYou = { mouth: idx >= 172 ? 'o' : 'grin', brows: idx >= 172 ? 0.75 : 0.1, wideEyes: idx >= 172 };
        fCrush = { mouth: idx >= 172 ? 'o' : 'grin', brows: idx >= 172 ? 0.75 : 0.15, wideEyes: idx >= 172 };
        poseToyCharacter(W.you, pYou, fYou);
        poseToyCharacter(W.crush, pCrush, fCrush);

        // Pilot Commander standing beside helicopter skid
        W.pilot.root.visible = true;
        const pPilot = basePose();
        Object.assign(pPilot, { x: rx - 1.35, y: ry, z: rz + 0.45, rotY: 0.45, armB: { sx: -1.1, sz: 0.25, el: -1.2, free: 0 } });
        poseToyCharacter(W.pilot, pPilot, { mouth: 'flat', brows: -0.5 });

        // Titanium case on helicopter skid with blinking red biometric plate (ASSET 14B)
        W.props.titaniumCase.g.visible = true;
        W.props.titaniumCase.g.position.set(rx - 0.65, ry + 0.28, rz + 0.65);

        if (idx === 168) activeBubble = ['train', W.crush];
        if (idx === 173) activeBubble = ['asset14b', W.pilot];

        if (idx === 174) {
          // Macro close-up on the Titanium Case ASSET: 14B biometric plate
          cam0 = [rx - 0.65, ry + 1.15, rz + 1.45];
          cam1 = [rx - 0.65, ry + 0.82, rz + 1.05];
          look0 = [rx - 0.65, ry + 0.35, rz + 0.65];
          look1 = [rx - 0.65, ry + 0.35, rz + 0.65];
          fov = 38;
        } else {
          cam0 = [rx - 2.8, ry + 1.85, rz + 4.8];
          cam1 = [rx + 2.4, ry + 1.65, rz + 3.9];
          look0 = [rx, ry + 1.25, rz + 0.8];
          look1 = [rx - 0.2, ry + 1.2, rz + 0.5];
          fov = 48;
        }
      }
    } else {
      // Dynamic island exploration & dialogue shots across the active zone (walking, turning, gesturing, orbiting camera)
      const parity = idx % 3;
      const [ux0, uy0, uz0] = zoneAt(zone, -1.2, 1.8);
      const [ux1, uy1, uz1] = zoneAt(zone, -0.45, 1.35);
      const [cx0, cy0, cz0] = zoneAt(zone, 1.15, 1.65);
      const [cx1, cy1, cz1] = zoneAt(zone, 0.55, 1.3);
      const upos = lerp3([ux0, uy0, uz0], [ux1, uy1, uz1], e);
      const cpos = lerp3([cx0, cy0, cz0], [cx1, cy1, cz1], e);

      Object.assign(pYou, {
        x: upos[0], y: upos[1], z: upos[2],
        rotY: faceToward(upos[0], upos[2], cpos[0], cpos[2]),
        dist: t * 1.15, speed: 0.34,
        armB: { sx: -0.65 - 0.35 * Math.sin(u * PI), sz: 0.22, el: -0.75, free: 0 },
      });
      Object.assign(pCrush, {
        x: cpos[0], y: cpos[1], z: cpos[2],
        rotY: faceToward(cpos[0], cpos[2], upos[0], upos[2]),
        dist: t * 1.05, speed: 0.3,
        armA: { sx: -0.55 - 0.3 * Math.cos(u * PI), sz: 0.2, el: -0.7, free: 0 },
      });
      fYou = { mouth: parity === 0 ? 'o' : 'smile', brows: parity === 1 ? -0.35 : 0.25, wideEyes: parity === 0 };
      fCrush = { mouth: parity === 1 ? 'grin' : 'smile', brows: 0.2 };
      poseToyCharacter(W.you, pYou, fYou);
      poseToyCharacter(W.crush, pCrush, fCrush);

      const side = (idx % 2 === 0 ? 1 : -1);
      cam0 = [Z[0] + side * 2.6, upos[1] + 1.65, Z[1] + 4.4];
      cam1 = [Z[0] - side * 1.8, upos[1] + 1.42, Z[1] + 3.5];
      look0 = [(upos[0] + cpos[0]) / 2, upos[1] + 1.05, (upos[2] + cpos[2]) / 2];
      look1 = [(upos[0] + cpos[0]) / 2, upos[1] + 1.12, (upos[2] + cpos[2]) / 2];
      fov = parity === 2 ? 42 : 48;
    }

    const camPos = lerp3(cam0, cam1, e);
    const camLook = lerp3(look0, look1, e);
    setCamera(camPos, camLook, fov, t, stormAmt > 0.3 ? 0.018 : 0.006);

    if (activeBubble) {
      showBubble(activeBubble[0], activeBubble[1], camPos, smooth(Math.min(u * 4, (1 - u) * 5 + 0.2)));
    }
    W.updateRain(t, camPos, stormAmt > 0.35);
    W.fx.update(t, camera);
  }

  return { update };
}
