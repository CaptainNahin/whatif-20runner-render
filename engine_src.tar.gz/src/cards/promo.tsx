// Reusable Business Promo & Native Ad Card Module (`promo`, `auraquant`, `primenself`, `antigravity`).
// Generates high-retention 2D Remotion motion-graphics commercials and mid-roll explainer cards
// in the exact IFOLOGY / "What If Levels" navy-and-gold blueprint aesthetic for:
// 1. AuraQuant v5 APEX (TradingView trading signals & quant indicator with live win-rate/stop-loss chart)
// 2. PrimeNself Studio ($500 48-hour B2B web redesign agency)
// 3. Antigravity Creator Studio / CaptainNahin (Autonomous 3D Voxel + Remotion production studio)
import React from 'react';
import { AbsoluteFill } from 'remotion';
import type { CardProps } from './index';
import {
  backOut, C, Caps, clamp01, COND, countText, easeOut, f, GlowDefs, GoldText, NavyBg, Push, seg, SERIF, spring01, sArr, sNum, sStr, Stroke,
} from './kit';

type BrandPreset = 'auraquant' | 'primenself' | 'antigravity';

function resolveBrand(spec: Record<string, unknown>, fallback: BrandPreset = 'auraquant'): BrandPreset {
  const b = sStr(spec, 'brand', fallback).toLowerCase();
  if (b.includes('prime')) return 'primenself';
  if (b.includes('anti') || b.includes('captain') || b.includes('nahin')) return 'antigravity';
  return 'auraquant';
}

export const PromoCard: React.FC<CardProps & { defaultBrand?: BrandPreset }> = ({ t, dur, spec, W, H, defaultBrand = 'auraquant' }) => {
  const brand = resolveBrand(spec, defaultBrand);
  const pDraw = easeOut(seg(t, 0.08, 0.95));
  const pStats = easeOut(seg(t, 0.35, 1.25));
  const pCta = spring01(seg(t, 0.85, 1.45));
  const shimmer = t > 1.1 ? ((t - 1.1) * 0.65) % 1.6 : null;

  // Defaults by brand preset (all overridable via spec)
  const badge = sStr(
    spec,
    'badge',
    brand === 'auraquant'
      ? 'AURAQUANT v5 APEX // QUANTITATIVE SIGNAL ENGINE'
      : brand === 'primenself'
        ? 'PRIMENSELF STUDIO // B2B WEB REDESIGN AGENCY'
        : 'ANTIGRAVITY CREATOR STUDIO // CAPTAINNAHIN',
  );
  const title = sStr(
    spec,
    'title',
    brand === 'auraquant'
      ? 'AURAQUANT v5 APEX'
      : brand === 'primenself'
        ? 'PRIMENSELF STUDIO'
        : 'ANTIGRAVITY STUDIO',
  );
  const metricVal = sNum(spec, 'value', brand === 'auraquant' ? 87.4 : brand === 'primenself' ? 500 : 100);
  const metricPrefix = sStr(spec, 'prefix', brand === 'primenself' ? '$' : '');
  const metricUnit = sStr(spec, 'unit', brand === 'auraquant' ? '% WIN RATE' : brand === 'primenself' ? 'FLAT RATE' : '% AUTOMATED');
  const subLabel = sStr(
    spec,
    'label',
    brand === 'auraquant'
      ? 'NON-REPAINTING TRADINGVIEW SIGNALS + DYNAMIC ATR STOP-LOSS'
      : brand === 'primenself'
        ? 'COMPLETE B2B CONVERSION REDESIGN DELIVERED IN 48 HOURS'
        : '3D MINECRAFT VOXEL RIGS × REMOTION 4 × CLOUD BUILD PIPELINE',
  );
  const cta = sStr(
    spec,
    'cta',
    brand === 'auraquant'
      ? 'GET AURAQUANT v5 APEX ON TRADINGVIEW'
      : brand === 'primenself'
        ? 'BOOK YOUR 48-HOUR REDESIGN — PRIMENSELF STUDIO'
        : 'POWERED BY CAPTAINNAHIN × ANTIGRAVITY STUDIO',
  );
  const bullets = sArr<string>(spec, 'bullets');
  const items = bullets.length
    ? bullets
    : brand === 'auraquant'
      ? ['LIVE BUY / SELL LIQUIDITY SWEEP SIGNALS', 'AUTOMATED ATR STOP-LOSS & 3-TIER TAKE PROFIT', '3.84 PROFIT FACTOR ACROSS CRYPTO, FOREX & INDICES']
      : brand === 'primenself'
        ? ['48-HOUR TURNAROUND FROM BRIEF TO LIVE DEPLOYMENT', 'HIGH-CONVERTING B2B LANDING PAGES & DESIGN SYSTEMS', 'TRANSPARENT $500 FLAT PRICING — ZERO RETAINER BLOAT']
        : ['ARTICULATED 3D MINECRAFT VOXEL CAST & EXPRESSIONS', 'SLEEK IFOLOGY BLUEPRINT MOTION GRAPHICS CARDS', 'GOOGLE CLOUD E2_HIGHCPU_32 PARALLEL RENDERING'];

  // Candlestick data for AuraQuant chart
  const candles = [
    { x: 170, o: 580, c: 540, h: 520, l: 605, bull: true },
    { x: 235, o: 540, c: 565, h: 525, l: 585, bull: false },
    { x: 300, o: 565, c: 610, h: 550, l: 635, bull: false },
    { x: 365, o: 610, c: 575, h: 560, l: 645, bull: true }, // liquidity sweep low
    { x: 430, o: 575, c: 495, h: 475, l: 590, bull: true }, // APEX BUY trigger candle
    { x: 495, o: 495, c: 440, h: 420, l: 510, bull: true },
    { x: 560, o: 440, c: 460, h: 425, l: 475, bull: false },
    { x: 625, o: 460, c: 385, h: 365, l: 470, bull: true },
    { x: 690, o: 385, c: 330, h: 310, l: 400, bull: true },
  ];

  const decimals = brand === 'auraquant' ? 1 : 0;
  const numStr = `${metricPrefix}${countText(t, 0, metricVal, 0.25, 1.0, decimals)}`;

  return (
    <AbsoluteFill>
      <NavyBg t={t} W={W} H={H} seed={brand === 'auraquant' ? 19 : brand === 'primenself' ? 31 : 47} cx={48} cy={46} />
      <Push t={t} dur={dur} amount={0.028}>
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: 'absolute', inset: 0 }}>
          <defs>
            <GlowDefs id="promo" W={W} H={H} />
          </defs>

          {/* Blueprint Frame Grid & Corner Accents */}
          <Stroke d="M 90 110 L 1830 110 L 1830 970 L 90 970 Z" p={pDraw} color={C.lineDim} w={2} />
          <Stroke d="M 90 150 L 90 110 L 130 110 M 1790 110 L 1830 110 L 1830 150 M 90 930 L 90 970 L 130 970 M 1790 970 L 1830 970 L 1830 930" p={pDraw} color={C.gold} w={5} filter="url(#promo-gold)" />

          {/* Left Visual Panel (x: 130..820, y: 250..780) */}
          <Stroke d="M 130 250 L 820 250 L 820 780 L 130 780 Z" p={pDraw} color="rgba(245,243,238,0.22)" w={2.5} fill="rgba(11,17,48,0.55)" />

          {brand === 'auraquant' && (
            <g>
              {/* Horizontal grid lines */}
              {[330, 430, 530, 630, 710].map((gy, i) => (
                <Stroke key={i} d={`M 150 ${gy} L 795 ${gy}`} p={pDraw} color="rgba(245,243,238,0.1)" w={1.5} dash="6 8" />
              ))}
              {/* Dynamic ATR Stop-Loss Line (red dashed) */}
              <Stroke d="M 350 662 L 775 662" p={seg(t, 0.35, 0.9)} color={C.red} w={3} dash="10 7" filter="url(#promo-softU)" />
              {/* APEX Take-Profit Target Line (gold) */}
              <Stroke d="M 410 322 L 775 322" p={seg(t, 0.5, 1.1)} color={C.goldHi} w={3.5} dash="12 6" filter="url(#promo-goldU)" />

              {/* Candlesticks */}
              {candles.map((cd, i) => {
                const cp = easeOut(seg(t, 0.12 + i * 0.07, 0.38 + i * 0.07));
                if (cp <= 0) return null;
                const col = cd.bull ? '#34d399' : C.red;
                const top = Math.min(cd.o, cd.c);
                const bot = Math.max(cd.o, cd.c);
                return (
                  <g key={i} opacity={cp} transform={`translate(0, ${(1 - cp) * 28})`}>
                    <line x1={cd.x} y1={cd.h} x2={cd.x} y2={cd.l} stroke={col} strokeWidth={3} strokeLinecap="round" />
                    <rect x={cd.x - 16} y={top} width={32} height={Math.max(8, bot - top)} rx={3} fill={col} stroke="#0b1130" strokeWidth={1.5} />
                  </g>
                );
              })}

              {/* EMA / Quant Trend Ribbon Curve */}
              <Stroke
                d="M 170 595 C 260 610, 340 625, 430 545 C 520 465, 610 410, 690 345"
                p={seg(t, 0.3, 1.15)}
                color={C.goldHi}
                w={4.5}
                filter="url(#promo-gold)"
              />

              {/* BUY SIGNAL Tag at candle 4 (x=430, y=615) */}
              {t > 0.45 && (
                <g transform={`translate(430, 625) scale(${backOut(seg(t, 0.45, 0.78), 2.1)})`}>
                  <polygon points="0,-22 -14,-2 14,-2" fill="#34d399" />
                  <rect x={-92} y={0} width={184} height={42} rx={8} fill="#064e3b" stroke="#34d399" strokeWidth={2.5} />
                  <text x={0} y={27} textAnchor="middle" fill="#ecfdf5" fontFamily={COND} fontWeight={800} fontSize={23} letterSpacing="0.08em">
                    APEX BUY SIGNAL
                  </text>
                </g>
              )}
              {t > 0.55 && (
                <text x={765} y={652} textAnchor="end" fill={C.red} fontFamily={COND} fontWeight={700} fontSize={20} letterSpacing="0.08em">
                  ATR STOP-LOSS
                </text>
              )}
              {t > 0.65 && (
                <text x={765} y={310} textAnchor="end" fill={C.goldHi} fontFamily={COND} fontWeight={800} fontSize={21} letterSpacing="0.08em">
                  TAKE PROFIT +3.8R
                </text>
              )}
            </g>
          )}

          {brand === 'primenself' && (
            <g>
              {/* Browser Window Frame */}
              <Stroke d="M 165 290 L 785 290 L 785 735 L 165 735 Z" p={pDraw} color={C.line} w={3} />
              <Stroke d="M 165 340 L 785 340" p={pDraw} color={C.lineDim} w={2} />
              <circle cx={195} cy={315} r={7} fill={C.red} opacity={pDraw} />
              <circle cx={220} cy={315} r={7} fill={C.gold} opacity={pDraw} />
              <circle cx={245} cy={315} r={7} fill="#34d399" opacity={pDraw} />
              {/* High-converting B2B Hero Wireframe */}
              <Stroke d="M 205 385 L 520 385 L 520 435 L 205 435 Z" p={seg(t, 0.25, 0.8)} color={C.goldHi} w={3} fill="rgba(240,180,76,0.18)" />
              <Stroke d="M 205 460 L 460 460 M 205 490 L 420 490" p={seg(t, 0.35, 0.9)} color={C.line} w={4} />
              <Stroke d="M 205 535 L 365 535 L 365 585 L 205 585 Z" p={seg(t, 0.45, 1.0)} color="#34d399" w={3} fill="rgba(52,211,153,0.22)" />
              {/* Rising Conversion Curve */}
              <Stroke d="M 215 695 C 340 690, 445 640, 560 540 C 625 480, 685 415, 745 375" p={seg(t, 0.4, 1.15)} color={C.goldHi} w={5} filter="url(#promo-gold)" />
              {t > 0.55 && (
                <g transform={`translate(645, 635) scale(${backOut(seg(t, 0.55, 0.9), 2.0)})`}>
                  <rect x={-105} y={-34} width={210} height={68} rx={12} fill="rgba(240,180,76,0.18)" stroke={C.goldHi} strokeWidth={3} />
                  <text x={0} y={8} textAnchor="middle" fill={C.goldHi} fontFamily={COND} fontWeight={800} fontSize={32} letterSpacing="0.08em">
                    48H DELIVERY
                  </text>
                </g>
              )}
            </g>
          )}

          {brand === 'antigravity' && (
            <g>
              {/* 3D Voxel Cube Isometric Schematic + Pipeline Nodes */}
              <Stroke d="M 475 320 L 635 400 L 635 580 L 475 660 L 315 580 L 315 400 Z" p={pDraw} color={C.goldHi} w={4} fill="rgba(240,180,76,0.12)" filter="url(#promo-gold)" />
              <Stroke d="M 315 400 L 475 480 L 635 400 M 475 480 L 475 660" p={seg(t, 0.25, 0.9)} color={C.line} w={3.5} />
              {/* Voxel Eyes on front isometric face */}
              {t > 0.4 && (
                <g opacity={easeOut(seg(t, 0.4, 0.8))}>
                  <rect x={355} y={475} width={38} height={24} fill="#ffffff" />
                  <rect x={372} y={479} width={18} height={18} fill="#00a8b5" />
                  <rect x={415} y={498} width={38} height={24} fill="#ffffff" />
                  <rect x={418} y={502} width={18} height={18} fill="#00a8b5" />
                </g>
              )}
              <text x={475} y={732} textAnchor="middle" fill={C.cream} fontFamily={COND} fontWeight={800} fontSize={28} letterSpacing="0.12em" opacity={pStats}>
                MINECRAFT 3D × REMOTION 4 ENGINE
              </text>
            </g>
          )}
        </svg>

        {/* Top Header Badge & Brand Title */}
        <div style={{ position: 'absolute', left: 130, top: 138, right: 130, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Caps text={badge} size={28} color={C.goldHi} spacing={0.14} />
          <Caps text="SPONSORED SPOTLIGHT" size={24} color={C.creamSoft} spacing={0.16} style={{ opacity: 0.8 }} />
        </div>

        {/* Right Side Headline, Count-up Metric & Bullet List */}
        <div style={{ position: 'absolute', left: 880, top: 245, width: 890 }}>
          <GoldText text={title} size={74} shimmer={shimmer} stagger={{ t, start: 0.05, step: 0.025, dur: 0.28 }} />
          <div style={{ marginTop: 18, display: 'flex', alignItems: 'baseline', gap: 22, opacity: pStats, transform: `translateY(${(1 - pStats) * 18}px)` }}>
            <GoldText text={numStr} size={118} tabular />
            <Caps text={metricUnit} size={46} color={C.cream} spacing={0.1} />
          </div>
          <div style={{ marginTop: 10, opacity: pStats }}>
            <Caps text={subLabel} size={27} color={C.goldLight} spacing={0.08} style={{ whiteSpace: 'normal', lineHeight: 1.25 }} />
          </div>

          {/* Gold Divider */}
          <div
            style={{
              marginTop: 24,
              marginBottom: 24,
              height: 4,
              width: `${Math.round(pStats * 100)}%`,
              background: 'linear-gradient(90deg, #ffd56b 0%, rgba(240,180,76,0.15) 100%)',
              borderRadius: 2,
            }}
          />

          {/* Animated Bullet Rows */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {items.slice(0, 3).map((item, idx) => {
              const bp = easeOut(seg(t, 0.5 + idx * 0.16, 0.9 + idx * 0.16));
              return (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 18,
                    opacity: bp,
                    transform: `translateX(${(1 - bp) * 32}px)`,
                    background: 'rgba(15, 23, 58, 0.72)',
                    border: '1.5px solid rgba(240, 180, 76, 0.38)',
                    borderRadius: 12,
                    padding: '14px 22px',
                  }}
                >
                  <div
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 8,
                      background: C.gold,
                      color: C.navyE,
                      fontFamily: SERIF,
                      fontSize: 22,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                    }}
                  >
                    ✓
                  </div>
                  <Caps text={item} size={27} color={C.cream} spacing={0.07} style={{ whiteSpace: 'normal' }} />
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Call-To-Action Banner */}
        <div
          style={{
            position: 'absolute',
            left: 130,
            right: 130,
            bottom: 138,
            height: 78,
            borderRadius: 16,
            background: 'linear-gradient(90deg, rgba(240,180,76,0.22) 0%, rgba(255,213,107,0.34) 50%, rgba(240,180,76,0.22) 100%)',
            border: `2.5px solid ${C.goldHi}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            opacity: clamp01(pCta * 1.5),
            transform: `scale(${0.92 + 0.08 * pCta})`,
            boxShadow: '0 12px 34px rgba(0,0,0,0.45)',
          }}
        >
          <Caps text={cta} size={34} color={C.goldLight} spacing={0.14} />
        </div>
      </Push>
    </AbsoluteFill>
  );
};

export const AuraQuantCard: React.FC<CardProps> = (props) => <PromoCard {...props} defaultBrand="auraquant" />;
export const PrimeNselfCard: React.FC<CardProps> = (props) => <PromoCard {...props} defaultBrand="primenself" />;
export const AntigravityCard: React.FC<CardProps> = (props) => <PromoCard {...props} defaultBrand="antigravity" />;
