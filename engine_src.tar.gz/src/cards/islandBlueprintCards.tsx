// 6 Bespoke Dark-Indigo Blueprint Grid (#160F29) Motion-Graphics Cards
// Modeled on Jeremy Bearimy's "What IF You Could Control Your Luck?" explainer diagrams.
import React from 'react';
import { AbsoluteFill } from 'remotion';
import type { CardProps } from './index';
import {
  C,
  Caps,
  GoldText,
  GlowDefs,
  NavyBg,
  Push,
  Stroke,
  backOut,
  circlePath,
  clamp01,
  countText,
  easeOut,
  seg,
  sStr,
} from './kit';

// ============================================================================
// 1. SEARCH RADIUS RADAR CARD (search_radar)
// Animated plane gliding 20 mins -> expanding 45,000 KM² circle vs tiny 2 KM scan corridor
// ============================================================================
export const SearchRadarCard: React.FC<CardProps> = ({ t, dur, spec, W, H }) => {
  const title = sStr(spec, 'title', 'OCEAN SEARCH GEOMETRY');
  const sub = sStr(spec, 'sub', '20 MIN GLIDE OFF RADAR = 45,000 KM² SEARCH ZONE');
  const pCircle = easeOut(seg(t, 0.15, 1.35));
  const pCorridor = easeOut(seg(t, 0.7, 1.8));
  const sweepDeg = (t * 110) % 360;
  const sweepRad = (sweepDeg * Math.PI) / 180;
  const cx = 600;
  const cy = 560;
  const R = 310 * pCircle;

  const glideX = 290 + easeOut(seg(t, 0.05, 1.1)) * 310;

  return (
    <AbsoluteFill>
      <NavyBg t={t} W={W} H={H} seed={101} />
      <Push t={t} dur={dur} amount={0.025}>
        {/* Header */}
        <div style={{ position: 'absolute', top: 54, left: 0, width: W, textAlign: 'center' }}>
          <Caps text={title} size={44} color={C.cream} spacing={0.16} />
          <div style={{ marginTop: 8 }}>
            <Caps text={sub} size={28} color="#c084fc" spacing={0.12} />
          </div>
        </div>

        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: 'absolute', inset: 0 }}>
          <defs>
            <GlowDefs id="radar" W={W} H={H} />
          </defs>

          {/* Radar concentric rings */}
          {[0.33, 0.66, 1].map((f, idx) => (
            <Stroke
              key={idx}
              d={circlePath(cx, cy, 310 * f)}
              p={clamp01(pCircle * 1.2 - idx * 0.15)}
              color={idx === 2 ? C.gold : 'rgba(192,132,252,0.35)'}
              w={idx === 2 ? 4.5 : 2}
              dash={idx === 2 ? undefined : '8 8'}
              fill={idx === 2 ? 'rgba(240,180,76,0.08)' : undefined}
            />
          ))}

          {/* Crosshairs */}
          <line x1={cx - 350} y1={cy} x2={cx + 350} y2={cy} stroke="rgba(245,243,238,0.22)" strokeWidth={1.5} strokeDasharray="6 6" />
          <line x1={cx} y1={cy - 350} x2={cx} y2={cy + 350} stroke="rgba(245,243,238,0.22)" strokeWidth={1.5} strokeDasharray="6 6" />

          {/* Sweeping radar line */}
          {R > 20 && (
            <line
              x1={cx}
              y1={cy}
              x2={cx + Math.cos(sweepRad) * R}
              y2={cy + Math.sin(sweepRad) * R}
              stroke="#4ade80"
              strokeWidth={3.5}
              filter="url(#radar-softU)"
            />
          )}

          {/* Tiny 2 KM Rescue Plane Scan Corridor across the giant circle */}
          {pCorridor > 0.02 && (
            <g opacity={pCorridor}>
              <rect
                x={cx - 280}
                y={cy - 95}
                width={560 * pCorridor}
                height={18}
                fill="rgba(56,189,248,0.35)"
                stroke="#38bdf8"
                strokeWidth={2.5}
              />
              {/* Rescue plane icon along the 2km corridor */}
              <g transform={`translate(${cx - 280 + 560 * pCorridor}, ${cy - 86})`}>
                <path d="M-18,0 L16,0 M-4,-14 L6,0 L-4,14 M-15,-7 L-10,0 L-15,7" stroke="#38bdf8" strokeWidth={3.5} fill="none" strokeLinecap="round" />
              </g>
            </g>
          )}

          {/* Gliding Flight 815 trajectory into center */}
          <line x1={290} y1={cy} x2={glideX} y2={cy} stroke="#ff7a6b" strokeWidth={3.5} strokeDasharray="10 6" />
          <circle cx={cx} cy={cy} r={8} fill="#ff7a6b" />
          <circle cx={cx} cy={cy} r={18 + 6 * Math.sin(t * 6)} stroke="#ff7a6b" strokeWidth={2} fill="none" />
        </svg>

        {/* Right-side Blueprint Callout Metrics */}
        <div style={{ position: 'absolute', left: 1020, top: 230, width: 780 }}>
          <div style={{ padding: '24px 32px', border: '2px solid rgba(240,180,76,0.55)', borderRadius: 16, background: 'rgba(22,15,41,0.78)' }}>
            <Caps text="20-MINUTE GLIDE RADIUS" size={28} color="#c084fc" />
            <div style={{ marginTop: 6 }}>
              <GoldText text={`${countText(t, 0, 45000, 0.15, 1.2)} KM²`} size={88} />
            </div>
            <Caps text="EXPANDING OCEAN SEARCH CIRCLE" size={26} color={C.cream} style={{ marginTop: 6 }} />
          </div>

          <div
            style={{
              marginTop: 34,
              padding: '24px 32px',
              border: '2px solid rgba(56,189,248,0.65)',
              borderRadius: 16,
              background: 'rgba(22,15,41,0.78)',
              opacity: easeOut(seg(t, 0.65, 1.25)),
              transform: `translateX(${(1 - backOut(seg(t, 0.65, 1.25))) * 50}px)`,
            }}
          >
            <Caps text="SINGLE PASS SCAN CORRIDOR (300M ALT)" size={26} color="#38bdf8" />
            <div style={{ marginTop: 6 }}>
              <GoldText text="2 KM WIDE" size={76} />
            </div>
            <Caps text="2 TEENS ON 300M SANDBAR = 2 ANTS IN 10,000 FIELDS" size={24} color="#ff7a6b" style={{ marginTop: 8 }} />
          </div>
        </div>
      </Push>
    </AbsoluteFill>
  );
};

// ============================================================================
// 2. RULE OF THREES & KIDNEY OSMOSIS CARD (kidney_osmosis)
// Animated 3 MIN AIR / 3 DAYS WATER / 3 WEEKS FOOD bars + balance scale comparing
// 35g SALT/L SEAWATER vs 20g/L KIDNEY LIMIT draining -0.5L CELL WATER
// ============================================================================
export const KidneyOsmosisCard: React.FC<CardProps> = ({ t, dur, spec, W, H }) => {
  const title = sStr(spec, 'title', 'RULE OF THREES & KIDNEY OSMOSIS');
  const b1 = easeOut(seg(t, 0.1, 0.6));
  const b2 = easeOut(seg(t, 0.3, 0.85));
  const b3 = easeOut(seg(t, 0.5, 1.05));
  const tilt = easeOut(seg(t, 0.55, 1.45)) * 14; // degrees tipping toward 35g salt

  return (
    <AbsoluteFill>
      <NavyBg t={t} W={W} H={H} seed={202} />
      <Push t={t} dur={dur} amount={0.025}>
        <div style={{ position: 'absolute', top: 48, left: 0, width: W, textAlign: 'center' }}>
          <Caps text={title} size={46} color={C.cream} spacing={0.15} />
          <Caps text="WHY DRINKING SEAWATER ACCELERATES DEHYDRATION" size={26} color="#c084fc" style={{ marginTop: 6 }} />
        </div>

        {/* Left Panel: Rule of Threes Bars */}
        <div style={{ position: 'absolute', left: 100, top: 185, width: 780 }}>
          <Caps text="SURVIVAL RULE OF THREES" size={32} color={C.goldHi} style={{ marginBottom: 20 }} />
          {[
            { label: '3 MINUTES WITHOUT AIR', val: '3 MIN', w: 0.32 * b1, col: '#38bdf8', hi: false },
            { label: '3 DAYS WITHOUT WATER (72 HRS)', val: '3 DAYS', w: 0.92 * b2, col: '#ff7a6b', hi: true },
            { label: '3 WEEKS WITHOUT FOOD', val: '3 WEEKS', w: 0.68 * b3, col: '#4ade80', hi: false },
          ].map((row, idx) => (
            <div
              key={idx}
              style={{
                marginBottom: 26,
                padding: '18px 22px',
                borderRadius: 14,
                border: row.hi ? '3px solid #ff7a6b' : '1.5px solid rgba(245,243,238,0.22)',
                background: row.hi ? 'rgba(255,122,107,0.14)' : 'rgba(22,15,41,0.7)',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Caps text={row.label} size={26} color={row.hi ? '#ff7a6b' : C.cream} />
                <GoldText text={row.val} size={42} />
              </div>
              <div style={{ marginTop: 12, height: 18, background: 'rgba(255,255,255,0.1)', borderRadius: 9, overflow: 'hidden' }}>
                <div style={{ width: `${row.w * 100}%`, height: '100%', background: row.col, borderRadius: 9 }} />
              </div>
            </div>
          ))}

          <div style={{ marginTop: 16, padding: '16px 22px', borderRadius: 12, background: 'rgba(240,180,76,0.12)', border: '1.5px solid rgba(240,180,76,0.45)' }}>
            <Caps text="AT 32°C: 2 CASTAWAYS SWEAT 4.0 LITERS / DAY" size={25} color={C.goldHi} />
          </div>
        </div>

        {/* Right Panel: Kidney Osmosis Balance Scale & -0.5L Cell Drain */}
        <div style={{ position: 'absolute', left: 960, top: 185, width: 860, height: 780 }}>
          <Caps text="KIDNEY SALT OSMOSIS BALANCE" size={32} color="#38bdf8" style={{ textAlign: 'center' }} />
          <svg width={860} height={470} viewBox="0 0 860 470">
            {/* Fulcrum base */}
            <polygon points="430,270 390,390 470,390" fill="rgba(192,132,252,0.28)" stroke={C.line} strokeWidth={3} />
            <line x1={310} y1={390} x2={550} y2={390} stroke={C.line} strokeWidth={4} />

            {/* Tilting balance beam */}
            <g transform={`translate(430, 270) rotate(${-tilt})`}>
              <line x1={-250} y1={0} x2={250} y2={0} stroke={C.gold} strokeWidth={6} strokeLinecap="round" />
              <circle cx={0} cy={0} r={10} fill={C.goldHi} />

              {/* Left Pan: 35g/L Seawater (Heavier -> tips down) */}
              <g transform={`translate(-230, 0) rotate(${tilt})`}>
                <line x1={0} y1={0} x2={-45} y2={70} stroke={C.line} strokeWidth={2.5} />
                <line x1={0} y1={0} x2={45} y2={70} stroke={C.line} strokeWidth={2.5} />
                <rect x={-95} y={70} width={190} height={86} rx={12} fill="rgba(255,122,107,0.22)" stroke="#ff7a6b" strokeWidth={3} />
                <text x={0} y={108} textAnchor="middle" fill="#ff7a6b" fontFamily="Barlow Condensed" fontWeight={800} fontSize={32}>
                  35g SALT / L
                </text>
                <text x={0} y={140} textAnchor="middle" fill="#fff3dc" fontFamily="Barlow Condensed" fontWeight={700} fontSize={22}>
                  OCEAN SEAWATER
                </text>
              </g>

              {/* Right Pan: 20g/L Kidney Limit */}
              <g transform={`translate(230, 0) rotate(${tilt})`}>
                <line x1={0} y1={0} x2={-45} y2={70} stroke={C.line} strokeWidth={2.5} />
                <line x1={0} y1={0} x2={45} y2={70} stroke={C.line} strokeWidth={2.5} />
                <rect x={-95} y={70} width={190} height={86} rx={12} fill="rgba(56,189,248,0.18)" stroke="#38bdf8" strokeWidth={3} />
                <text x={0} y={108} textAnchor="middle" fill="#38bdf8" fontFamily="Barlow Condensed" fontWeight={800} fontSize={32}>
                  20g SALT / L
                </text>
                <text x={0} y={140} textAnchor="middle" fill="#fff3dc" fontFamily="Barlow Condensed" fontWeight={700} fontSize={22}>
                  HUMAN KIDNEY MAX
                </text>
              </g>
            </g>
          </svg>

          {/* Osmosis Deficit Callout Box */}
          <div
            style={{
              marginTop: 4,
              padding: '20px 28px',
              borderRadius: 16,
              border: '3px solid #ff7a6b',
              background: 'rgba(255,122,107,0.16)',
              textAlign: 'center',
              opacity: easeOut(seg(t, 0.7, 1.4)),
            }}
          >
            <Caps text="+15g EXCESS SALT REQUIRES CELL WATER FLUSH" size={25} color={C.cream} />
            <div style={{ marginTop: 6 }}>
              <GoldText text="-0.5 L CELL WATER" size={68} />
            </div>
            <Caps text="NET LOSS PER LITER OF SEAWATER DRUNK" size={24} color="#ff7a6b" style={{ marginTop: 4 }} />
          </div>
        </div>
      </Push>
    </AbsoluteFill>
  );
};

// ============================================================================
// 3. PARABOLIC MIRROR PHYSICS CARD (parabolic_mirror)
// FLAT MIRROR (3 KM SCATTER) vs CURVED WING SLAT (37 KM FOCUSED BEAM)
// ============================================================================
export const ParabolicMirrorCard: React.FC<CardProps> = ({ t, dur, spec, W, H }) => {
  const title = sStr(spec, 'title', 'PARABOLIC WING-SLAT OPTICS');
  const pTop = easeOut(seg(t, 0.1, 0.9));
  const pBot = easeOut(seg(t, 0.55, 1.55));

  return (
    <AbsoluteFill>
      <NavyBg t={t} W={W} H={H} seed={303} />
      <Push t={t} dur={dur} amount={0.025}>
        <div style={{ position: 'absolute', top: 48, left: 0, width: W, textAlign: 'center' }}>
          <Caps text={title} size={46} color={C.cream} spacing={0.15} />
          <Caps text="FLAT POCKET MIRROR DIFFUSION VS CONCAVE ALUMINUM WING SLAT" size={26} color="#c084fc" style={{ marginTop: 6 }} />
        </div>

        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: 'absolute', inset: 0 }}>
          <defs>
            <GlowDefs id="mirror" W={W} H={H} />
          </defs>

          {/* TOP DIAGRAM: FLAT MIRROR (3 KM SCATTER) */}
          <g transform="translate(160, 210)">
            <rect x={0} y={0} width={1600} height={320} rx={18} fill="rgba(22,15,41,0.72)" stroke="rgba(245,243,238,0.22)" strokeWidth={2} />
            {/* Flat mirror plate */}
            <line x1={180} y1={95} x2={180} y2={235} stroke="#94a3b8" strokeWidth={10} strokeLinecap="round" />
            {/* Scattering diverging light rays fading out */}
            {[-28, -14, 0, 14, 28].map((deg, i) => {
              const rad = (deg * Math.PI) / 180;
              const len = 460 * pTop;
              return (
                <line
                  key={i}
                  x1={186}
                  y1={165}
                  x2={186 + Math.cos(rad) * len}
                  y2={165 + Math.sin(rad) * len}
                  stroke="#ff7a6b"
                  strokeWidth={3}
                  strokeDasharray="10 8"
                  opacity={0.75 * (1 - pTop * 0.25)}
                />
              );
            })}
            <text x={240} y={62} fill="#ff7a6b" fontFamily="Barlow Condensed" fontWeight={800} fontSize={34} letterSpacing="3">
              FLAT POCKET MIRROR — INVERSE-SQUARE SCATTER
            </text>
          </g>

          {/* BOTTOM DIAGRAM: CURVED WING SLAT (37 KM FOCUSED BEAM) */}
          <g transform="translate(160, 585)">
            <rect x={0} y={0} width={1600} height={360} rx={18} fill="rgba(22,15,41,0.82)" stroke="rgba(240,180,76,0.65)" strokeWidth={3} />
            {/* Concave parabolic wing slat */}
            <path d="M210,85 Q145,180 210,275" fill="none" stroke="#e2e8f0" strokeWidth={12} strokeLinecap="round" />
            {/* Incoming sun rays */}
            {[-60, 0, 60].map((dy, i) => (
              <line key={i} x1={70} y1={180 + dy} x2={175} y2={180 + dy * 0.75} stroke="#fde047" strokeWidth={2.5} opacity={0.65} />
            ))}
            {/* Focused parabolic beam reaching 37 KM across the frame */}
            <polygon
              points={`185,152 ${185 + 1220 * pBot},168 ${185 + 1220 * pBot},192 185,208`}
              fill="rgba(255,213,107,0.32)"
            />
            <line
              x1={185}
              y1={180}
              x2={185 + 1220 * pBot}
              y2={180}
              stroke="#ffd56b"
              strokeWidth={8}
              filter="url(#mirror-goldU)"
            />
            {/* Target Coast Guard plane at 37 KM */}
            {pBot > 0.7 && (
              <g transform="translate(1435, 180)">
                <circle cx={0} cy={0} r={28} fill="rgba(74,222,128,0.25)" stroke="#4ade80" strokeWidth={3} />
                <path d="M-16,0 L16,0 M-3,-14 L6,0 L-3,14" stroke="#4ade80" strokeWidth={3.5} fill="none" />
              </g>
            )}
            <text x={240} y={62} fill="#ffd56b" fontFamily="Barlow Condensed" fontWeight={800} fontSize={36} letterSpacing="3">
              CONCAVE ALUMINUM WING SLAT — PARABOLIC COLLIMATED FLASH (410°C FOCUS)
            </text>
          </g>
        </svg>

        {/* Numeric Badges on Right */}
        <div style={{ position: 'absolute', right: 210, top: 265, textAlign: 'right' }}>
          <GoldText text="3 KM" size={84} />
          <Caps text="FADES BEFORE HORIZON" size={24} color="#ff7a6b" />
        </div>
        <div style={{ position: 'absolute', right: 210, top: 655, textAlign: 'right', opacity: easeOut(seg(t, 0.65, 1.3)) }}>
          <GoldText text={`${countText(t, 3, 37, 0.65, 1.0)} KM`} size={102} />
          <Caps text="HITS COCKPIT AT HORIZON" size={26} color="#4ade80" />
        </div>
      </Push>
    </AbsoluteFill>
  );
};

// ============================================================================
// 4. REFRACTION SPEAR-AIM CARD (refraction_spear)
// Light ray bending at n = 1.33 showing APPARENT FISH (HOLOGRAM) vs REAL FISH (AIM LOWER)
// ============================================================================
export const RefractionSpearCard: React.FC<CardProps> = ({ t, dur, spec, W, H }) => {
  const title = sStr(spec, 'title', "SNELL'S LAW UNDERWATER REFRACTION (n = 1.33)");
  const pRay = easeOut(seg(t, 0.15, 1.0));
  const pSpear = easeOut(seg(t, 0.75, 1.65));

  // Eye at (380, 290), water surface at y = 470, refraction point at (780, 470)
  // Apparent fish along straight line: (1280, 695)
  // Real fish deeper & closer: (1160, 825)
  return (
    <AbsoluteFill>
      <NavyBg t={t} W={W} H={H} seed={404} />
      <Push t={t} dur={dur} amount={0.025}>
        <div style={{ position: 'absolute', top: 48, left: 0, width: W, textAlign: 'center' }}>
          <Caps text={title} size={46} color={C.cream} spacing={0.14} />
          <Caps text="LIGHT SLOWS IN WATER — IMAGE BENDS UPWARD TOWARD SURFACE" size={26} color="#38bdf8" style={{ marginTop: 6 }} />
        </div>

        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: 'absolute', inset: 0 }}>
          <defs>
            <GlowDefs id="refract" W={W} H={H} />
          </defs>

          {/* Water volume below y = 470 */}
          <rect x={140} y={470} width={1640} height={490} rx={16} fill="rgba(6,182,212,0.14)" stroke="rgba(56,189,248,0.45)" strokeWidth={2.5} />
          <line x1={140} y1={470} x2={1780} y2={470} stroke="#38bdf8" strokeWidth={4} />
          <text x={180} y={452} fill="#fff3dc" fontFamily="Barlow Condensed" fontWeight={700} fontSize={26}>
            AIR (n = 1.00)
          </text>
          <text x={180} y={512} fill="#38bdf8" fontFamily="Barlow Condensed" fontWeight={800} fontSize={26}>
            LAGOON WATER (n = 1.33)
          </text>

          {/* Surface normal at (780, 470) */}
          <line x1={780} y1={330} x2={780} y2={640} stroke="rgba(245,243,238,0.35)" strokeWidth={2} strokeDasharray="6 6" />

          {/* Stickman observer on left sandbar */}
          <g transform="translate(340, 290)">
            <circle cx={0} cy={0} r={26} stroke={C.line} strokeWidth={4} fill="none" />
            <line x1={0} y1={26} x2={0} y2={115} stroke={C.line} strokeWidth={4} />
            <line x1={0} y1={115} x2={-28} y2={180} stroke={C.line} strokeWidth={4} />
            <line x1={0} y1={115} x2={28} y2={180} stroke={C.line} strokeWidth={4} />
            <line x1={0} y1={52} x2={55} y2={35} stroke={C.line} strokeWidth={4} />
          </g>

          {/* Dashed red sightline to APPARENT FISH (HOLOGRAM) */}
          <Stroke
            d="M380,290 L780,470 L1280,695"
            p={pRay}
            color="#ff7a6b"
            w={3.5}
            dash="10 8"
          />

          {/* Bent cyan actual light ray from REAL FISH to surface to eye */}
          <Stroke
            d="M1160,825 L780,470 L380,290"
            p={pRay}
            color="#38bdf8"
            w={4}
          />

          {/* Solid Gold Spear Trajectory aimed lower to hit REAL FISH */}
          <Stroke
            d="M395,325 L1160,825"
            p={pSpear}
            color={C.goldHi}
            w={5.5}
            filter="url(#refract-goldU)"
          />

          {/* Apparent Fish (Translucent Hologram at 1280, 695) */}
          <g transform="translate(1280, 695)" opacity={0.55}>
            <ellipse cx={0} cy={0} rx={58} ry={26} fill="none" stroke="#ff7a6b" strokeWidth={3} strokeDasharray="6 5" />
            <polygon points="-58,0 -84,-20 -84,20" fill="none" stroke="#ff7a6b" strokeWidth={3} />
            <text x={85} y={-6} fill="#ff7a6b" fontFamily="Barlow Condensed" fontWeight={800} fontSize={30}>
              APPARENT FISH (HOLOGRAM)
            </text>
            <text x={85} y={26} fill="#fff3dc" fontFamily="Barlow Condensed" fontWeight={700} fontSize={24}>
              MISSES BY +30 CM HIGH
            </text>
          </g>

          {/* Real Fish (Solid Parrotfish at 1160, 825) */}
          <g transform="translate(1160, 825)">
            <ellipse cx={0} cy={0} rx={62} ry={28} fill="rgba(56,189,248,0.35)" stroke="#4ade80" strokeWidth={4} />
            <polygon points="-62,0 -90,-22 -90,22" fill="rgba(74,222,128,0.35)" stroke="#4ade80" strokeWidth={3.5} />
            <circle cx={34} cy={-6} r={5} fill="#fff" />
            <text x={88} y={-4} fill="#4ade80" fontFamily="Barlow Condensed" fontWeight={800} fontSize={32}>
              REAL FISH (AIM A HAND'S WIDTH LOWER)
            </text>
            <text x={88} y={28} fill={C.goldHi} fontFamily="Barlow Condensed" fontWeight={700} fontSize={26}>
              DIRECT SPEAR STRIKE!
            </text>
          </g>
        </svg>
      </Push>
    </AbsoluteFill>
  );
};

// ============================================================================
// 5. SOLAR STILL GREENHOUSE DIAGRAM (solar_still)
// Animated cross-section of the 1m sand pit evaporating 800 mL x 3 = 2.4L/DAY
// ============================================================================
export const SolarStillCard: React.FC<CardProps> = ({ t, dur, spec, W, H }) => {
  const title = sStr(spec, 'title', 'SOLAR DISTILLATION PIT CROSS-SECTION');
  const pDraw = easeOut(seg(t, 0.1, 1.1));
  const dropY = 545 + ((t * 140) % 145);

  return (
    <AbsoluteFill>
      <NavyBg t={t} W={W} H={H} seed={505} />
      <Push t={t} dur={dur} amount={0.025}>
        <div style={{ position: 'absolute', top: 48, left: 0, width: W, textAlign: 'center' }}>
          <Caps text={title} size={46} color={C.cream} spacing={0.15} />
          <Caps text="GREENHOUSE EVAPORATION SEPARATES PURE H₂O FROM SALT & DAMP SAND" size={26} color="#38bdf8" style={{ marginTop: 6 }} />
        </div>

        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: 'absolute', inset: 0 }}>
          <defs>
            <GlowDefs id="still" W={W} H={H} />
          </defs>

          {/* Conical 1m Pit Cross-Section on Left/Center */}
          <g transform="translate(120, 140)">
            {/* Sand ground & 1m pit */}
            <Stroke
              d="M40,260 L220,260 L360,640 L680,640 L820,260 L1000,260"
              p={pDraw}
              color="#eab308"
              w={5}
            />
            {/* Inverted clear plastic cone sagged by center pebble */}
            <Stroke
              d="M200,255 L520,415 L840,255"
              p={pDraw}
              color="#38bdf8"
              w={4.5}
            />
            {/* Center pebble weight */}
            <ellipse cx={520} cy={392} rx={28} ry={16} fill="#64748b" stroke={C.line} strokeWidth={2.5} />
            <text x={520} y={358} textAnchor="middle" fill="#fff3dc" fontFamily="Barlow Condensed" fontWeight={700} fontSize={23}>
              PEBBLE WEIGHT (45° CONE)
            </text>

            {/* Crushed green shoreline plants on pit walls */}
            <path d="M275,410 Q320,390 345,450 Q310,470 275,410 Z" fill="rgba(74,222,128,0.35)" stroke="#4ade80" strokeWidth={2.5} />
            <path d="M765,410 Q720,390 695,450 Q730,470 765,410 Z" fill="rgba(74,222,128,0.35)" stroke="#4ade80" strokeWidth={2.5} />

            {/* Central collection cup at bottom of pit */}
            <rect x={460} y={505} width={120} height={125} rx={8} fill="rgba(245,243,238,0.12)" stroke={C.line} strokeWidth={3.5} />
            <rect x={466} y={555} width={108} height={70} rx={4} fill="rgba(56,189,248,0.55)" />

            {/* Rising water vapor arrows */}
            {[-140, -85, 85, 140].map((dx, i) => {
              const vy = 540 - ((t * 65 + i * 40) % 160);
              return (
                <g key={i} transform={`translate(${520 + dx}, ${vy})`} opacity={0.8}>
                  <path d="M0,25 L0,0 M-7,8 L0,0 L7,8" stroke="#38bdf8" strokeWidth={3} fill="none" strokeLinecap="round" />
                </g>
              );
            })}

            {/* Falling condensed water droplet */}
            <circle cx={520} cy={dropY - 140} r={8} fill="#38bdf8" filter="url(#still-softU)" />

            {/* Dimension arrow: 1.0 METER WIDE */}
            <line x1={220} y1={210} x2={820} y2={210} stroke={C.gold} strokeWidth={3} />
            <text x={520} y={195} textAnchor="middle" fill={C.goldHi} fontFamily="Barlow Condensed" fontWeight={800} fontSize={28}>
              1.0 METER CONICAL SAND PIT
            </text>
          </g>
        </svg>

        {/* Right Output Math Panel */}
        <div style={{ position: 'absolute', left: 1180, top: 245, width: 640 }}>
          <div style={{ padding: '24px 30px', borderRadius: 16, border: '2px solid rgba(56,189,248,0.55)', background: 'rgba(22,15,41,0.8)' }}>
            <Caps text="YIELD PER SOLAR PIT" size={26} color="#38bdf8" />
            <div style={{ marginTop: 6 }}>
              <GoldText text={`${countText(t, 0, 800, 0.2, 1.0)} mL`} size={84} />
            </div>
            <Caps text="PURE DISTILLED WATER / DAY" size={24} color={C.cream} />
          </div>

          <div
            style={{
              marginTop: 30,
              padding: '26px 30px',
              borderRadius: 16,
              border: '3px solid #4ade80',
              background: 'rgba(74,222,128,0.12)',
              opacity: easeOut(seg(t, 0.65, 1.35)),
            }}
          >
            <Caps text="3 SOLAR PITS × 800 mL" size={28} color="#4ade80" />
            <div style={{ marginTop: 8 }}>
              <GoldText text="2.4 LITERS / DAY" size={76} />
            </div>
            <Caps text="+ COCONUTS = DEHYDRATION CLOCK BEATEN" size={24} color={C.goldHi} style={{ marginTop: 8 }} />
          </div>
        </div>
      </Push>
    </AbsoluteFill>
  );
};

// ============================================================================
// 6. ARCHIMEDES 4:1 LEVER & 410°C BATTERY IGNITION CARD (lever_battery)
// Animated fulcrum multiplying 45 KG PUSH -> 180 KG LIFT and 15 Wh FOIL SHORT -> 410°C FLAME
// ============================================================================
export const LeverBatteryCard: React.FC<CardProps> = ({ t, dur, spec, W, H }) => {
  const title = sStr(spec, 'title', 'CHAINING ISLAND PHYSICS: LEVERAGE & THERMAL SPARK');
  const pLever = easeOut(seg(t, 0.1, 1.1));
  const pBatt = easeOut(seg(t, 0.55, 1.55));
  const beamAngle = -10 + pLever * 18;

  return (
    <AbsoluteFill>
      <NavyBg t={t} W={W} H={H} seed={606} />
      <Push t={t} dur={dur} amount={0.025}>
        <div style={{ position: 'absolute', top: 48, left: 0, width: W, textAlign: 'center' }}>
          <Caps text={title} size={46} color={C.cream} spacing={0.14} />
          <Caps text="ARCHIMEDES 4:1 MECHANICAL ADVANTAGE + 15 Wh LITHIUM FOIL SHORT" size={26} color="#c084fc" style={{ marginTop: 6 }} />
        </div>

        {/* LEFT CARD: 4:1 ARCHIMEDES LEVER */}
        <div style={{ position: 'absolute', left: 90, top: 190, width: 840, height: 790, borderRadius: 20, border: '2.5px solid rgba(240,180,76,0.55)', background: 'rgba(22,15,41,0.78)', padding: 28 }}>
          <Caps text="STEP 1: 4:1 ARCHIMEDES DRIFTWOOD LEVER" size={32} color={C.goldHi} />
          <svg width={780} height={420} viewBox="0 0 780 420">
            {/* Fulcrum rock at x = 230 (1:4 ratio along 2.4m spar) */}
            <polygon points="230,250 190,340 270,340" fill="#475569" stroke={C.line} strokeWidth={3} />
            <text x={230} y={375} textAnchor="middle" fill="#cbd5e1" fontFamily="Barlow Condensed" fontWeight={700} fontSize={22}>
              40 CM FULCRUM
            </text>

            {/* Pivoting 2.4m ironwood lever */}
            <g transform={`translate(230, 250) rotate(${beamAngle})`}>
              <line x1={-140} y1={0} x2={460} y2={0} stroke="#d97706" strokeWidth={14} strokeLinecap="round" />
              {/* 180kg aluminum beam load on short arm */}
              <rect x={-165} y={-78} width={115} height={68} rx={8} fill="#64748b" stroke="#f8fafc" strokeWidth={3} />
              <text x={-108} y={-36} textAnchor="middle" fill="#4ade80" fontFamily="Barlow Condensed" fontWeight={800} fontSize={28}>
                180 KG
              </text>
              {/* 45kg downward push arrow on long arm */}
              <path d="M430,-95 L430,-15 M414,-35 L430,-15 L446,-35" stroke="#38bdf8" strokeWidth={5} fill="none" strokeLinecap="round" />
              <text x={430} y={-110} textAnchor="middle" fill="#38bdf8" fontFamily="Barlow Condensed" fontWeight={800} fontSize={28}>
                45 KG PUSH
              </text>
            </g>
          </svg>
          <div style={{ textAlign: 'center', marginTop: 12 }}>
            <GoldText text="45 KG × 4 = 180 KG LIFT" size={62} />
            <Caps text="2.4M IRONWOOD SPAR FREES HER TRAPPED ANKLE" size={24} color="#4ade80" style={{ marginTop: 8 }} />
          </div>
        </div>

        {/* RIGHT CARD: 15 Wh FOIL SHORT -> 410°C FLAME */}
        <div
          style={{
            position: 'absolute',
            left: 990,
            top: 190,
            width: 840,
            height: 790,
            borderRadius: 20,
            border: '2.5px solid rgba(255,122,107,0.65)',
            background: 'rgba(22,15,41,0.78)',
            padding: 28,
            opacity: pBatt,
          }}
        >
          <Caps text="STEP 2: 15 Wh LITHIUM FOIL THERMAL IGNITION" size={32} color="#ff7a6b" />
          <svg width={780} height={420} viewBox="0 0 780 420">
            <defs>
              <GlowDefs id="batt" W={780} H={420} />
            </defs>
            {/* Li-ion battery cell */}
            <rect x={230} y={180} width={320} height={150} rx={14} fill="#1e293b" stroke={C.line} strokeWidth={3.5} />
            <rect x={255} y={205} width={270} height={100} rx={8} fill="rgba(249,115,22,0.22)" stroke="#f97316" strokeWidth={2.5} />
            <text x={390} y={268} textAnchor="middle" fill="#fff3dc" fontFamily="Barlow Condensed" fontWeight={800} fontSize={36}>
              15 Wh LI-ION POUCH
            </text>
            {/* Positive and negative terminals */}
            <rect x={290} y={150} width={36} height={30} fill="#facc15" />
            <rect x={454} y={150} width={36} height={30} fill="#facc15" />
            {/* Foil pretzel wrapper ribbon bridging leads */}
            <path d="M308,150 Q390,95 472,150" fill="none" stroke="#e2e8f0" strokeWidth={10} strokeLinecap="round" />
            {/* 410°C Flame & Sparks at center of foil bridge */}
            <circle cx={390} cy={120} r={28 + 8 * Math.sin(t * 14)} fill="rgba(255,122,107,0.45)" filter="url(#batt-goldU)" />
            <path d="M390,55 Q425,105 390,135 Q355,105 390,55 Z" fill="#ffd56b" stroke="#ff7a6b" strokeWidth={3} />
          </svg>
          <div style={{ textAlign: 'center', marginTop: 12 }}>
            <GoldText text={`${countText(t, 25, 410, 0.55, 0.95)}°C SPARK`} size={66} />
            <Caps text="IGNITES COCONUT HUSK + GREEN PALM SAP SMOKE" size={24} color={C.goldHi} style={{ marginTop: 8 }} />
          </div>
        </div>
      </Push>
    </AbsoluteFill>
  );
};
