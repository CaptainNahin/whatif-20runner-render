// Articulated 3D Minecraft Voxel Character Rig.
// Replaces the sphere-head stickman with authentic Minecraft BoxGeometry proportions:
// - Head: 8x8x8 voxel cube + 3D outer hair/hat/glasses/beard voxel layer + dynamic pixel-art FaceShell
// - Body: 8x12x4 voxel torso + pixel-art outfit texture + 3D collar/hood/pocket voxel details
// - Arms: 4x12x4 classic male arms (Steve, Sunny, Noor, Zuri, Kai) or 3x12x4 slim female arms (Alex, Makena, Ari, Efe)
// - Legs: 4x12x4 articulated thigh/shin voxel blocks + voxel shoes & soles
// Keeps 100% compatibility with `actor.ts` and `rig.ts` (all 45+ poses, IK reach landmarks, gaits, blinks, FACES, Ghost pass).
import React, { useContext, useEffect, useMemo } from 'react';
import * as THREE from 'three';
import type { ActorState, FullFace } from './actor';
import { DIM } from './actor';
import { clothMaterial, envMaterial, flat, inkMaterial, outlineMaterial, toonGradient } from './materials';

const boxGeo = new THREE.BoxGeometry(1, 1, 1);
const HEAD_SZ = DIM.headR * 1.88; // ~0.398m (8x8x8 voxel cube)
const facePlaneGeo = new THREE.PlaneGeometry(HEAD_SZ * 0.96, HEAD_SZ * 0.96);

const OutlineCtx = React.createContext(true);

/** Bone: applies a precomputed Matrix4 from `actor.ts` skeleton(). */
const Bone: React.FC<{ m: THREE.Matrix4; children?: React.ReactNode }> = ({ m, children }) => (
  <group matrixAutoUpdate={false} matrix={m}>{children}</group>
);

const O: React.FC<{
  g?: THREE.BufferGeometry;
  m: THREE.Material;
  p?: [number, number, number];
  r?: [number, number, number];
  s?: [number, number, number] | number;
  outline?: boolean;
  ow?: number;
}> = ({ g = boxGeo, m, p, r, s, outline = true, ow = 0.0042 }) => {
  const ctxOl = useContext(OutlineCtx);
  const scale: [number, number, number] = typeof s === 'number' ? [s, s, s] : s || [1, 1, 1];
  return (
    <group position={p} rotation={r} scale={scale}>
      <mesh geometry={g} material={m} castShadow receiveShadow />
      {outline && ctxOl && <mesh geometry={g} material={outlineMaterial()} />}
    </group>
  );
};

// ---------------------------------------------------------------------------------------
// Procedural NearestFilter Pixel-Art Skin & Outfit Textures
// ---------------------------------------------------------------------------------------
function shade(hex: string, k: number): string {
  const c = new THREE.Color(hex).multiplyScalar(k);
  return '#' + c.getHexString();
}

const pixelMatCache = new Map<string, THREE.MeshToonMaterial>();

function makePixelTexture(w: number, h: number, draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d')!;
  g.imageSmoothingEnabled = false;
  draw(g, w, h);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

function pixelToonMaterial(key: string, w: number, h: number, draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void): THREE.MeshToonMaterial {
  let m = pixelMatCache.get(key);
  if (!m) {
    const tex = makePixelTexture(w, h, draw);
    m = new THREE.MeshToonMaterial({ map: tex, gradientMap: toonGradient([125, 255]) });
    pixelMatCache.set(key, m);
  }
  return m;
}

function skinMaterial(skinColor: string): THREE.MeshToonMaterial {
  const key = `skin|${skinColor}`;
  return pixelToonMaterial(key, 8, 8, (g) => {
    g.fillStyle = skinColor;
    g.fillRect(0, 0, 8, 8);
    // Subtle Minecraft voxel pixel texture variation
    g.fillStyle = shade(skinColor, 0.94);
    g.fillRect(0, 0, 8, 1);
    g.fillRect(0, 7, 8, 1);
    g.fillRect(1, 2, 2, 1);
    g.fillRect(5, 5, 2, 1);
    g.fillStyle = shade(skinColor, 1.05);
    g.fillRect(2, 3, 4, 2);
  });
}

function hairPixelMaterial(hairColor: string): THREE.MeshToonMaterial {
  const key = `hair|${hairColor}`;
  return pixelToonMaterial(key, 8, 8, (g) => {
    g.fillStyle = hairColor;
    g.fillRect(0, 0, 8, 8);
    const dark = shade(hairColor, 0.86);
    const light = shade(hairColor, 1.12);
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        if ((x + y * 3) % 5 === 0) {
          g.fillStyle = dark;
          g.fillRect(x, y, 1, 1);
        } else if ((x * 2 + y) % 7 === 0) {
          g.fillStyle = light;
          g.fillRect(x, y, 1, 1);
        }
      }
    }
  });
}

function torsoPixelMaterial(topKind: string, topColor: string, accentColor: string, skinColor: string): THREE.MeshToonMaterial {
  const key = `torso|${topKind}|${topColor}|${accentColor}|${skinColor}`;
  return pixelToonMaterial(key, 8, 12, (g) => {
    g.fillStyle = topColor;
    g.fillRect(0, 0, 8, 12);
    // Pixel-art shading along edges and bottom hem
    g.fillStyle = shade(topColor, 0.88);
    g.fillRect(0, 0, 1, 12);
    g.fillRect(7, 0, 1, 12);
    g.fillRect(0, 11, 8, 1);
    g.fillStyle = shade(topColor, 1.07);
    g.fillRect(2, 2, 4, 6);

    // Neckline skin pixels at top center
    g.fillStyle = skinColor;
    g.fillRect(3, 0, 2, 1);
    if (topKind === 'tee') {
      // Classic Steve V-neck pixel notch + untucked bottom tab
      g.fillStyle = shade(skinColor, 0.92);
      g.fillRect(3, 1, 2, 1);
      g.fillStyle = accentColor;
      g.fillRect(2, 0, 1, 2);
      g.fillRect(5, 0, 1, 2);
      g.fillRect(3, 2, 2, 1);
      g.fillStyle = shade(topColor, 0.82);
      g.fillRect(0, 10, 8, 1);
    } else if (topKind === 'hoodie') {
      // Drawstrings + kangaroo pocket pixel details
      g.fillStyle = accentColor;
      g.fillRect(2, 1, 1, 4);
      g.fillRect(5, 1, 1, 4);
      g.fillStyle = shade(topColor, 0.84);
      g.fillRect(1, 7, 6, 3);
      g.fillStyle = accentColor;
      g.fillRect(0, 11, 8, 1);
    } else if (topKind === 'jacket') {
      // Center front zipper / open lapel + accent tee underneath
      g.fillStyle = accentColor;
      g.fillRect(3, 1, 2, 10);
      g.fillStyle = shade(topColor, 0.78);
      g.fillRect(2, 0, 1, 11);
      g.fillRect(5, 0, 1, 11);
    } else if (topKind === 'coat' || topKind === 'suit') {
      // Lab coat / suit lapels + inner shirt & tie
      g.fillStyle = '#f8fafc';
      g.fillRect(3, 1, 2, 8);
      g.fillStyle = accentColor;
      g.fillRect(3, 2, 2, 5);
      g.fillStyle = shade(topColor, 0.82);
      g.fillRect(2, 1, 1, 10);
      g.fillRect(5, 1, 1, 10);
    }
  });
}

function legPixelMaterial(bottomColor: string): THREE.MeshToonMaterial {
  const key = `leg|${bottomColor}`;
  return pixelToonMaterial(key, 4, 6, (g) => {
    g.fillStyle = bottomColor;
    g.fillRect(0, 0, 4, 6);
    g.fillStyle = shade(bottomColor, 0.88);
    g.fillRect(0, 0, 1, 6);
    g.fillRect(0, 5, 4, 1);
    g.fillStyle = shade(bottomColor, 1.08);
    g.fillRect(1, 1, 2, 4);
  });
}

// ---------------------------------------------------------------------------------------
// Dynamic Pixel-Art Facial Expressions Rig (Blinking, Pupil Tracking, Eyebrows, Mouth)
// ---------------------------------------------------------------------------------------
function drawFace(
  g: CanvasRenderingContext2D,
  f: FullFace,
  open: number,
  glow?: string,
  skinColor = '#b58463',
  eyeColor = '#4b3f96',
  hairColor = '#4a3121',
) {
  const W = g.canvas.width; // 256 (mapped to a 16x16 pixel grid -> 16px per pixel)
  const P = W / 16;
  g.clearRect(0, 0, W, W);
  g.imageSmoothingEnabled = false;

  const px = (x: number, y: number, w: number, h: number, col: string) => {
    g.fillStyle = col;
    g.fillRect(Math.round(x * P), Math.round(y * P), Math.max(1, Math.round(w * P)), Math.max(1, Math.round(h * P)));
  };

  // Subtle Minecraft nose bridge pixel (2x1 at center row 8)
  px(7, 8, 2, 1, shade(skinColor, 0.84));

  // Cheek blush pixels
  if (f.blush) {
    px(1.5, 8.5, 2, 1.2, 'rgba(244, 114, 182, 0.65)');
    px(12.5, 8.5, 2, 1.2, 'rgba(244, 114, 182, 0.65)');
  }

  // --- EYES (LeftEye: x=2..5, RightEye: x=11..14, y=6..8) ---
  const eo = Math.max(0, Math.min(1.4, f.eyes));
  const lx = Math.max(-0.85, Math.min(0.85, f.look[0]));
  const ly = Math.max(-0.65, Math.min(0.65, f.look[1]));
  const browColor = shade(hairColor, 0.85);
  const lidShade = shade(skinColor, 0.78);

  for (const side of [-1, 1] as const) {
    const ex = side < 0 ? 2 : 11; // 3-pixel wide eye
    const ey = 6.0;
    const ew = 3.0;
    const eh = eo > 1.15 ? 2.4 : 2.0;

    if (eo < 0.16) {
      // Closed / blinking eye: crisp dark pixel line + skin eyelid above
      px(ex, ey + 0.8, ew, 0.6, lidShade);
      px(ex, ey + 1.2, ew, 0.5, '#1e1b24');
    } else {
      // White sclera block
      px(ex, ey, ew, eh, glow || '#ffffff');
      // Colored iris + pupil block (tracks f.look)
      const pupilW = 1.35;
      const pupilH = Math.min(eh, 1.75);
      // Default Minecraft eyes look slightly inward or track lx
      const baseOffset = side < 0 ? 1.15 : 0.5;
      const pxOff = Math.max(0, Math.min(ew - pupilW, baseOffset + lx * 0.85));
      const pyOff = Math.max(0, Math.min(eh - pupilH, 0.2 - ly * 0.45));
      px(ex + pxOff, ey + pyOff, pupilW, pupilH, glow || eyeColor);
      // Dark pupil core
      px(ex + pxOff + 0.25, ey + pyOff + 0.25, 0.85, Math.min(1.2, pupilH - 0.25), '#14121d');
      // White pixel catchlight on wide/shocked eyes
      if (f.pupils || eo > 1.1) {
        px(ex + pxOff + 0.15, ey + pyOff + 0.15, 0.45, 0.45, '#ffffff');
      }
      // Upper/lower eyelid closure for partial blink or smug `f.lid`
      const lidClose = Math.max(f.lid || 0, eo < 0.85 ? (0.85 - eo) * 0.9 : 0);
      if (lidClose > 0.05) {
        const lh = Math.min(eh * 0.75, eh * lidClose);
        px(ex, ey, ew, lh, lidShade);
        px(ex, ey + lh - 0.25, ew, 0.28, '#1e1b24');
      }
    }

    // --- EYEBROWS (tilt/raise for shocked, worried, angry, curious) ---
    const by = 4.55 - f.browY * 0.75;
    const tilt = f.brow * 0.65; // <0 angry V (inner lower), >0 worried (inner higher)
    // Draw 3 stepped pixel blocks per eyebrow so tilt reads clearly in pixel art
    for (let k = 0; k < 3; k++) {
      // k=0 outer, k=1 mid, k=2 inner
      const bx = side < 0 ? ex + k : ex + (2 - k);
      const stepY = by + (k - 1) * (-tilt * 0.45);
      px(bx, stepY, 1.05, 0.75, browColor);
    }

    // Tears
    if (f.tears) {
      px(side < 0 ? ex + 0.4 : ex + 1.8, ey + eh, 0.8, 2.2, '#38bdf8');
      px(side < 0 ? ex + 0.3 : ex + 1.7, ey + eh + 1.8, 1.0, 0.9, '#7dd3fc');
    }
  }

  // Sweat drop on right temple
  if (f.sweat) {
    px(14.2, 3.8, 1.0, 1.6, '#7dd3fc');
    px(14.0, 5.0, 1.3, 1.1, '#e0f2fe');
  }

  // --- MOUTH (Closed, Smile, Smirk, Frown, Shocked 'O', or Talking Lip-Sync) ---
  const mw = Math.max(2.2, Math.min(5.2, 3.6 * (f.width || 1)));
  const mx = 8 - mw / 2;
  const my = 10.6;
  const mouthCol = '#2a1814';

  if (open > 0.1) {
    const mh = Math.max(1.1, Math.min(2.8, 1.0 + open * 2.1));
    // Outer dark mouth cavity
    px(mx, my - mh * 0.25, mw, mh, mouthCol);
    // White pixel teeth row along top
    if (mh > 1.25) {
      px(mx + 0.35, my - mh * 0.2, mw - 0.7, 0.55, '#f8fafc');
    }
    // Pink/coral pixel tongue at bottom
    if (mh > 1.45) {
      px(mx + 0.6, my + mh * 0.35, mw - 1.2, 0.55, '#e86b6b');
    }
  } else {
    // Closed pixel mouth with smile/frown stepped corners
    const curve = f.mouth; // -1 frown .. +1 smile
    px(mx + 0.6, my, mw - 1.2, 0.75, mouthCol);
    const cornerY = my - curve * 0.55;
    px(mx, cornerY, 0.75, 0.75, mouthCol);
    px(mx + mw - 0.75, cornerY, 0.75, 0.75, mouthCol);
  }
}

const FaceShell: React.FC<{
  face: FullFace;
  mouthOpen: number;
  glow?: string;
  skinColor: string;
  eyeColor: string;
  hairColor: string;
}> = ({ face, mouthOpen, glow, skinColor, eyeColor, hairColor }) => {
  const { tex, mat } = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = c.height = 256;
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.magFilter = THREE.NearestFilter;
    t.minFilter = THREE.NearestFilter;
    t.generateMipmaps = false;
    const m = new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false, toneMapped: false });
    return { tex: t, mat: m };
  }, []);
  useEffect(() => () => { tex.dispose(); mat.dispose(); }, [tex, mat]);

  const g = (tex.image as HTMLCanvasElement).getContext('2d')!;
  drawFace(g, face, mouthOpen, glow, skinColor, eyeColor, hairColor);
  tex.needsUpdate = true;
  return <mesh geometry={facePlaneGeo} material={mat} position={[0, 0, HEAD_SZ / 2 + 0.004]} renderOrder={3} />;
};

// ---------------------------------------------------------------------------------------
// Voxel Outfit & 3D Outer Hair / Hat / Glasses / Beard Layers
// ---------------------------------------------------------------------------------------
const Top: React.FC<{ s: ActorState; ghost?: THREE.Material }> = ({ s, ghost }) => {
  const c = s.cast;
  const topKind = c.top || 'tee';
  if (topKind === 'none') {
    const skin = ghost || skinMaterial(c.skinColor || '#b58463');
    return <O g={boxGeo} m={skin} p={[0, DIM.torso * 0.5, 0]} s={[0.24 * (c.build ?? 1), DIM.torso + 0.03, 0.13]} outline={!ghost} />;
  }
  const col = c.topColor || '#00a8b5';
  const acc = c.accent || shade(col, 1.25);
  const skinCol = c.skinColor || '#b58463';
  const mainMat = ghost || torsoPixelMaterial(topKind, col, acc, skinCol);
  const clothMat = ghost || clothMaterial(col);
  const accMat = ghost || clothMaterial(acc);
  const ol = !ghost;
  const W = 0.25 * (c.build ?? 1);
  const H = DIM.torso + 0.03;
  const D = 0.135;

  return (
    <group>
      {/* Main 8x12x4 Minecraft Voxel Torso */}
      <O g={boxGeo} m={mainMat} p={[0, H * 0.48, 0]} s={[W, H, D]} outline={ol} />
      {/* 3D Voxel Outer Layer Details */}
      {topKind === 'hoodie' && (
        <>
          {/* 3D Voxel Hood resting behind the neck */}
          <O g={boxGeo} m={clothMat} p={[0, H - 0.02, -D * 0.52]} s={[W * 0.88, 0.11, 0.09]} outline={ol} />
          {/* 3D Voxel Kangaroo Pocket */}
          <O g={boxGeo} m={clothMat} p={[0, H * 0.25, D * 0.52]} s={[W * 0.72, 0.12, 0.025]} outline={false} />
          {/* Voxel Drawstrings */}
          <O g={boxGeo} m={accMat} p={[-0.04, H * 0.74, D * 0.53]} s={[0.018, 0.13, 0.018]} outline={false} />
          <O g={boxGeo} m={accMat} p={[0.04, H * 0.74, D * 0.53]} s={[0.018, 0.13, 0.018]} outline={false} />
        </>
      )}
      {(topKind === 'jacket' || topKind === 'suit' || topKind === 'coat') && (
        <>
          {/* 3D Voxel Collar Lapels */}
          <O g={boxGeo} m={clothMat} p={[-W * 0.26, H * 0.82, D * 0.52]} r={[0, 0, -0.18]} s={[0.045, 0.16, 0.022]} outline={false} />
          <O g={boxGeo} m={clothMat} p={[W * 0.26, H * 0.82, D * 0.52]} r={[0, 0, 0.18]} s={[0.045, 0.16, 0.022]} outline={false} />
        </>
      )}
    </group>
  );
};

const HeadGear: React.FC<{ s: ActorState; ghost?: THREE.Material }> = ({ s, ghost }) => {
  const c = s.cast;
  const ol = !ghost;
  const hairCol = c.hairColor || '#4a3121';
  const hairMat = ghost || hairPixelMaterial(hairCol);
  const hatMat = c.hat && c.hat !== 'none' ? ghost || clothMaterial(c.hatColor || '#f2b632') : null;
  const R = HEAD_SZ / 2; // 0.199

  return (
    <group>
      {/* 3D Voxel Hair Layer (8.5x8.5x8.5 outer voxel shell) */}
      {c.hair && c.hair !== 'none' && (!c.hat || c.hat === 'none' || c.hat === 'headband') && (
        <group>
          {/* Base Top Crown Voxel Cap */}
          <O g={boxGeo} m={hairMat} p={[0, R * 0.88, -0.008]} s={[HEAD_SZ * 1.06, HEAD_SZ * 0.28, HEAD_SZ * 1.06]} outline={ol} />
          {/* Back Hair Voxel Layer */}
          <O g={boxGeo} m={hairMat} p={[0, R * 0.18, -R * 0.92]} s={[HEAD_SZ * 1.05, HEAD_SZ * 0.88, HEAD_SZ * 0.22]} outline={ol} />
          {/* Sideburn Voxel Strips */}
          <O g={boxGeo} m={hairMat} p={[-R * 0.96, R * 0.28, -0.01]} s={[HEAD_SZ * 0.14, HEAD_SZ * 0.65, HEAD_SZ * 0.96]} outline={ol} />
          <O g={boxGeo} m={hairMat} p={[R * 0.96, R * 0.28, -0.01]} s={[HEAD_SZ * 0.14, HEAD_SZ * 0.65, HEAD_SZ * 0.96]} outline={ol} />

          {c.hair === 'spiky' && (
            <>
              {/* Classic Steve / Kai stepped front voxel fringe */}
              <O g={boxGeo} m={hairMat} p={[0, R * 0.68, R * 0.95]} s={[HEAD_SZ * 1.04, HEAD_SZ * 0.22, HEAD_SZ * 0.14]} outline={false} />
              <O g={boxGeo} m={hairMat} p={[-R * 0.55, R * 0.46, R * 0.96]} s={[HEAD_SZ * 0.38, HEAD_SZ * 0.16, HEAD_SZ * 0.12]} outline={false} />
              <O g={boxGeo} m={hairMat} p={[R * 0.62, R * 0.48, R * 0.96]} s={[HEAD_SZ * 0.32, HEAD_SZ * 0.14, HEAD_SZ * 0.12]} outline={false} />
            </>
          )}

          {(c.hair === 'parted' || c.hair === 'short' || c.hair === 'buzz') && (
            <O g={boxGeo} m={hairMat} p={[-R * 0.22, R * 0.68, R * 0.95]} s={[HEAD_SZ * 0.78, HEAD_SZ * 0.2, HEAD_SZ * 0.13]} outline={false} />
          )}

          {(c.hair === 'ponytail' || c.hair === 'long') && (
            <>
              {/* Female side-swept voxel bangs (Alex / Ari) */}
              <O g={boxGeo} m={hairMat} p={[-R * 0.35, R * 0.62, R * 0.96]} s={[HEAD_SZ * 0.65, HEAD_SZ * 0.26, HEAD_SZ * 0.14]} outline={false} />
              <O g={boxGeo} m={hairMat} p={[R * 0.58, R * 0.56, R * 0.96]} s={[HEAD_SZ * 0.36, HEAD_SZ * 0.32, HEAD_SZ * 0.14]} outline={false} />
              {/* Long side locks framing the face */}
              <O g={boxGeo} m={hairMat} p={[-R * 0.95, -R * 0.35, R * 0.45]} s={[HEAD_SZ * 0.18, HEAD_SZ * 0.95, HEAD_SZ * 0.32]} outline={ol} />
              <O g={boxGeo} m={hairMat} p={[R * 0.95, -R * 0.35, R * 0.45]} s={[HEAD_SZ * 0.18, HEAD_SZ * 0.95, HEAD_SZ * 0.32]} outline={ol} />
              {/* Articulated 3D Voxel Ponytail in back */}
              <O g={boxGeo} m={hairMat} p={[0, -R * 0.25, -R * 1.18]} r={[0.22, 0, 0]} s={[HEAD_SZ * 0.42, HEAD_SZ * 0.95, HEAD_SZ * 0.32]} outline={ol} />
            </>
          )}

          {c.hair === 'bob' && (
            <>
              {/* Sleek voxel bob cut (Efe) */}
              <O g={boxGeo} m={hairMat} p={[0, R * 0.66, R * 0.96]} s={[HEAD_SZ * 1.02, HEAD_SZ * 0.24, HEAD_SZ * 0.14]} outline={false} />
              <O g={boxGeo} m={hairMat} p={[-R * 0.98, -R * 0.15, 0.04]} s={[HEAD_SZ * 0.18, HEAD_SZ * 1.05, HEAD_SZ * 0.92]} outline={ol} />
              <O g={boxGeo} m={hairMat} p={[R * 0.98, -R * 0.15, 0.04]} s={[HEAD_SZ * 0.18, HEAD_SZ * 1.05, HEAD_SZ * 0.92]} outline={ol} />
            </>
          )}

          {c.hair === 'bun' && (
            <>
              <O g={boxGeo} m={hairMat} p={[0, R * 0.66, R * 0.95]} s={[HEAD_SZ * 0.96, HEAD_SZ * 0.2, HEAD_SZ * 0.12]} outline={false} />
              {/* Top 3D Voxel Bun */}
              <O g={boxGeo} m={hairMat} p={[0, R * 1.28, -R * 0.25]} s={[HEAD_SZ * 0.48, HEAD_SZ * 0.42, HEAD_SZ * 0.48]} outline={ol} />
            </>
          )}

          {(c.hair === 'curly' || c.hair === 'afro') && (
            <>
              {/* Volumetric curly voxel puff (Makena) */}
              <O g={boxGeo} m={hairMat} p={[0, R * 1.05, 0]} s={[HEAD_SZ * 1.22, HEAD_SZ * 0.48, HEAD_SZ * 1.2]} outline={ol} />
              <O g={boxGeo} m={hairMat} p={[-R * 1.04, R * 0.35, 0]} s={[HEAD_SZ * 0.26, HEAD_SZ * 0.85, HEAD_SZ * 1.08]} outline={ol} />
              <O g={boxGeo} m={hairMat} p={[R * 1.04, R * 0.35, 0]} s={[HEAD_SZ * 0.26, HEAD_SZ * 0.85, HEAD_SZ * 1.08]} outline={ol} />
            </>
          )}
        </group>
      )}

      {/* Classic Steve / Male Voxel Goatee / Beard */}
      {c.beard && (
        <O g={boxGeo} m={hairMat} p={[0, -R * 0.78, R * 0.97]} s={[HEAD_SZ * 0.36, HEAD_SZ * 0.22, 0.018]} outline={false} />
      )}

      {/* 3D Voxel Hats */}
      {c.hat === 'cap' && hatMat && (
        <group>
          <O g={boxGeo} m={hatMat} p={[0, R * 0.78, 0]} s={[HEAD_SZ * 1.08, HEAD_SZ * 0.42, HEAD_SZ * 1.08]} outline={ol} />
          {/* Voxel Cap Visor Brim */}
          <O g={boxGeo} m={hatMat} p={[0, R * 0.52, R * 1.22]} s={[HEAD_SZ * 0.96, 0.038, HEAD_SZ * 0.48]} outline={ol} />
        </group>
      )}
      {c.hat === 'beanie' && hatMat && (
        <group>
          <O g={boxGeo} m={hatMat} p={[0, R * 0.82, 0]} s={[HEAD_SZ * 1.08, HEAD_SZ * 0.48, HEAD_SZ * 1.08]} outline={ol} />
          <O g={boxGeo} m={hatMat} p={[0, R * 1.38, 0]} s={[0.09, 0.09, 0.09]} outline={ol} />
        </group>
      )}
      {c.hat === 'headband' && hatMat && (
        <O g={boxGeo} m={hatMat} p={[0, R * 0.52, 0]} s={[HEAD_SZ * 1.07, 0.055, HEAD_SZ * 1.07]} outline={ol} />
      )}
      {c.hat === 'helmet' && hatMat && (
        <group>
          <O g={boxGeo} m={hatMat} p={[0, R * 0.55, -0.02]} s={[HEAD_SZ * 1.14, HEAD_SZ * 0.82, HEAD_SZ * 1.14]} outline={ol} />
          {c.mask && !ghost && (
            <mesh geometry={boxGeo} material={flat(c.mask, 0.55)} position={[0, 0.0, R * 1.04]} scale={[HEAD_SZ * 0.96, HEAD_SZ * 0.52, 0.03]} />
          )}
        </group>
      )}

      {/* 3D Voxel Glasses */}
      {c.glasses && !ghost && (
        <group position={[0, R * 0.08, R + 0.014]}>
          {[-1, 1].map(sd => (
            <group key={sd} position={[sd * R * 0.46, 0, 0]}>
              <mesh geometry={boxGeo} material={flat(c.glassesColor || '#9fd3f2', 0.42)} scale={[0.11, 0.075, 0.01]} />
              {/* Voxel Rim Bars */}
              <O g={boxGeo} m={inkMaterial()} p={[0, 0.04, 0.004]} s={[0.125, 0.014, 0.016]} outline={false} />
              <O g={boxGeo} m={inkMaterial()} p={[0, -0.04, 0.004]} s={[0.125, 0.014, 0.016]} outline={false} />
              <O g={boxGeo} m={inkMaterial()} p={[-0.058, 0, 0.004]} s={[0.014, 0.085, 0.016]} outline={false} />
              <O g={boxGeo} m={inkMaterial()} p={[0.058, 0, 0.004]} s={[0.014, 0.085, 0.016]} outline={false} />
            </group>
          ))}
          <O g={boxGeo} m={inkMaterial()} p={[0, 0.015, 0.004]} s={[0.055, 0.014, 0.016]} outline={false} />
        </group>
      )}
    </group>
  );
};

// ---------------------------------------------------------------------------------------
// Voxel Hand Props & Voxel Hands
// ---------------------------------------------------------------------------------------
const HandProp: React.FC<{ type: string }> = ({ type }) => {
  switch (type) {
    case 'pill':
      return (
        <group position={[0.03, -0.045, 0.04]} rotation={[0, 0, 0.5]}>
          <mesh geometry={boxGeo} material={flat('#b57cff')} position={[0, 0.012, 0]} scale={[0.024, 0.026, 0.024]} />
          <mesh geometry={boxGeo} material={flat('#ffffff')} position={[0, -0.012, 0]} scale={[0.024, 0.026, 0.024]} />
        </group>
      );
    case 'phone':
      return (
        <group position={[0, -0.06, 0.04]} rotation={[-0.4, 0, 0]}>
          <O g={boxGeo} m={envMaterial('#1d1e26')} s={[0.09, 0.16, 0.018]} />
          <mesh geometry={boxGeo} material={flat('#7fd4ff')} position={[0, 0, 0.01]} scale={[0.078, 0.14, 0.004]} />
        </group>
      );
    case 'coffee':
    case 'mug':
      return (
        <group position={[0, -0.05, 0.04]}>
          <O g={boxGeo} m={envMaterial('#f2efe9')} s={[0.09, 0.12, 0.09]} />
          <O g={boxGeo} m={envMaterial('#c97a4b')} p={[0, 0.01, 0]} s={[0.094, 0.05, 0.094]} outline={false} />
        </group>
      );
    case 'book':
      return (
        <group position={[0, -0.05, 0.06]} rotation={[-0.5, 0, 0]}>
          <O g={boxGeo} m={envMaterial('#b83c32')} s={[0.18, 0.23, 0.04]} />
          <O g={boxGeo} m={envMaterial('#f5f1e6')} p={[0.005, 0, 0]} s={[0.17, 0.22, 0.032]} outline={false} />
        </group>
      );
    case 'flashlight':
      return (
        <group position={[0, -0.05, 0.06]} rotation={[Math.PI / 2, 0, 0]}>
          <O g={boxGeo} m={envMaterial('#2b2d38')} s={[0.055, 0.18, 0.055]} />
          <mesh geometry={boxGeo} material={flat('#fff3b0')} position={[0, 0.095, 0]} scale={[0.062, 0.016, 0.062]} />
        </group>
      );
    case 'paper':
      return <O g={boxGeo} m={envMaterial('#f7f4ec')} p={[0, -0.06, 0.06]} r={[-0.3, 0, 0.1]} s={[0.2, 0.26, 0.008]} />;
    default:
      return null;
  }
};

const VoxelHand: React.FC<{ kind: 'fist' | 'open' | 'point'; skinMat: THREE.Material; armW: number; armD: number; side: 1 | -1; outline: boolean }> = ({
  kind,
  skinMat,
  armW,
  armD,
  side,
  outline,
}) => {
  if (kind === 'point') {
    return (
      <group>
        <O g={boxGeo} m={skinMat} p={[0, -0.032, 0]} s={[armW * 0.94, 0.065, armD * 0.94]} outline={outline} />
        <O g={boxGeo} m={skinMat} p={[0, -0.075, 0.014]} s={[0.028, 0.055, 0.028]} outline={outline} />
      </group>
    );
  }
  const open = kind === 'open';
  return (
    <group>
      <O g={boxGeo} m={skinMat} p={[0, -0.034, 0]} s={[armW * 0.96, open ? 0.076 : 0.066, open ? armD * 0.82 : armD * 0.96]} outline={outline} />
      <O g={boxGeo} m={skinMat} p={[side * -0.014, -0.032, 0.032]} r={[0.6, 0, side * 0.35]} s={[0.026, 0.038, 0.026]} outline={false} />
    </group>
  );
};

// ---------------------------------------------------------------------------------------
// Glow & Ghost Pass
// ---------------------------------------------------------------------------------------
let glowTex: THREE.Texture | null = null;
export function glowTexture() {
  if (glowTex) return glowTex;
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.25, 'rgba(255,255,255,0.55)');
  grd.addColorStop(0.6, 'rgba(255,255,255,0.12)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 256, 256);
  glowTex = new THREE.CanvasTexture(c);
  return glowTex;
}

const depthOnly = new THREE.MeshBasicMaterial({ colorWrite: false, depthWrite: true, transparent: true });

function ghostMaterial(color: string, opacity: number) {
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, depthFunc: THREE.EqualDepth, toneMapped: false,
    uniforms: { uCol: { value: new THREE.Color(color) }, uEdge: { value: new THREE.Color('#f3e9ff') }, uOp: { value: opacity } },
    vertexShader: `varying vec3 vN; varying vec3 vV;
      void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `uniform vec3 uCol; uniform vec3 uEdge; uniform float uOp; varying vec3 vN; varying vec3 vV;
      void main(){ float f = 1.0 - abs(dot(normalize(vN), normalize(vV))); vec3 c = mix(uCol, uEdge, pow(f, 2.2));
        gl_FragColor = vec4(c, uOp * (0.6 + 0.4 * f)); gl_FragColor = linearToOutputTexel(gl_FragColor); }`,
  });
}

const orderRef = (order: number) => (g: THREE.Object3D | null) => {
  if (g) g.traverse(o => { o.renderOrder = order; });
};

const Ghost: React.FC<{ s: ActorState; opacity: number; color: string; order: number }> = ({ s, opacity, color, order }) => {
  const mat = useMemo(() => ghostMaterial(color, opacity), [color, opacity]);
  useEffect(() => () => mat.dispose(), [mat]);
  return (
    <>
      <group ref={orderRef(order)}><StickmanBody s={s} ghostMat={depthOnly} /></group>
      <group ref={orderRef(order + 1)}><StickmanBody s={s} ghostMat={mat} /></group>
    </>
  );
};

export const Stickman: React.FC<{ s: ActorState; shadowBlob?: boolean; ghostOpacity?: number; ghostColor?: string; ghostOrder?: number; faceGlow?: string }> = ({
  s, shadowBlob = true, ghostOpacity, ghostColor, ghostOrder = 20, faceGlow,
}) => {
  if (s.spec.ghost || ghostOpacity !== undefined) return <Ghost s={s} opacity={ghostOpacity ?? 0.3} color={ghostColor || s.spec.glow || '#b48cff'} order={ghostOrder} />;
  return <StickmanBody s={s} shadowBlob={shadowBlob} faceGlow={faceGlow} />;
};

const StickmanBody: React.FC<{ s: ActorState; shadowBlob?: boolean; faceGlow?: string; ghostMat?: THREE.Material }> = ({
  s, shadowBlob = true, faceGlow, ghostMat,
}) => {
  const c = s.cast;
  const isGhost = !!ghostMat;
  const skinCol = c.skinColor || '#b58463';
  const hairCol = c.hairColor || '#4a3121';
  const eyeCol = c.eyeColor || '#4b3f96';
  const skin = ghostMat || skinMaterial(skinCol);
  const b = s.bones;
  const hasTop = c.top && c.top !== 'none';
  const topCol = c.topColor || '#00a8b5';
  const sleeve = hasTop ? ghostMat || clothMaterial(topCol) : null;
  const cuff = hasTop ? ghostMat || clothMaterial(c.accent || shade(topCol, 1.3)) : null;
  const longSleeve = c.top === 'hoodie' || c.top === 'jacket' || c.top === 'coat' || c.top === 'suit' || c.top === 'shirt';
  const bottomCol = c.bottomColor || '#38275e';
  const pants = c.bottom && c.bottom !== 'none' ? ghostMat || legPixelMaterial(bottomCol) : null;
  const shoe = ghostMat || clothMaterial(c.shoes || '#64748b');
  const sole = ghostMat || clothMaterial('#f8fafc');
  const ol = !ghostMat;

  // 3x12x4 Slim Female Arms vs 4x12x4 Classic Male Arms
  const isSlim = c.slim ?? (c.hair === 'ponytail' || c.hair === 'bob' || c.hair === 'bun' || c.hair === 'curly' || c.top === 'dress');
  const armW = isSlim ? 0.08 : 0.1;
  const armD = 0.098;
  const legW = 0.108;
  const legD = 0.108;

  const arm = (side: 'L' | 'R') => {
    const up = side === 'L' ? b.upperArmL : b.upperArmR;
    const fo = side === 'L' ? b.forearmL : b.forearmR;
    const ha = side === 'L' ? b.handL : b.handR;
    const kind = side === 'L' ? s.pose.handL : s.pose.handR;
    const held = s.spec.hold?.[side];
    return (
      <group key={side}>
        <Bone m={up}>
          {sleeve ? (
            c.top === 'tee' ? (
              <>
                {/* Short-sleeve voxel tee (upper 54% clothed, lower 46% skin) */}
                <O g={boxGeo} m={sleeve} p={[0, -DIM.upperArm * 0.24, 0]} s={[armW * 1.08, DIM.upperArm * 0.56, armD * 1.08]} outline={ol} />
                <O g={boxGeo} m={skin} p={[0, -DIM.upperArm * 0.75, 0]} s={[armW, DIM.upperArm * 0.52, armD]} outline={ol} />
              </>
            ) : (
              <O g={boxGeo} m={sleeve} p={[0, -DIM.upperArm * 0.48, 0]} s={[armW * 1.06, DIM.upperArm * 1.04, armD * 1.06]} outline={ol} />
            )
          ) : (
            <O g={boxGeo} m={skin} p={[0, -DIM.upperArm * 0.48, 0]} s={[armW, DIM.upperArm * 1.02, armD]} outline={ol} />
          )}
        </Bone>
        <Bone m={fo}>
          {sleeve && longSleeve ? (
            <>
              <O g={boxGeo} m={sleeve} p={[0, -DIM.forearm * 0.38, 0]} s={[armW * 1.04, DIM.forearm * 0.78, armD * 1.04]} outline={ol} />
              <O g={boxGeo} m={cuff!} p={[0, -DIM.forearm * 0.8, 0]} s={[armW * 1.07, 0.042, armD * 1.07]} outline={ol} />
              <O g={boxGeo} m={skin} p={[0, -DIM.forearm * 0.9, 0]} s={[armW, DIM.forearm * 0.22, armD]} outline={ol} />
            </>
          ) : (
            <O g={boxGeo} m={skin} p={[0, -DIM.forearm * 0.48, 0]} s={[armW, DIM.forearm * 1.02, armD]} outline={ol} />
          )}
        </Bone>
        <Bone m={ha}>
          <VoxelHand kind={held ? 'fist' : (kind || 'open')} skinMat={skin} armW={armW} armD={armD} side={side === 'L' ? 1 : -1} outline={ol} />
          {held && !ghostMat && <HandProp type={held} />}
        </Bone>
      </group>
    );
  };

  const leg = (side: 'L' | 'R') => {
    const th = side === 'L' ? b.thighL : b.thighR;
    const sh = side === 'L' ? b.shinL : b.shinR;
    const ft = side === 'L' ? b.footL : b.footR;
    return (
      <group key={side}>
        <Bone m={th}>
          <O g={boxGeo} m={pants || skin} p={[0, -DIM.thigh * 0.48, 0]} s={[legW, DIM.thigh * 1.04, legD]} outline={ol} />
        </Bone>
        <Bone m={sh}>
          {pants && c.bottom === 'pants' ? (
            <O g={boxGeo} m={pants} p={[0, -DIM.shin * 0.48, 0]} s={[legW * 0.96, DIM.shin * 0.96, legD * 0.96]} outline={ol} />
          ) : (
            <O g={boxGeo} m={skin} p={[0, -DIM.shin * 0.48, 0]} s={[legW * 0.94, DIM.shin * 0.96, legD * 0.94]} outline={ol} />
          )}
        </Bone>
        <Bone m={ft}>
          {/* Voxel Shoe & Sole */}
          <O g={boxGeo} m={shoe} p={[0, -0.004, 0.026]} s={[legW * 1.05, 0.068, 0.165]} outline={ol} />
          <O g={boxGeo} m={sole} p={[0, -0.032, 0.026]} s={[legW * 1.08, 0.022, 0.172]} outline={ol} />
        </Bone>
      </group>
    );
  };

  const lying = Math.abs(s.pose.body[0]) > 45 || s.pose.hipY < -0.7;
  const W_BODY = 0.25 * (c.build ?? 1);

  return (
    <OutlineCtx.Provider value={!ghostMat}>
      <group>
        <Bone m={b.hips}>
          {/* Voxel Pelvis Block */}
          <O g={boxGeo} m={pants || skin} p={[0, 0, 0]} s={[W_BODY * 0.96, 0.095, 0.128]} outline={ol} />
          {c.bottom === 'skirt' && pants && (
            <O g={boxGeo} m={pants} p={[0, -0.11, 0]} s={[W_BODY * 1.06, 0.2, 0.148]} outline={ol} />
          )}
          {c.top === 'coat' && sleeve && (
            <O g={boxGeo} m={sleeve} p={[0, -0.12, -0.01]} s={[W_BODY * 1.04, 0.22, 0.144]} outline={ol} />
          )}
        </Bone>
        <Bone m={b.spine}>
          <Top s={s} ghost={ghostMat} />
          {c.backpack && (
            <O g={boxGeo} m={ghostMat || clothMaterial(c.backpack)} p={[0, DIM.torso * 0.55, -0.14]} s={[0.22, 0.28, 0.11]} outline={ol} />
          )}
        </Bone>
        <Bone m={b.chest}>
          {/* Voxel Neck Block */}
          <O g={boxGeo} m={skin} p={[0, 0.025, 0]} s={[0.1, 0.06, 0.1]} outline={false} />
        </Bone>
        <Bone m={b.head}>
          {/* 8x8x8 Minecraft Voxel Head Cube */}
          <O g={boxGeo} m={skin} p={[0, 0, 0]} s={[HEAD_SZ, HEAD_SZ, HEAD_SZ]} outline={ol} />
          {!ghostMat && (
            <FaceShell
              face={s.face}
              mouthOpen={s.mouthOpen}
              glow={faceGlow}
              skinColor={skinCol}
              eyeColor={eyeCol}
              hairColor={hairCol}
            />
          )}
          <HeadGear s={s} ghost={ghostMat} />
        </Bone>
        {arm('L')}
        {arm('R')}
        {leg('L')}
        {leg('R')}
        {s.spec.glow && !isGhost && (
          <sprite position={s.anchors.chest.toArray()} scale={[2.4 * s.scale, 2.8 * s.scale, 1]} renderOrder={5}>
            <spriteMaterial map={glowTexture()} color={s.spec.glow} transparent opacity={0.5} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
          </sprite>
        )}
        {shadowBlob && !lying && !isGhost && (
          <mesh position={[s.pos[0], s.pos[1] + 0.006, s.pos[2]]} rotation={[-Math.PI / 2, 0, 0]} scale={[0.3 * s.scale, 0.3 * s.scale, 1]} renderOrder={1}>
            <circleGeometry args={[1, 32]} />
            <meshBasicMaterial color="#000" transparent opacity={0.22} depthWrite={false} />
          </mesh>
        )}
      </group>
    </OutlineCtx.Provider>
  );
};

export { drawFace };
