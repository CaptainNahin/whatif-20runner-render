import React from 'react';
import { At, Ball, Box, Cone, Cyl as KitCyl, Ground as KitGround, Rug } from './kit';
import type { SetProps } from './index';
import type { Vec3 } from '../types';

const Cyl: React.FC<{ p?: Vec3; r?: Vec3 | number; rad?: number; h?: number; s?: Vec3 | number; c: string; glow?: boolean }> = ({
  p,
  r,
  rad = 0.2,
  h = 0.5,
  s,
  c,
  glow,
}) => <KitCyl p={p} r={r} s={s ?? [rad, h, rad]} c={c} glow={glow} />;

const Disc: React.FC<{ p?: Vec3; r: number; c: string }> = ({ p, r, c }) => (
  <Rug p={p} w={r * 2} d={r * 2} c={c} round />
);

const Glow: React.FC<{ p?: Vec3; size?: number; color?: string; opacity?: number }> = ({
  p,
  size = 0.5,
  color = '#fef08a',
}) => <Ball p={p} s={size * 0.35} c={color} glow />;

const Ground: React.FC<{ c: string; r?: number; y?: number }> = ({ c, r = 160, y = 0 }) => (
  <KitGround c={c} size={r * 2} y={y} />
);

const Flames: React.FC<{ r?: number; k?: number; t?: number }> = ({ r = 0.5, k = 1, t = 0 }) => {
  const pulse = 0.85 + 0.2 * Math.sin(t * 11);
  const s = r * k * pulse;
  if (s <= 0.02) return null;
  return (
    <At>
      <Cone p={[0, s * 0.7, 0]} s={[s * 0.65, s * 1.4, s * 0.65]} c="#f97316" glow />
      <Cone p={[s * 0.18, s * 0.55, s * 0.1]} s={[s * 0.42, s * 1.1, s * 0.42]} c="#facc15" glow />
      <Cone p={[-s * 0.16, s * 0.5, -s * 0.1]} s={[s * 0.38, s * 0.95, s * 0.38]} c="#ef4444" glow />
    </At>
  );
};

const Smoke: React.FC<{ t?: number; h?: number; r?: number; n?: number; speed?: number; wind?: [number, number] }> = ({
  t = 0,
  h = 6,
  r = 0.5,
  n = 16,
  speed = 1,
  wind = [0.25, 0.06],
}) => {
  const count = Math.min(18, n);
  return (
    <At>
      {Array.from({ length: count }, (_, i) => {
        const phase = ((t * speed * 0.35 + i / count) % 1);
        const py = phase * h;
        const px = wind[0] * py + Math.sin(i * 2.1 + t) * r * 0.35;
        const pz = wind[1] * py + Math.cos(i * 1.7 + t) * r * 0.35;
        const sr = r * (0.35 + phase * 0.75);
        return <Ball key={i} p={[px, py, pz]} s={sr} c={i % 2 === 0 ? '#64748b' : '#94a3b8'} ico />;
      })}
    </At>
  );
};

/**
 * Shared stage marks (all grounded at y = 0 so actors stay grounded on every set).
 */
export const ISLAND_MARKS: Record<string, Vec3> = {
  center: [0, 0, 0.2],
  beach: [0, 0, 1.1],
  wreck: [-2.4, 0, -1.2],
  cargo: [-1.4, 0, -0.8],
  panel: [-1.8, 0, -1.0],
  camp: [0.2, 0, -1.1],
  shelter: [2.2, 0, -1.6],
  palm: [2.4, 0, -0.8],
  jungle: [0, 0, -1.4],
  solarPit: [-1.6, 0, -0.9],
  shore: [0, 0, 1.8],
  tide: [-1.2, 0, 1.4],
  lookout: [0, 0, -1.2],
  ridge: [0, 0, -0.8],
  stream: [1.4, 0, -0.6],
  boulder: [-1.8, 0, -1.1],
  bamboo: [2.1, 0, -1.5],
  trail: [0, 0, 0.5],
  summit: [0, 0, -0.6],
  cliff: [0, 0, 1.5],
  pad: [0, 0, -1.2],
  skid: [1.5, 0, -1.0],
  clearing: [0, 0, 0.8],
};

/** Voxel tropical palm tree with curved trunk, crown fronds, and coconuts */
const VoxelPalm: React.FC<{
  p: Vec3;
  h?: number;
  lean?: [number, number];
  scale?: number;
}> = ({ p, h = 4.6, lean = [0.06, 0.02], scale = 1 }) => {
  const segs = 7;
  const segH = (h * scale) / segs;
  const topX = lean[0] * segs * 0.45 * scale;
  const topZ = lean[1] * segs * 0.45 * scale;
  const topY = h * scale;

  const frondAngles = [
    0,
    Math.PI * 0.25,
    Math.PI * 0.5,
    Math.PI * 0.75,
    Math.PI,
    Math.PI * 1.25,
    Math.PI * 1.5,
    Math.PI * 1.75,
  ];

  return (
    <At p={p}>
      {Array.from({ length: segs }, (_, i) => {
        const w = (0.34 - i * 0.022) * scale;
        const ox = lean[0] * i * 0.45 * scale;
        const oz = lean[1] * i * 0.45 * scale;
        return (
          <Box
            key={i}
            p={[ox, (i + 0.5) * segH, oz]}
            s={[w, segH * 1.04, w]}
            c={i % 2 === 0 ? '#8c6239' : '#75512d'}
          />
        );
      })}
      <Box p={[topX, topY + 0.14 * scale, topZ]} s={[0.48 * scale, 0.34 * scale, 0.48 * scale]} c="#3f8f3d" />
      <Box p={[topX + 0.22 * scale, topY - 0.06 * scale, topZ + 0.12 * scale]} s={0.2 * scale} c="#4e341c" />
      <Box p={[topX - 0.2 * scale, topY - 0.08 * scale, topZ + 0.18 * scale]} s={0.19 * scale} c="#5a3d22" />
      <Box p={[topX + 0.06 * scale, topY - 0.09 * scale, topZ - 0.22 * scale]} s={0.19 * scale} c="#472f19" />
      {frondAngles.map((ang, idx) => (
        <At key={idx} p={[topX, topY + 0.18 * scale, topZ]} r={[0, ang, 0]}>
          <Box p={[0.58 * scale, 0.06 * scale, 0]} r={[0, 0, -0.16]} s={[0.95 * scale, 0.12 * scale, 0.42 * scale]} c="#4ca34e" />
          <Box p={[1.38 * scale, -0.18 * scale, 0]} r={[0, 0, -0.44]} s={[0.85 * scale, 0.1 * scale, 0.36 * scale]} c="#3f9142" />
          <Box p={[1.95 * scale, -0.52 * scale, 0]} r={[0, 0, -0.72]} s={[0.52 * scale, 0.08 * scale, 0.26 * scale]} c="#337a36" />
        </At>
      ))}
    </At>
  );
};

// ============================================================================
// SET 1: CRASH SURF (crash_surf)
// Smoking airplane fuselage split open in shallow ocean waves, scattered
// suitcases, burning engine debris, sheared wing stub, and foam surf.
// ============================================================================
export const CrashSurfSet: React.FC<SetProps> = ({ t = 0 }) => {
  return (
    <>
      {/* Deep ocean backdrop and turquoise shallow surf */}
      <Ground c="#0b6fa4" r={160} y={-0.18} />
      <Box p={[0, -0.12, 0]} s={[68, 0.08, 52]} c="#189cc4" />
      <Box p={[0, -0.06, 0]} s={[42, 0.06, 30]} c="#38d2d9" />

      {/* Rolling white surf foam bands washing onto the sandbar */}
      <Box p={[0, -0.02, 3.6]} s={[30, 0.04, 1.2]} c="#eefcff" />
      <Box p={[0, -0.02, 5.8]} s={[34, 0.04, 0.85]} c="#d7f6ff" />
      <Box p={[0, -0.02, -6.5]} s={[32, 0.04, 1.1]} c="#eefcff" />

      {/* Wet sandbar and beach shoreline at y=0 */}
      <Box p={[0, -0.04, -0.4]} s={[28, 0.08, 8.2]} c="#dfbe82" />
      <Box p={[0, -0.03, -1.2]} s={[22, 0.06, 5.8]} c="#f2d59b" />
      <Box p={[0, -0.035, 2.2]} s={[25, 0.05, 2.2]} c="#c9a66b" />

      {/* Split-open smoking fuselage main cabin section on the left surf */}
      <At p={[-4.8, 0, -2.8]} r={[0.04, 0.38, -0.1]}>
        <Box p={[0, 1.15, 0]} s={[5.8, 2.2, 2.45]} c="#e5ebf2" />
        <Box p={[0, 2.15, 0]} s={[5.4, 0.42, 1.9]} c="#f5f8fc" />
        {/* Blue airline cheatline stripe */}
        <Box p={[0, 1.22, 1.24]} s={[5.6, 0.3, 0.05]} c="#1d63b8" />
        <Box p={[0, 1.22, -1.24]} s={[5.6, 0.3, 0.05]} c="#1d63b8" />
        {/* Cabin windows */}
        {[-1.8, -0.9, 0, 0.9, 1.8].map((wx, i) => (
          <Box key={i} p={[wx, 1.52, 1.25]} s={[0.38, 0.46, 0.06]} c="#1e293b" />
        ))}
        {/* Nose cone */}
        <Box p={[-3.35, 1.0, 0]} s={[1.2, 1.65, 1.9]} c="#d8e0ea" />
        <Box p={[-3.2, 1.55, 0]} r={[0, 0, 0.35]} s={[0.85, 0.58, 1.55]} c="#0f172a" />
        {/* Jagged split-open tail rupture revealing interior seats & cargo */}
        <Box p={[2.88, 1.15, 0]} s={[0.35, 2.1, 2.35]} c="#1e293b" />
        <Box p={[3.1, 0.7, 0.65]} r={[0.2, 0.3, -0.35]} s={[0.9, 0.4, 0.14]} c="#94a3b8" />
        <Box p={[3.0, 1.5, -0.6]} r={[-0.2, -0.3, 0.4]} s={[1.0, 0.38, 0.14]} c="#64748b" />
        {/* Exposed blue airline seat inside rupture */}
        <Box p={[2.45, 0.75, 0.45]} s={[0.45, 0.75, 0.48]} c="#2563eb" />
      </At>

      {/* Severed tail fin assembly in the right surf */}
      <At p={[5.4, 0, -3.6]} r={[-0.08, -0.45, 0.14]}>
        <Box p={[0, 0.85, 0]} s={[3.2, 1.7, 1.95]} c="#dde5ee" />
        <Box p={[0, 0.95, 0.99]} s={[3.0, 0.26, 0.05]} c="#1d63b8" />
        {/* Tall vertical stabilizer */}
        <Box p={[0.6, 2.45, 0]} r={[0, 0, -0.22]} s={[1.5, 2.4, 0.28]} c="#1d63b8" />
        <Box p={[0.9, 3.1, 0]} r={[0, 0, -0.22]} s={[1.1, 0.5, 0.3]} c="#f8fafc" />
      </At>

      {/* Burning jet turbine engine debris with active flames and smoke */}
      <At p={[-1.9, 0, -3.5]} r={[0.08, -0.28, 0.12]}>
        <Cyl p={[0, 0.68, 0]} r={[0, 0, Math.PI / 2]} rad={0.68} h={1.85} c="#334155" />
        <Cyl p={[-0.94, 0.68, 0]} r={[0, 0, Math.PI / 2]} rad={0.56} h={0.14} c="#0f172a" />
        <Box p={[0.2, 0.25, 0.65]} s={[1.2, 0.35, 0.4]} c="#1e293b" />
      </At>
      <At p={[-1.8, 0.95, -3.4]}>
        <Flames r={0.58} k={1} t={t} />
        <Smoke t={t} h={7.5} r={0.62} n={34} speed={1.05} wind={[0.3, 0.08]} />
      </At>
      <At p={[5.1, 1.25, -3.5]}>
        <Flames r={0.42} k={1} t={t + 1.7} />
        <Smoke t={t + 1.7} h={6.0} r={0.48} n={24} speed={0.95} wind={[0.28, 0.06]} />
      </At>

      {/* Sheared aluminum wing stub & flap panel on the wet sand */}
      <At p={[-2.3, 0, -1.55]} r={[0.15, 0.42, -0.08]}>
        <Box p={[0, 0.28, 0]} s={[1.8, 0.1, 0.95]} c="#cbd5e1" />
        <Box p={[0, 0.34, 0]} s={[1.6, 0.05, 0.8]} c="#f1f5f9" />
      </At>

      {/* Scattered passenger suitcases, cargo crates, and yellow life vests */}
      <Box p={[-3.2, 0.2, 0.85]} r={[0, 0.48, 0]} s={[0.72, 0.4, 0.5]} c="#dc2626" />
      <Box p={[-3.2, 0.42, 0.85]} r={[0, 0.48, 0]} s={[0.24, 0.07, 0.08]} c="#1e293b" />
      <Box p={[2.6, 0.18, 1.1]} r={[0, -0.35, 0.08]} s={[0.66, 0.36, 0.46]} c="#2563eb" />
      <Box p={[1.5, 0.14, -2.1]} r={[0, 0.22, 0]} s={[0.58, 0.28, 0.42]} c="#eab308" />
      <Box p={[-0.8, 0.08, 1.9]} r={[0, 0.65, 0]} s={[0.46, 0.14, 0.42]} c="#f97316" />
      <Box p={[3.5, 0.26, -1.5]} r={[0, -0.2, 0]} s={[0.62, 0.52, 0.62]} c="#78350f" />

      {/* Framing coastal palms and dark volcanic reef rocks */}
      <VoxelPalm p={[-7.5, 0, -4.5]} h={5.2} lean={[0.1, 0.04]} />
      <VoxelPalm p={[7.2, 0, -4.2]} h={4.9} lean={[-0.09, 0.05]} />
      <Box p={[-6.8, 0.45, 2.2]} s={[1.6, 0.9, 1.4]} c="#3f3f46" />
      <Box p={[6.4, 0.38, 2.5]} s={[1.4, 0.76, 1.2]} c="#52525b" />
    </>
  );
};

// ============================================================================
// SET 2: JUNGLE INTERIOR (jungle_interior)
// Dense voxel palm canopy, segmented bamboo grove, hanging vines, sparkling
// freshwater stream, and mossy basalt boulders.
// ============================================================================
export const JungleInteriorSet: React.FC = () => {
  const bambooStalks: [number, number, number][] = [
    [2.6, -2.2, 5.2], [3.0, -2.5, 5.8], [3.4, -2.0, 4.9], [3.8, -2.6, 5.5],
    [4.2, -1.8, 5.1], [4.6, -2.3, 6.0], [2.3, -2.9, 4.7], [3.2, -3.1, 5.6],
    [-3.6, -2.4, 4.8], [-4.1, -2.8, 5.4], [-4.5, -2.1, 5.0], [-3.2, -3.0, 5.3],
  ];

  const vines: [number, number, number][] = [
    [-2.8, -2.2, 3.2], [-1.2, -3.4, 3.6], [0.8, -3.2, 3.4], [2.4, -2.6, 3.0],
    [-4.2, -1.5, 3.5], [4.4, -1.4, 3.3], [0.0, -4.2, 3.8],
  ];

  return (
    <>
      {/* Rich emerald jungle moss & soil floor at y=0 */}
      <Ground c="#2d5a27" r={120} y={-0.04} />
      <Box p={[0, -0.02, 0]} s={[28, 0.04, 20]} c="#36692f" />
      {/* Dirt and stepping-stone trail through the clearing */}
      <Box p={[0, -0.01, 0.2]} s={[9.5, 0.03, 3.8]} c="#5c4934" />
      {[-3.2, -1.8, -0.4, 1.0, 2.4].map((sx, i) => (
        <Box key={i} p={[sx, 0.01, 0.3 + (i % 2) * 0.35]} s={[0.75, 0.04, 0.55]} c="#64748b" />
      ))}

      {/* Sparkling freshwater stream cutting through the right foreground/midground */}
      <At p={[2.2, 0, 0.8]} r={[0, 0.32, 0]}>
        <Box p={[0, -0.015, 0]} s={[2.2, 0.04, 14]} c="#0ea5e9" />
        <Box p={[0, -0.005, 0]} s={[1.5, 0.04, 13.6]} c="#38bdf8" />
        {/* White water riffles & stream pebbles */}
        <Box p={[-0.2, 0.01, -2.0]} s={[0.65, 0.03, 0.9]} c="#e0f2fe" />
        <Box p={[0.25, 0.01, 0.5]} s={[0.55, 0.03, 1.1]} c="#e0f2fe" />
        <Box p={[-0.15, 0.01, 2.4]} s={[0.7, 0.03, 0.85]} c="#e0f2fe" />
        <Box p={[-1.15, 0.12, -1.2]} s={[0.48, 0.24, 0.55]} c="#475569" />
        <Box p={[1.18, 0.14, 1.1]} s={[0.52, 0.28, 0.48]} c="#64748b" />
      </At>

      {/* Mossy volcanic basalt boulders on the left & back */}
      <At p={[-2.9, 0, -1.8]}>
        <Box p={[0, 0.65, 0]} s={[1.8, 1.3, 1.5]} c="#3f3f46" />
        <Box p={[0.1, 1.32, 0]} s={[1.5, 0.18, 1.25]} c="#4ca34e" />
        <Box p={[1.0, 0.38, 0.4]} s={[0.95, 0.76, 0.88]} c="#52525b" />
        <Box p={[1.0, 0.78, 0.4]} s={[0.8, 0.12, 0.72]} c="#3f9142" />
      </At>
      <At p={[-4.5, 0, 1.4]}>
        <Box p={[0, 0.52, 0]} s={[1.4, 1.04, 1.2]} c="#475569" />
        <Box p={[0, 1.06, 0]} s={[1.2, 0.14, 1.0]} c="#4ca34e" />
      </At>

      {/* Segmented green bamboo grove */}
      {bambooStalks.map(([bx, bz, bh], idx) => (
        <At key={idx} p={[bx, 0, bz]}>
          {Array.from({ length: 6 }, (_, seg) => (
            <React.Fragment key={seg}>
              <Cyl p={[0, seg * (bh / 6) + bh / 12, 0]} rad={0.075} h={bh / 6 - 0.03} c="#84cc16" />
              <Cyl p={[0, (seg + 1) * (bh / 6), 0]} rad={0.09} h={0.04} c="#4d7c0f" />
            </React.Fragment>
          ))}
          <Box p={[0.22, bh * 0.75, 0]} r={[0, 0, -0.35]} s={[0.48, 0.08, 0.18]} c="#65a30d" />
          <Box p={[-0.22, bh * 0.88, 0.1]} r={[0, 0.4, 0.35]} s={[0.45, 0.08, 0.18]} c="#4d7c0f" />
        </At>
      ))}

      {/* Dense voxel palm canopy & giant jungle ferns */}
      <VoxelPalm p={[-5.2, 0, -3.5]} h={5.8} lean={[0.08, 0.04]} scale={1.1} />
      <VoxelPalm p={[-1.8, 0, -4.6]} h={6.2} lean={[0.04, 0.06]} scale={1.12} />
      <VoxelPalm p={[1.6, 0, -4.8]} h={5.9} lean={[-0.05, 0.05]} scale={1.08} />
      <VoxelPalm p={[5.4, 0, -3.6]} h={5.6} lean={[-0.09, 0.03]} scale={1.06} />
      <VoxelPalm p={[-6.4, 0, 0.6]} h={5.3} lean={[0.11, -0.02]} />
      <VoxelPalm p={[6.2, 0, 0.8]} h={5.4} lean={[-0.1, -0.03]} />

      {/* Hanging voxel jungle vines descending from the upper canopy */}
      {vines.map(([vx, vz, vh], i) => (
        <At key={i} p={[vx, 5.4, vz]}>
          <Box p={[0, -vh * 0.5, 0]} s={[0.09, vh, 0.09]} c="#3f9142" />
          <Box p={[0.08, -vh * 0.35, 0]} s={[0.18, 0.28, 0.08]} c="#4ca34e" />
          <Box p={[-0.08, -vh * 0.72, 0]} s={[0.18, 0.26, 0.08]} c="#65a30d" />
        </At>
      ))}

      {/* Low tropical ferns & broad leaves */}
      {[-3.8, -1.4, 0.9, 3.6, 4.8].map((fx, i) => (
        <At key={i} p={[fx, 0, -2.9 - (i % 2) * 0.7]}>
          <Box p={[0, 0.28, 0]} s={[0.75, 0.45, 0.65]} c="#2e7d32" />
          <Box p={[0, 0.52, 0]} s={[0.95, 0.22, 0.85]} c="#43a047" />
        </At>
      ))}
    </>
  );
};

// ============================================================================
// SET 3: SURVIVOR CAMP (survivor_camp)
// A-frame palm-frond shelter under construction, stone fire ring, driftwood
// tripod, and solar water-distillation pits.
// ============================================================================
export const SurvivorCampSet: React.FC<SetProps> = ({ t = 0 }) => {
  return (
    <>
      {/* Turquoise lagoon background and warm golden beach clearing at y=0 */}
      <Ground c="#1692b8" r={150} y={-0.16} />
      <Box p={[0, -0.04, 0]} s={[34, 0.08, 22]} c="#f1d399" />
      <Box p={[0, -0.02, -0.8]} s={[24, 0.04, 14]} c="#f8e1b4" />
      <Box p={[0, -0.03, 7.5]} s={[32, 0.04, 1.2]} c="#e8fbff" />

      {/* A-frame bamboo & palm-frond shelter under construction on the right */}
      <At p={[3.2, 0, -2.4]} r={[0, -0.35, 0]}>
        <Box p={[0, 0.04, 0]} s={[3.2, 0.08, 2.6]} c="#d9b87c" />
        {/* Slanted bamboo rafters */}
        <Box p={[-0.85, 1.15, 1.1]} r={[0, 0, -0.58]} s={[0.14, 2.65, 0.14]} c="#84cc16" />
        <Box p={[0.85, 1.15, 1.1]} r={[0, 0, 0.58]} s={[0.14, 2.65, 0.14]} c="#84cc16" />
        <Box p={[-0.85, 1.15, -1.1]} r={[0, 0, -0.58]} s={[0.14, 2.65, 0.14]} c="#65a30d" />
        <Box p={[0.85, 1.15, -1.1]} r={[0, 0, 0.58]} s={[0.14, 2.65, 0.14]} c="#65a30d" />
        {/* Ridgepole */}
        <Box p={[0, 2.15, 0]} s={[0.16, 0.16, 2.8]} c="#a37c40" />
        {/* Palm-thatch roof panels (one side completed, right side half-framed for construction) */}
        <Box p={[-0.58, 1.55, 0]} r={[0, 0, 0.98]} s={[0.12, 1.45, 2.5]} c="#4ca34e" />
        <Box p={[-0.95, 0.85, 0]} r={[0, 0, 0.98]} s={[0.12, 1.35, 2.55]} c="#3f9142" />
        <Box p={[0.58, 1.55, -0.4]} r={[0, 0, -0.98]} s={[0.12, 1.35, 1.6]} c="#4ca34e" />
        {/* Woven palm sleeping mats inside */}
        <Box p={[-0.35, 0.09, 0]} s={[0.85, 0.06, 1.85]} c="#c89d54" />
        <Box p={[0.45, 0.09, 0]} s={[0.85, 0.06, 1.85]} c="#b88b42" />
      </At>

      {/* Stone fire ring & driftwood log seats at center-back */}
      <At p={[0.1, 0, -2.1]}>
        <Disc p={[0, 0.02, 0]} r={0.95} c="#3b2f26" />
        {Array.from({ length: 12 }, (_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return (
            <Box
              key={i}
              p={[Math.cos(a) * 0.88, 0.14, Math.sin(a) * 0.88]}
              r={[0, -a, 0]}
              s={[0.34, 0.28, 0.28]}
              c={i % 2 === 0 ? '#64748b' : '#475569'}
            />
          );
        })}
        <Box p={[0, 0.16, 0]} r={[0, 0.4, 0]} s={[0.95, 0.15, 0.18]} c="#6b4423" />
        <Box p={[0, 0.18, 0]} r={[0, -0.6, 0]} s={[0.95, 0.15, 0.18]} c="#5c3a1d" />
        <Flames r={0.35} k={0.85} t={t} />
        {/* Driftwood log benches */}
        <Box p={[-1.45, 0.22, 0.35]} r={[0, 0.32, 0]} s={[0.38, 0.34, 1.45]} c="#8c6239" />
        <Box p={[1.45, 0.22, 0.35]} r={[0, -0.32, 0]} s={[0.38, 0.34, 1.45]} c="#8c6239" />
      </At>

      {/* Driftwood aiming tripod gimbal */}
      <At p={[-1.4, 0, -2.3]}>
        <Box p={[-0.36, 0.72, 0.28]} r={[0.22, 0, -0.26]} s={[0.1, 1.55, 0.1]} c="#8c6239" />
        <Box p={[0.36, 0.72, 0.28]} r={[0.22, 0, 0.26]} s={[0.1, 1.55, 0.1]} c="#8c6239" />
        <Box p={[0, 0.72, -0.38]} r={[-0.28, 0, 0]} s={[0.1, 1.55, 0.1]} c="#75512d" />
        <Box p={[0, 1.38, 0]} s={[0.3, 0.12, 0.3]} c="#d4a359" />
      </At>

      {/* Solar water-distillation pits on the left with translucent plastic cone & center stone */}
      {[-3.2, -4.5, -2.2].map((px, idx) => {
        const pz = idx === 2 ? -3.4 : -1.5;
        return (
          <At key={idx} p={[px, 0, pz]}>
            <Disc p={[0, 0.015, 0]} r={0.62} c="#8c6d46" />
            <Disc p={[0, 0.025, 0]} r={0.46} c="#3f2e1e" />
            {/* Collection cup inside pit */}
            <Cyl p={[0, 0.08, 0]} rad={0.11} h={0.14} c="#f8fafc" />
            <Cyl p={[0, 0.14, 0]} rad={0.09} h={0.03} c="#38bdf8" />
            {/* Clear plastic sheet stretched over pit with pebble weight */}
            <Box p={[0, 0.17, 0]} s={[1.05, 0.03, 1.05]} c="#bae6fd" />
            <Box p={[0, 0.2, 0]} s={[0.16, 0.1, 0.16]} c="#475569" />
            {/* Anchor stones around perimeter */}
            <Box p={[0.52, 0.08, 0]} s={[0.18, 0.14, 0.18]} c="#64748b" />
            <Box p={[-0.52, 0.08, 0]} s={[0.18, 0.14, 0.18]} c="#64748b" />
            <Box p={[0, 0.08, 0.52]} s={[0.18, 0.14, 0.18]} c="#475569" />
            <Box p={[0, 0.08, -0.52]} s={[0.18, 0.14, 0.18]} c="#475569" />
          </At>
        );
      })}

      {/* Camp palm trees & stacked coconut pile */}
      <VoxelPalm p={[-5.4, 0, -3.2]} h={5.0} lean={[0.09, 0.03]} />
      <VoxelPalm p={[5.6, 0, -3.4]} h={5.2} lean={[-0.08, 0.04]} />
      <VoxelPalm p={[0.4, 0, -5.2]} h={5.5} lean={[0.03, 0.06]} />
      <Box p={[1.8, 0.14, -1.1]} s={0.26} c="#5a3d22" />
      <Box p={[2.08, 0.14, -1.15]} s={0.25} c="#4e341c" />
      <Box p={[1.94, 0.36, -1.12]} s={0.24} c="#6b4423" />
    </>
  );
};

// ============================================================================
// SET 4: VOLCANIC RIDGE (volcanic_ridge)
// Steep rocky mountain trail overlooking the entire miniature island, lagoon,
// and vast ocean horizon.
// ============================================================================
export const VolcanicRidgeSet: React.FC = () => {
  return (
    <>
      {/* Vast endless Pacific Ocean below the mountain ridge */}
      <Ground c="#075985" r={180} y={-8.0} />
      <Box p={[0, -7.8, -28]} s={[160, 0.2, 95]} c="#0369a1" />

      {/* Miniature panoramic island & turquoise lagoon visible down below in the distance */}
      <At p={[0, -6.5, -24]}>
        <Box p={[0, 0, 0]} s={[26, 0.2, 16]} c="#2dd4bf" />
        <Box p={[0, 0.18, 0]} s={[18, 0.3, 10]} c="#f2d59b" />
        <Box p={[0, 0.45, -1.2]} s={[11, 0.5, 6]} c="#3f9142" />
        {/* Tiny smoking wreck speck on the distant beach below */}
        <Box p={[-5.5, 0.42, 2.2]} s={[1.8, 0.4, 0.6]} c="#e2e8f0" />
      </At>

      {/* High volcanic basalt ridge trail platform at y=0 */}
      <Box p={[0, -2.5, 0.2]} s={[18, 5.0, 7.6]} c="#27272a" />
      <Box p={[0, -0.06, 0.2]} s={[16.5, 0.12, 6.8]} c="#3f3f46" />
      {/* Rocky trail path & ledges */}
      <Box p={[0, -0.02, 0.3]} s={[13.5, 0.06, 4.6]} c="#52525b" />
      {[-4.2, -2.4, -0.6, 1.2, 3.0].map((tx, i) => (
        <Box key={i} p={[tx, 0.01, 0.5 + (i % 2) * 0.3]} s={[1.1, 0.04, 0.85]} c="#71717a" />
      ))}

      {/* Dramatic jagged volcanic crags framing the left and right ridge */}
      <At p={[-5.8, 0, -1.8]}>
        <Box p={[0, 1.4, 0]} s={[2.8, 2.8, 2.6]} c="#27272a" />
        <Box p={[0.6, 2.9, -0.2]} s={[1.8, 1.6, 1.8]} c="#3f3f46" />
        <Box p={[1.4, 0.7, 0.6]} s={[1.4, 1.4, 1.4]} c="#52525b" />
      </At>
      <At p={[5.8, 0, -1.6]}>
        <Box p={[0, 1.6, 0]} s={[2.8, 3.2, 2.6]} c="#27272a" />
        <Box p={[-0.5, 3.3, -0.2]} s={[1.9, 1.5, 1.8]} c="#3f3f46" />
        <Box p={[-1.3, 0.8, 0.5]} s={[1.3, 1.6, 1.3]} c="#52525b" />
      </At>

      {/* Stacked stone surveyor cairn on the cliff edge */}
      <At p={[-2.2, 0, -2.3]}>
        <Box p={[0, 0.22, 0]} s={[0.75, 0.44, 0.65]} c="#52525b" />
        <Box p={[0, 0.56, 0]} s={[0.52, 0.28, 0.48]} c="#71717a" />
        <Box p={[0, 0.8, 0]} s={[0.32, 0.22, 0.32]} c="#a1a1aa" />
      </At>

      {/* Wind-sculpted scrub bushes & ridge palms */}
      <Box p={[2.8, 0.28, -2.2]} s={[0.95, 0.55, 0.85]} c="#3f6212" />
      <Box p={[-3.6, 0.24, -2.0]} s={[0.8, 0.48, 0.75]} c="#365314" />
      <VoxelPalm p={[-6.8, 0, 1.2]} h={4.2} lean={[0.16, 0.04]} scale={0.9} />
      <VoxelPalm p={[6.6, 0, 1.0]} h={4.4} lean={[-0.15, 0.04]} scale={0.9} />
    </>
  );
};

// ============================================================================
// SET 5: CYCLONE NIGHT BEACH (cyclone_night_beach)
// Dark storm lighting, heavy 3D rain particles, rising tide waves, shredded
// camp debris, and collapsed wreckage beam trapping the crush.
// ============================================================================
export const CycloneNightBeachSet: React.FC<SetProps> = ({ t = 0 }) => {
  const surgeZ = Math.sin(t * 2.4) * 0.35;

  // Deterministic 3D slanted rain streaks falling across the storm scene
  const rainDrops = Array.from({ length: 36 }, (_, i) => {
    const rx = ((i * 7.3) % 16) - 8.0;
    const rz = ((i * 4.1) % 8) - 3.5;
    const ry = 4.6 - (((t * 9.5 + i * 0.47) % 4.4));
    return [rx, ry, rz] as Vec3;
  });

  return (
    <>
      {/* Dark churning cyclone ocean and storm-flooded beach at y=0 */}
      <Ground c="#082f49" r={160} y={-0.14} />
      <Box p={[0, -0.06, 0]} s={[48, 0.08, 32]} c="#0c4a6e" />
      <Box p={[0, -0.03, -0.6]} s={[26, 0.06, 9.5]} c="#6b5b45" />
      <Box p={[0, -0.02, -1.8]} s={[22, 0.04, 6.2]} c="#7c6a52" />

      {/* Rising storm-surge wave walls crashing onto the tideline */}
      <At p={[0, 0, 2.2 + surgeZ]}>
        <Box p={[0, 0.24, 0]} s={[28, 0.48, 1.4]} c="#0369a1" />
        <Box p={[0, 0.52, -0.45]} s={[28, 0.18, 0.75]} c="#e0f2fe" />
        <Box p={[0, 0.04, -1.1]} s={[26, 0.06, 1.1]} c="#bae6fd" />
      </At>

      {/* Collapsed fuselage rib & heavy wreckage beam at the rising tideline */}
      <At p={[1.6, 0, 0.4]} r={[0.06, -0.25, -0.14]}>
        <Box p={[0, 0.32, 0]} s={[2.8, 0.48, 0.75]} c="#475569" />
        <Box p={[0, 0.58, 0]} s={[2.6, 0.12, 0.82]} c="#94a3b8" />
        <Box p={[-0.9, 0.75, 0.2]} r={[0, 0, 0.45]} s={[1.2, 0.18, 0.55]} c="#cbd5e1" />
        {/* Basalt fulcrum rock beside the wreckage beam */}
        <Box p={[-0.55, 0.22, 0.45]} s={[0.48, 0.42, 0.45]} c="#1e293b" />
      </At>

      {/* Soaked fire pit ready for the lithium battery spark */}
      <At p={[0.0, 0, -1.5]}>
        <Disc p={[0, 0.02, 0]} r={0.88} c="#1e293b" />
        {Array.from({ length: 10 }, (_, i) => {
          const a = (i / 10) * Math.PI * 2;
          return (
            <Box
              key={i}
              p={[Math.cos(a) * 0.82, 0.14, Math.sin(a) * 0.82]}
              r={[0, -a, 0]}
              s={[0.32, 0.26, 0.26]}
              c="#334155"
            />
          );
        })}
        <Box p={[0, 0.16, 0]} r={[0, 0.4, 0]} s={[0.9, 0.16, 0.18]} c="#451a03" />
        <Box p={[0, 0.18, 0]} r={[0, -0.5, 0]} s={[0.9, 0.16, 0.18]} c="#3b1704" />
        {/* Green palm fronds heaped beside the pit */}
        <Box p={[0.95, 0.14, -0.2]} r={[0, 0.3, 0.1]} s={[0.85, 0.18, 0.45]} c="#15803d" />
      </At>

      {/* Shredded A-frame shelter debris blown down by the cyclone */}
      <At p={[4.2, 0, -2.8]} r={[0.2, -0.4, 0.35]}>
        <Box p={[0, 0.35, 0]} s={[0.14, 2.4, 0.14]} c="#4d7c0f" />
        <Box p={[0.6, 0.25, 0.3]} r={[0, 0.4, 0.8]} s={[0.14, 2.2, 0.14]} c="#3f6212" />
        <Box p={[-0.4, 0.15, 0]} s={[1.2, 0.1, 1.4]} c="#166534" />
      </At>

      {/* Wind-lashed palm trees bending violently in the gale */}
      <VoxelPalm p={[-5.2, 0, -3.2]} h={4.8} lean={[0.28, 0.08]} />
      <VoxelPalm p={[5.4, 0, -3.4]} h={4.9} lean={[0.26, 0.09]} />

      {/* Slanted 3D rain streaks */}
      {rainDrops.map((rp, i) => (
        <Box key={i} p={rp} r={[0, 0, -0.28]} s={[0.025, 0.52, 0.025]} c="#bae6fd" />
      ))}
    </>
  );
};

// ============================================================================
// SET 6: RIDGE HELIPAD (ridge_helipad)
// High clearing with a descending/landed voxel rescue helicopter, spinning
// rotors, and searchlights.
// ============================================================================
export const RidgeHelipadSet: React.FC<SetProps> = ({ t = 0 }) => {
  const rotorAngle = t * 22;

  return (
    <>
      {/* Distant ocean horizon far below the summit */}
      <Ground c="#0c4a6e" r={180} y={-7.5} />

      {/* High summit basalt clearing at y=0 */}
      <Box p={[0, -2.4, 0]} s={[22, 4.8, 14]} c="#27272a" />
      <Box p={[0, -0.05, 0]} s={[20, 0.1, 12.5]} c="#3f3f46" />
      <Box p={[0, -0.02, 0.2]} s={[16, 0.05, 9.5]} c="#52525b" />

      {/* Stone Helipad Ring and white 'H' landing marker */}
      <At p={[0, 0, -1.8]}>
        <Disc p={[0, 0.015, 0]} r={3.6} c="#334155" />
        <Disc p={[0, 0.025, 0]} r={3.2} c="#475569" />
        {/* White 'H' markings */}
        <Box p={[-0.95, 0.035, 0]} s={[0.35, 0.02, 2.2]} c="#f8fafc" />
        <Box p={[0.95, 0.035, 0]} s={[0.35, 0.02, 2.2]} c="#f8fafc" />
        <Box p={[0, 0.035, 0]} s={[1.9, 0.02, 0.35]} c="#f8fafc" />
        {/* Perimeter helipad beacon lights */}
        {Array.from({ length: 8 }, (_, i) => {
          const a = (i / 8) * Math.PI * 2;
          return (
            <Glow
              key={i}
              p={[Math.cos(a) * 3.4, 0.12, Math.sin(a) * 3.4]}
              size={0.28}
              color="#facc15"
              opacity={0.75}
            />
          );
        })}
      </At>

      {/* Voxel Coast Guard Rescue Helicopter with spinning rotors and searchlights */}
      <At p={[0.2, 0, -2.6]} r={[0, 0.22, 0]}>
        {/* Landing skids */}
        <Box p={[0, 0.1, 0.88]} s={[3.0, 0.12, 0.14]} c="#1e293b" />
        <Box p={[0, 0.1, -0.88]} s={[3.0, 0.12, 0.14]} c="#1e293b" />
        <Box p={[-0.85, 0.38, 0.88]} s={[0.12, 0.52, 0.12]} c="#334155" />
        <Box p={[0.85, 0.38, 0.88]} s={[0.12, 0.52, 0.12]} c="#334155" />
        <Box p={[-0.85, 0.38, -0.88]} s={[0.12, 0.52, 0.12]} c="#334155" />
        <Box p={[0.85, 0.38, -0.88]} s={[0.12, 0.52, 0.12]} c="#334155" />

        {/* Main rescue orange & white fuselage */}
        <Box p={[0, 1.32, 0]} s={[3.4, 1.48, 1.75]} c="#ea580c" />
        <Box p={[0, 1.38, 0]} s={[3.44, 0.38, 1.8]} c="#f8fafc" />
        {/* Open side sliding rescue door */}
        <Box p={[0.15, 1.28, 0.89]} s={[1.25, 1.05, 0.06]} c="#0f172a" />
        {/* Cockpit nose & glass */}
        <Box p={[-1.95, 1.15, 0]} s={[0.95, 1.08, 1.52]} c="#ea580c" />
        <Box p={[-1.85, 1.48, 0]} s={[0.85, 0.62, 1.42]} c="#38bdf8" />

        {/* Tail boom & stabilizer fin */}
        <Box p={[2.85, 1.52, 0]} s={[2.6, 0.52, 0.52]} c="#ea580c" />
        <Box p={[3.95, 2.05, 0]} r={[0, 0, 0.28]} s={[0.62, 1.25, 0.16]} c="#f8fafc" />
        {/* Spinning tail rotor */}
        <At p={[4.05, 2.1, 0.18]} r={[0, 0, rotorAngle * 1.6]}>
          <Box s={[0.95, 0.1, 0.04]} c="#0f172a" />
          <Box s={[0.1, 0.95, 0.04]} c="#0f172a" />
        </At>

        {/* Rotor mast & spinning 4-blade main rotor */}
        <Cyl p={[0, 2.25, 0]} rad={0.16} h={0.45} c="#334155" />
        <At p={[0, 2.48, 0]} r={[0, rotorAngle, 0]}>
          <Box s={[6.8, 0.05, 0.28]} c="#0f172a" />
          <Box s={[0.28, 0.05, 6.8]} c="#0f172a" />
        </At>

        {/* Bright searchlights under nose & belly */}
        <Glow p={[-2.15, 0.65, 0.35]} size={2.2} color="#fef08a" opacity={0.7} />
        <Glow p={[-2.15, 0.65, -0.35]} size={2.2} color="#fef08a" opacity={0.7} />
      </At>
      {/* Searchlight ground pool */}
      <Disc p={[-1.8, 0.03, -0.4]} r={1.8} c="#fef9c3" />

      {/* Framing summit boulders and palms */}
      <Box p={[-6.4, 0.85, -2.2]} s={[2.2, 1.7, 2.0]} c="#27272a" />
      <Box p={[6.4, 0.95, -2.0]} s={[2.4, 1.9, 2.0]} c="#27272a" />
      <VoxelPalm p={[-6.8, 0, 1.5]} h={4.4} lean={[0.12, 0.04]} scale={0.92} />
      <VoxelPalm p={[6.8, 0, 1.4]} h={4.5} lean={[-0.12, 0.04]} scale={0.92} />
    </>
  );
};
