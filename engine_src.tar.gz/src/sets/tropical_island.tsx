// Tropical Island voxel set: turquoise Minecraft lagoon, white shoreline foam, golden voxel sand
// peninsula, smoking passenger-jet fuselage wreckage, polished aluminum wing-panel reflector,
// cobblestone campfire ring, bamboo/palm-thatch shelter, stepped voxel palm trees with coconuts,
// and volcanic basalt sea stacks on the horizon.
import React from 'react';
import type { Vec3 } from '../types';
import { At, Box, Ground, mix, rng } from './kit';
import { lampsOn, LightPool, skyFlat } from './outdoorKit';
import { Smoke } from './props';

export const TROPICAL_ISLAND_MARKS: Record<string, Vec3> = {
  center: [0, 0, 0],
  beach: [-1.2, 0, 0.8],
  wreck: [-3.4, 0, -1.4],
  cargo: [-4.2, 0, -0.6],
  panel: [-1.6, 0, -1.2],
  camp: [0.4, 0, -0.6],
  shelter: [3.4, 0, -1.4],
  palm: [2.2, 0, 0.6],
  jungle: [4.4, 0, 0.2],
  solarPit: [2.8, 0, 1.4],
  shore: [0.0, 0, 2.4],
  tide: [-2.4, 0, 2.1],
  lookout: [-0.6, 0, -2.2],
  ridge: [0.6, 0, -3.2],
};

/** Stepped Minecraft voxel palm tree with curved segmented trunk, 6 blocky fronds, and coconuts. */
const VoxelPalmTree: React.FC<{ p: Vec3; s?: number; lean?: number; ry?: number }> = ({ p, s = 1, lean = 0.18, ry = 0 }) => {
  const bark = '#785338';
  const barkDark = '#5e3f28';
  const leaf = '#3f9b48';
  const leafLight = '#58b856';
  const leafTip = '#2f7d38';
  const segs = 7;
  return (
    <At p={p} r={ry} s={s}>
      {/* Segmented curved voxel trunk */}
      {Array.from({ length: segs }, (_, i) => {
        const h = 0.52;
        const y = i * h + h / 2;
        const dx = Math.pow(i / segs, 1.5) * lean * 2.4;
        const w = Math.max(0.24, 0.38 - i * 0.018);
        return (
          <Box
            key={i}
            p={[dx, y, 0]}
            s={[w, h + 0.02, w]}
            c={i % 2 === 0 ? bark : barkDark}
          />
        );
      })}
      {/* Crown center & coconuts */}
      {(() => {
        const cx = lean * 2.4;
        const cy = segs * 0.52;
        return (
          <At p={[cx, cy, 0]}>
            <Box p={[0, 0.12, 0]} s={[0.48, 0.32, 0.48]} c={barkDark} />
            {/* 3 hanging voxel coconuts */}
            <Box p={[0.24, -0.06, 0.16]} s={[0.22, 0.22, 0.22]} c="#4f301b" />
            <Box p={[-0.22, -0.05, 0.18]} s={[0.2, 0.2, 0.2]} c="#5c3820" />
            <Box p={[0.05, -0.08, -0.24]} s={[0.21, 0.21, 0.21]} c="#4f301b" />
            {/* 6 stepped voxel palm fronds */}
            {[0, 1, 2, 3, 4, 5].map(k => {
              const a = (k * Math.PI) / 3 + 0.25;
              return (
                <At key={k} r={a}>
                  <Box p={[0.55, 0.22, 0]} s={[0.95, 0.14, 0.46]} c={leafLight} />
                  <Box p={[1.25, 0.08, 0]} s={[0.85, 0.13, 0.4]} c={leaf} />
                  <Box p={[1.82, -0.14, 0]} s={[0.6, 0.12, 0.3]} c={leafTip} />
                </At>
              );
            })}
            <Box p={[0, 0.34, 0]} s={[0.7, 0.18, 0.7]} c={leafLight} />
          </At>
        );
      })()}
    </At>
  );
};

/** Smoking passenger jet fuselage wreckage half-buried in the sand. */
const PlaneWreckage: React.FC<{ p: Vec3; ry?: number; t: number }> = ({ p, ry = 0.38, t }) => (
  <At p={p} r={ry}>
    {/* Scorched sand crater around wreck */}
    <Box p={[0, 0.02, 0]} s={[6.2, 0.04, 3.4]} c="#bfa46f" />
    <Box p={[0.4, 0.04, 0.2]} s={[4.8, 0.05, 2.5]} c="#6e6559" />

    {/* Main fuselage barrel (tilted voxel cabin) */}
    <At p={[0, 1.05, 0]} r={[0.06, 0, -0.14]}>
      <Box p={[0, 0, 0]} s={[4.8, 1.85, 2.1]} c="#eef2f7" />
      {/* Blue airline cheatline stripe */}
      <Box p={[0, -0.12, 0]} s={[4.84, 0.32, 2.14]} c="#1f5fb8" />
      <Box p={[0, -0.58, 0]} s={[4.78, 0.55, 2.04]} c="#c5ccd6" />
      {/* Passenger cabin windows */}
      {[-1.6, -0.9, -0.2, 0.5, 1.2].map((x, i) => (
        <Box key={i} p={[x, 0.26, 1.06]} s={[0.36, 0.42, 0.04]} c="#222a38" />
      ))}
      {/* Nose cone & cockpit windshield at -x */}
      <Box p={[-2.75, -0.1, 0]} s={[0.9, 1.45, 1.75]} c="#e4eaf2" />
      <Box p={[-3.3, -0.28, 0]} s={[0.5, 0.95, 1.25]} c="#323846" />
      <Box p={[-2.65, 0.36, 0]} s={[0.78, 0.42, 1.52]} c="#1b2638" />
      {/* Torn tail break at +x with exposed ribs */}
      <Box p={[2.55, 0.15, -0.2]} s={[0.55, 1.5, 1.65]} c="#7c8492" />
      <Box p={[2.8, 1.35, -0.1]} s={[0.95, 1.55, 0.24]} c="#1f5fb8" />
      <Box p={[2.95, 1.95, -0.1]} s={[0.65, 0.65, 0.22]} c="#e0422d" />
    </At>

    {/* Sheared wing stub & smoking jet engine */}
    <Box p={[-0.4, 0.38, 1.65]} r={[0.18, 0.25, -0.12]} s={[1.8, 0.16, 2.2]} c="#d5dde8" />
    <At p={[-0.9, 0.48, 2.1]} r={[0, 0.2, 0]}>
      <Box p={[0, 0, 0]} s={[1.15, 0.78, 0.78]} c="#3b4252" />
      <Box p={[-0.58, 0, 0]} s={[0.12, 0.66, 0.66]} c="#1a1d24" />
      <Smoke t={t + 2.5} h={6.5} r={0.42} n={24} wind={[0.3, -0.1]} speed={0.85} seed={7} />
    </At>

    {/* Scattered voxel suitcases */}
    <Box p={[1.8, 0.16, 1.55]} r={0.4} s={[0.58, 0.32, 0.42]} c="#c8402f" />
    <Box p={[-2.1, 0.18, 1.75]} r={-0.5} s={[0.52, 0.36, 0.38]} c="#e6a82e" />
  </At>
);

/** Bamboo & palm-thatch A-frame survival shelter. */
const VoxelShelter: React.FC<{ p: Vec3; ry?: number }> = ({ p, ry = -0.35 }) => {
  const bamboo = '#9bba5a';
  const bambooDark = '#789640';
  const thatch = '#3f8f42';
  const thatchLight = '#56ab52';
  return (
    <At p={p} r={ry}>
      {/* Sand platform & palm-leaf bedding */}
      <Box p={[0, 0.04, 0]} s={[2.8, 0.08, 2.4]} c="#dfbe7d" />
      <Box p={[-0.45, 0.11, 0]} s={[0.9, 0.08, 1.7]} c="#4ca34e" />
      <Box p={[0.55, 0.11, 0]} s={[0.9, 0.08, 1.7]} c="#4ca34e" />
      {/* Corner bamboo posts */}
      {[-1.15, 1.15].map((x, i) => (
        <React.Fragment key={i}>
          <Box p={[x, 0.85, 0.9]} s={[0.16, 1.7, 0.16]} c={bamboo} />
          <Box p={[x, 0.55, -0.95]} s={[0.16, 1.1, 0.16]} c={bambooDark} />
        </React.Fragment>
      ))}
      {/* Crossbeam */}
      <Box p={[0, 1.68, 0.9]} s={[2.6, 0.14, 0.16]} c={bambooDark} />
      {/* Slanted voxel palm-thatch roof */}
      <At p={[0, 1.22, -0.05]} r={[-0.46, 0, 0]}>
        <Box p={[0, 0, 0]} s={[2.75, 0.14, 2.35]} c={thatch} />
        <Box p={[0, 0.09, -0.15]} s={[2.55, 0.1, 1.85]} c={thatchLight} />
        <Box p={[0, 0.16, -0.3]} s={[2.25, 0.08, 1.25]} c="#6bc262" />
      </At>
    </At>
  );
};

/** Cobblestone campfire ring with driftwood logs and benches. */
const CampfireRing: React.FC<{ p: Vec3; lit?: boolean }> = ({ p, lit = false }) => (
  <At p={p}>
    {/* 8 cobblestone voxel blocks in a ring */}
    {Array.from({ length: 8 }, (_, i) => {
      const a = (i * Math.PI) / 4;
      return (
        <Box
          key={i}
          p={[Math.cos(a) * 0.48, 0.1, Math.sin(a) * 0.48]}
          r={a}
          s={[0.28, 0.2, 0.24]}
          c={i % 2 === 0 ? '#787d87' : '#616670'}
        />
      );
    })}
    {/* Charred center & crossed driftwood fuel */}
    <Box p={[0, 0.03, 0]} s={[0.72, 0.06, 0.72]} c="#2d2926" />
    <Box p={[0, 0.14, 0]} r={[0, 0.5, 0.2]} s={[0.68, 0.12, 0.14]} c="#5c3d28" />
    <Box p={[0, 0.16, 0]} r={[0, -0.6, -0.2]} s={[0.68, 0.12, 0.14]} c="#6e4b32" />
    {lit && (
      <>
        <Box p={[0, 0.34, 0]} s={[0.32, 0.38, 0.32]} c="#ff6a1a" glow />
        <Box p={[0, 0.46, 0]} s={[0.18, 0.32, 0.18]} c="#ffd84d" glow />
        <LightPool p={[0, 0.02, 0]} rx={2.8} c="#ff9442" o={0.38} />
      </>
    )}
    {/* Driftwood log bench behind the fire */}
    <Box p={[-0.95, 0.18, -1.25]} r={0.22} s={[1.55, 0.28, 0.32]} c="#7d5a3c" />
    <Box p={[1.05, 0.18, -1.2]} r={-0.25} s={[1.45, 0.28, 0.32]} c="#6e4e33" />
  </At>
);

export const TropicalIslandSet: React.FC<{ t?: number; center?: Vec3; variant?: number; time?: string }> = ({ t = 0, variant = 1, time = 'afternoon' }) => {
  const rand = rng(variant + 101);
  const isNight = lampsOn(time);
  const isStorm = time === 'dusk' || time === 'night';

  // Ocean colours shift darker during storm/dusk
  const deepSea = isStorm ? '#0a3c54' : '#0c698a';
  const midSea = isStorm ? '#145a73' : '#189bb3';
  const shallowSea = isStorm ? '#21788e' : '#35c4d6';
  const foamCol = isStorm ? '#cbe3ec' : '#f2fbff';
  const sandMain = isStorm ? '#c7b07e' : '#efd593';
  const sandWet = isStorm ? '#9e895c' : '#d6b672';
  const sandHigh = isStorm ? '#d4be8c' : '#f7e2a9';

  return (
    <group>
      {/* Infinite deep ocean floor */}
      <Ground c={deepSea} size={420} y={-0.22} />

      {/* Mid-depth lagoon & turquoise reef shelf */}
      <Box p={[0, -0.15, 0]} s={[56, 0.08, 46]} c={midSea} />
      <Box p={[0, -0.09, 0]} s={[38, 0.06, 30]} c={shallowSea} />

      {/* White voxel shoreline surf foam ring */}
      <Box p={[0, -0.04, 0]} s={[28.6, 0.04, 18.8]} c={foamCol} />
      {/* Breaking wave crests in front & back coves */}
      {[-9, -3, 3, 9].map((x, i) => (
        <React.Fragment key={i}>
          <Box p={[x, -0.03, 9.8 + (i % 2) * 0.6]} s={[4.4, 0.05, 0.35]} c={foamCol} />
          <Box p={[x * 1.1, -0.03, -10.2 - (i % 2) * 0.5]} s={[4.8, 0.05, 0.35]} c={foamCol} />
        </React.Fragment>
      ))}

      {/* Wet shoreline sand shelf */}
      <Box p={[0, -0.02, 0]} s={[26.8, 0.04, 17.2]} c={sandWet} />

      {/* Main golden voxel beach peninsula (top exactly at y = 0.00 so all marks are grounded) */}
      <Box p={[0, -0.12, -0.4]} s={[24.0, 0.24, 15.2]} c={sandMain} />
      {/* Slightly raised dry dune patches away from central walking paths */}
      <Box p={[-6.2, 0.03, -4.8]} s={[7.5, 0.06, 5.2]} c={sandHigh} />
      <Box p={[6.0, 0.03, -4.6]} s={[7.0, 0.06, 5.0]} c={sandHigh} />

      {/* Planted Prop 1: Curved Polished Aluminum Wing-Panel resting near wreck */}
      <At p={[-2.2, 0, -2.5]} r={[0, 0.42, 0]}>
        <Box p={[0, 0.05, 0]} s={[1.35, 0.08, 0.95]} c="#b8c4d4" />
        <Box p={[0, 0.16, -0.08]} r={[0.35, 0, 0]} s={[1.28, 0.06, 0.88]} c="#e8f1fa" />
        <Box p={[0, 0.22, -0.12]} r={[0.35, 0, 0]} s={[1.1, 0.04, 0.68]} c="#ffffff" glow={!isStorm} />
        {/* Blue airline trim on the torn panel edge */}
        <Box p={[0, 0.11, 0.36]} s={[1.3, 0.05, 0.14]} c="#1f5fb8" />
      </At>

      {/* Planted Prop 2: Driftwood Tripod frame near campfire */}
      <At p={[1.65, 0, -2.2]} r={[0, -0.3, 0]}>
        <Box p={[-0.28, 0.58, 0]} r={[0, 0, -0.28]} s={[0.1, 1.25, 0.1]} c="#6e4e33" />
        <Box p={[0.28, 0.58, 0]} r={[0, 0, 0.28]} s={[0.1, 1.25, 0.1]} c="#7d5a3c" />
        <Box p={[0, 0.58, -0.28]} r={[0.28, 0, 0]} s={[0.1, 1.25, 0.1]} c="#5c3d28" />
        <Box p={[0, 1.05, 0]} s={[0.34, 0.12, 0.34]} c="#9bba5a" />
      </At>

      {/* Planted Prop 3: Locked Titanium Cargo Case near fuselage break */}
      <At p={[-4.5, 0, -1.9]} r={[0, 0.55, 0]}>
        <Box p={[0, 0.14, 0]} s={[0.68, 0.28, 0.48]} c="#8a95a5" />
        <Box p={[0, 0.29, 0]} s={[0.7, 0.04, 0.5]} c="#b8c4d4" />
        <Box p={[0, 0.16, 0.245]} s={[0.22, 0.08, 0.02]} c="#1a202c" />
        <Box p={[0.05, 0.16, 0.255]} s={[0.04, 0.04, 0.02]} c="#ff3b30" glow />
      </At>

      {/* Solar Distillation Pit near [3.2, 0, 1.9] */}
      <At p={[3.2, 0, 1.9]} r={[0, -0.2, 0]}>
        <Box p={[0, 0.03, 0]} s={[1.35, 0.06, 1.35]} c="#b89b5e" />
        <Box p={[0, 0.05, 0]} s={[1.05, 0.04, 1.05]} c="#8fc8eb" />
        <Box p={[0, 0.08, 0]} s={[0.24, 0.12, 0.24]} c="#f3efe6" />
        <Box p={[0, 0.11, 0]} s={[0.12, 0.06, 0.12]} c="#616670" />
      </At>

      {/* Smoking Plane Fuselage Wreckage at [-6.2, 0, -4.8] */}
      <PlaneWreckage p={[-6.2, 0, -4.8]} ry={0.42} t={t} />

      {/* Cobblestone Campfire Ring at [0.2, 0, -2.1] */}
      <CampfireRing p={[0.2, 0, -2.1]} lit={isNight} />

      {/* Bamboo & Palm-Thatch Shelter at [5.4, 0, -4.2] */}
      <VoxelShelter p={[5.4, 0, -4.2]} ry={-0.38} />

      {/* Fallen voxel coconuts on the sand */}
      {[
        [1.9, 0.12, 0.2],
        [2.45, 0.12, 0.45],
        [2.15, 0.12, -0.25],
        [-0.8, 0.12, -1.6],
        [3.8, 0.12, -2.2],
      ].map(([x, y, z], i) => (
        <Box key={i} p={[x, y, z]} r={i * 0.7} s={[0.24, 0.24, 0.24]} c={i % 2 === 0 ? '#5c3820' : '#4a2c18'} />
      ))}

      {/* Stepped Voxel Palm Trees framing the beach (clear of camera sightlines) */}
      <VoxelPalmTree p={[-10.2, 0, -2.8]} s={1.15} lean={-0.22} ry={0.3} />
      <VoxelPalmTree p={[-8.6, 0, -7.2]} s={1.25} lean={0.18} ry={0.8} />
      <VoxelPalmTree p={[-3.2, 0, -7.8]} s={1.08} lean={-0.15} ry={-0.4} />
      <VoxelPalmTree p={[2.6, 0, -7.4]} s={1.2} lean={0.2} ry={0.5} />
      <VoxelPalmTree p={[8.4, 0, -6.4]} s={1.18} lean={0.24} ry={-0.7} />
      <VoxelPalmTree p={[9.8, 0, -1.8]} s={1.1} lean={0.16} ry={1.1} />
      <VoxelPalmTree p={[-9.6, 0, 2.8]} s={0.95} lean={-0.2} ry={-0.9} />
      <VoxelPalmTree p={[9.4, 0, 2.6]} s={1.0} lean={0.2} ry={0.6} />

      {/* Volcanic Basalt Ridge & Mossy Cliffs behind the beach (z = -9 .. -14) */}
      {[
        [-7.5, 1.4, -10.5, 4.5, 2.8, 3.2],
        [-3.5, 2.1, -11.2, 4.8, 4.2, 3.6],
        [0.8, 1.6, -10.8, 4.2, 3.2, 3.0],
        [5.2, 2.4, -11.5, 5.0, 4.8, 3.8],
        [9.5, 1.5, -10.2, 4.0, 3.0, 3.0],
      ].map(([x, y, z, w, h, d], i) => (
        <React.Fragment key={i}>
          <Box p={[x, y, z]} s={[w, h, d]} c={i % 2 === 0 ? '#50545e' : '#636875'} />
          <Box p={[x, h + 0.18, z]} s={[w * 0.92, 0.36, d * 0.92]} c={mix('#499246', '#6ab85f', (i % 3) * 0.3)} />
        </React.Fragment>
      ))}

      {/* Distant oceanic sea stacks on the horizon */}
      <Box p={[-28, 3.5, -36]} s={[7, 7, 6]} c="#455363" />
      <Box p={[-28, 7.3, -36]} s={[6.2, 0.8, 5.2]} c="#3f8544" />
      <Box p={[32, 4.5, -42]} s={[9, 9, 7]} c="#455363" />
      <Box p={[32, 9.4, -42]} s={[7.8, 0.9, 6.0]} c="#3f8544" />

      {/* Scattered beach pebbles & tropical bushes */}
      {Array.from({ length: 14 }, (_, i) => {
        const angle = (i / 14) * Math.PI * 2;
        const rx = 8.5 + rand() * 3.0;
        const rz = 4.8 + rand() * 2.2;
        const px = Math.cos(angle) * rx;
        const pz = Math.sin(angle) * rz - 1.5;
        if (Math.abs(px) < 5.5 && Math.abs(pz) < 3.5) return null;
        return (
          <Box
            key={i}
            p={[px, 0.14, pz]}
            r={rand() * 3}
            s={[0.45 + rand() * 0.35, 0.28, 0.4 + rand() * 0.3]}
            c={i % 3 === 0 ? '#4ca34e' : '#858994'}
          />
        );
      })}

      {/* Distant sun/moon reflection glint on the water */}
      <mesh position={[0, -0.02, -24]} rotation={[-Math.PI / 2, 0, 0]} material={skyFlat(isStorm ? '#7fa8d4' : '#fff3b8', 0.35)}>
        <planeGeometry args={[8, 18]} />
      </mesh>
    </group>
  );
};
