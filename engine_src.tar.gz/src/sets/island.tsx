// Bespoke 3D Island Adventure Sets for "What If You And Your Crush Were Stranded On An Island Alone?"
// Built with React Three Fiber / Three.js primitives from ./kit.
// 5 Custom Sets: crash_beach, reef_lagoon, jungle_camp, storm_beach, ridge_helipad.
import React from 'react';
import { At, Ball, Box, Cone, Cyl as KitCyl, Ground as KitGround, Rug } from './kit';
import type { SetProps } from './index';
import type { Vec3 } from '../types';

const Cyl: React.FC<{ p?: Vec3; r?: Vec3 | number; rad?: number; h?: number; s?: Vec3 | number; c: string; glow?: boolean }> = ({
  p,
  r,
  rad = 0.2,
  h = 0.5,
  s,
  c,
  glow,
}) => <KitCyl p={p} r={r} s={s ?? [rad, h, rad]} c={c} glow={glow} />;

const Disc: React.FC<{ p?: Vec3; r: number; c: string; y?: number }> = ({ p = [0, 0, 0], r, c, y }) => (
  <Rug p={[p[0], y ?? p[1], p[2]]} w={r * 2} d={r * 2} c={c} round />
);

const GlowBall: React.FC<{ p?: Vec3; size?: number; color?: string }> = ({
  p,
  size = 0.5,
  color = '#fef08a',
}) => <Ball p={p} s={size * 0.35} c={color} glow />;

const Ground: React.FC<{ c: string; r?: number; y?: number }> = ({ c, r = 160, y = 0 }) => (
  <KitGround c={c} size={r * 2} y={y} />
);

const SetFlames: React.FC<{ r?: number; k?: number; t?: number }> = ({ r = 0.5, k = 1, t = 0 }) => {
  const pulse = 0.85 + 0.22 * Math.sin(t * 12);
  const s = r * k * pulse;
  if (s <= 0.02) return null;
  return (
    <At>
      <Cone p={[0, s * 0.72, 0]} s={[s * 0.68, s * 1.45, s * 0.68]} c="#f97316" glow />
      <Cone p={[s * 0.18, s * 0.56, s * 0.1]} s={[s * 0.44, s * 1.12, s * 0.44]} c="#facc15" glow />
      <Cone p={[-s * 0.16, s * 0.52, -s * 0.1]} s={[s * 0.4, s * 0.98, s * 0.4]} c="#ef4444" glow />
      <GlowBall p={[0, s * 0.6, 0]} size={s * 1.6} color="#fb923c" />
    </At>
  );
};

const SetSmoke: React.FC<{ t?: number; h?: number; r?: number; n?: number; speed?: number; wind?: [number, number]; light?: boolean }> = ({
  t = 0,
  h = 6.5,
  r = 0.55,
  n = 18,
  speed = 1,
  wind = [0.28, 0.07],
  light = false,
}) => {
  const count = Math.min(20, n);
  return (
    <At>
      {Array.from({ length: count }, (_, i) => {
        const phase = (t * speed * 0.35 + i / count) % 1;
        const py = phase * h;
        const px = wind[0] * py + Math.sin(i * 2.1 + t * 1.4) * r * 0.38;
        const pz = wind[1] * py + Math.cos(i * 1.7 + t * 1.2) * r * 0.38;
        const sr = r * (0.35 + phase * 0.85);
        const col = light
          ? i % 2 === 0 ? '#f1f5f9' : '#e2e8f0'
          : i % 2 === 0 ? '#475569' : '#94a3b8';
        return <Ball key={i} p={[px, py, pz]} s={sr} c={col} ico />;
      })}
    </At>
  );
};

/**
 * Shared stage marks for all 5 bespoke island sets (all grounded at y = 0).
 */
export const BESPOKE_ISLAND_MARKS: Record<string, Vec3> = {
  center: [0, 0, 0.2],
  beach: [0, 0, 1.0],
  wreck: [-2.2, 0, -1.1],
  cargo: [-1.4, 0, -0.8],
  panel: [-1.8, 0, -1.0],
  camp: [0.2, 0, -1.0],
  shelter: [2.2, 0, -1.5],
  palm: [2.3, 0, -0.8],
  jungle: [0, 0, -1.3],
  solarPit: [-1.6, 0, -0.9],
  shore: [0, 0, 1.6],
  lagoon: [0, 0, 1.2],
  coral: [1.2, 0, 0.9],
  tide: [-1.1, 0, 1.2],
  lookout: [0, 0, -1.1],
  ridge: [0, 0, -0.8],
  stream: [1.4, 0, -0.6],
  boulder: [-1.8, 0, -1.1],
  bamboo: [2.1, 0, -1.4],
  trail: [0, 0, 0.5],
  summit: [0, 0, -0.6],
  cliff: [0, 0, 1.4],
  pad: [0, 0, -1.2],
  skid: [1.4, 0, -1.0],
  clearing: [0, 0, 0.8],
};

/** Tropical Palm Tree with curved segmented trunk, crown fronds, and 3D coconuts */
const IslandPalm: React.FC<{
  p: Vec3;
  h?: number;
  lean?: [number, number];
  scale?: number;
}> = ({ p, h = 4.8, lean = [0.07, 0.02], scale = 1 }) => {
  const segs = 7;
  const segH = (h * scale) / segs;
  const topX = lean[0] * segs * 0.45 * scale;
  const topZ = lean[1] * segs * 0.45 * scale;
  const topY = h * scale;
  const frondAngles = [0, 0.785, 1.57, 2.356, 3.1415, 3.927, 4.712, 5.497];

  return (
    <At p={p}>
      {Array.from({ length: segs }, (_, i) => {
        const w = (0.34 - i * 0.022) * scale;
        const ox = lean[0] * i * 0.45 * scale;
        const oz = lean[1] * i * 0.45 * scale;
        return (
          <Box
            key={i}
            p={[ox, (i + 0.5) * segH, oz]}
            s={[w, segH * 1.05, w]}
            c={i % 2 === 0 ? '#8c6239' : '#734f2c'}
          />
        );
      })}
      <Box p={[topX, topY + 0.14 * scale, topZ]} s={[0.48 * scale, 0.34 * scale, 0.48 * scale]} c="#15803d" />
      {/* Coconuts clustered under crown */}
      <Ball p={[topX + 0.2 * scale, topY - 0.06 * scale, topZ + 0.12 * scale]} s={0.14 * scale} c="#5c3820" />
      <Ball p={[topX - 0.18 * scale, topY - 0.08 * scale, topZ + 0.16 * scale]} s={0.13 * scale} c="#4e341c" />
      <Ball p={[topX + 0.05 * scale, topY - 0.09 * scale, topZ - 0.2 * scale]} s={0.14 * scale} c="#6b4423" />
      {frondAngles.map((ang, idx) => (
        <At key={idx} p={[topX, topY + 0.18 * scale, topZ]} r={[0, ang, 0]}>
          <Box p={[0.58 * scale, 0.06 * scale, 0]} r={[0, 0, -0.16]} s={[0.96 * scale, 0.11 * scale, 0.42 * scale]} c="#22c55e" />
          <Box p={[1.38 * scale, -0.18 * scale, 0]} r={[0, 0, -0.44]} s={[0.86 * scale, 0.09 * scale, 0.36 * scale]} c="#16a34a" />
          <Box p={[1.95 * scale, -0.52 * scale, 0]} r={[0, 0, -0.72]} s={[0.52 * scale, 0.07 * scale, 0.26 * scale]} c="#15803d" />
        </At>
      ))}
    </At>
  );
};

/** 3D Swimming Blue Parrotfish mesh used in reef_lagoon */
const SwimmingParrotfish: React.FC<{ p: Vec3; rotY?: number; t: number; phase?: number; scale?: number }> = ({
  p,
  rotY = 0,
  t,
  phase = 0,
  scale = 1,
}) => {
  const swimX = p[0] + Math.sin(t * 1.2 + phase) * 0.55;
  const swimZ = p[2] + Math.cos(t * 0.9 + phase) * 0.35;
  const wag = Math.sin(t * 9 + phase) * 0.28;
  return (
    <At p={[swimX, p[1], swimZ]} r={[0, rotY + Math.cos(t * 1.2 + phase) * 0.25, 0]} s={scale}>
      {/* Turquoise-blue body */}
      <Box p={[0, 0, 0]} s={[0.46, 0.22, 0.14]} c="#0284c7" />
      <Box p={[0.04, 0.02, 0]} s={[0.36, 0.16, 0.16]} c="#38bdf8" />
      {/* Pink/yellow tropical parrotfish stripes & beak */}
      <Box p={[0.24, -0.01, 0]} s={[0.08, 0.1, 0.1]} c="#facc15" />
      <Box p={[0.16, 0.03, 0.075]} s={[0.03, 0.03, 0.02]} c="#0f172a" />
      <Box p={[0.16, 0.03, -0.075]} s={[0.03, 0.03, 0.02]} c="#0f172a" />
      {/* Dorsal & ventral fins */}
      <Box p={[-0.02, 0.13, 0]} s={[0.26, 0.06, 0.03]} c="#ec4899" />
      <Box p={[-0.04, -0.12, 0]} s={[0.18, 0.05, 0.03]} c="#facc15" />
      {/* Wagging tail fin */}
      <At p={[-0.24, 0, 0]} r={[0, wag, 0]}>
        <Box p={[-0.08, 0, 0]} s={[0.16, 0.24, 0.03]} c="#22d3ee" />
        <Box p={[-0.14, 0, 0]} s={[0.05, 0.26, 0.035]} c="#ec4899" />
      </At>
    </At>
  );
};

// ============================================================================
// 1. CRASH BEACH (crash_beach)
// Turquoise ocean shader/waves, white coral sandbar, torn smoking Flight 815
// fuselage half-submerged, scattered luggage.
// ============================================================================
export const CrashBeachSet: React.FC<SetProps> = ({ t = 0 }) => {
  const waveZ = Math.sin(t * 1.8) * 0.28;
  return (
    <>
      {/* Deep Pacific & turquoise reef water layers */}
      <Ground c="#0369a1" r={170} y={-0.2} />
      <Box p={[0, -0.13, 0]} s={[76, 0.08, 56]} c="#0891b2" />
      <Box p={[0, -0.07, 0]} s={[48, 0.06, 34]} c="#22d3ee" />

      {/* Animated white surf foam bands washing onto the coral sandbar */}
      <Box p={[0, -0.02, 3.3 + waveZ]} s={[34, 0.04, 1.1]} c="#f0fdfa" />
      <Box p={[0, -0.02, 5.4 - waveZ * 0.7]} s={[38, 0.04, 0.75]} c="#ccfbf1" />
      <Box p={[0, -0.02, -5.8 + waveZ * 0.5]} s={[34, 0.04, 1.0]} c="#f0fdfa" />

      {/* White coral sandbar at y = 0 */}
      <Box p={[0, -0.04, -0.3]} s={[30, 0.08, 8.6]} c="#f6e3ba" />
      <Box p={[0, -0.025, -1.0]} s={[24, 0.05, 6.2]} c="#fdf4dc" />
      <Box p={[0, -0.035, 2.3]} s={[27, 0.05, 2.0]} c="#e2c48e" />

      {/* Torn, smoking Flight 815 fuselage half-submerged on left sandbar/surf */}
      <At p={[-4.6, 0, -2.6]} r={[0.04, 0.36, -0.09]}>
        <Box p={[0, 1.15, 0]} s={[6.0, 2.25, 2.5]} c="#f1f5f9" />
        <Box p={[0, 2.18, 0]} s={[5.5, 0.42, 1.95]} c="#ffffff" />
        {/* Royal-blue Flight 815 cheatline stripe */}
        <Box p={[0, 1.24, 1.26]} s={[5.8, 0.32, 0.05]} c="#1d4ed8" />
        <Box p={[0, 1.24, -1.26]} s={[5.8, 0.32, 0.05]} c="#1d4ed8" />
        {/* Passenger windows (including Exit Row 14B) */}
        {[-1.9, -1.0, -0.1, 0.8, 1.7].map((wx, i) => (
          <Box key={i} p={[wx, 1.56, 1.27]} s={[0.38, 0.48, 0.06]} c={i === 3 ? '#ef4444' : '#0f172a'} />
        ))}
        {/* Cockpit nose section */}
        <Box p={[-3.45, 1.0, 0]} s={[1.25, 1.7, 1.95]} c="#e2e8f0" />
        <Box p={[-3.3, 1.58, 0]} r={[0, 0, 0.35]} s={[0.88, 0.6, 1.6]} c="#0f172a" />
        {/* Jagged torn tail rupture exposing cabin seats & overhead bins */}
        <Box p={[2.95, 1.15, 0]} s={[0.38, 2.15, 2.4]} c="#1e293b" />
        <Box p={[3.15, 0.72, 0.68]} r={[0.2, 0.3, -0.35]} s={[0.95, 0.42, 0.14]} c="#94a3b8" />
        <Box p={[3.05, 1.55, -0.62]} r={[-0.2, -0.3, 0.4]} s={[1.05, 0.4, 0.14]} c="#64748b" />
        <Box p={[2.5, 0.78, 0.48]} s={[0.48, 0.78, 0.5]} c="#2563eb" />
      </At>

      {/* Severed Flight 815 tail fin half-submerged in right surf */}
      <At p={[5.3, 0, -3.5]} r={[-0.08, -0.42, 0.14]}>
        <Box p={[0, 0.85, 0]} s={[3.2, 1.7, 1.95]} c="#e2e8f0" />
        <Box p={[0, 0.96, 1.0]} s={[3.0, 0.28, 0.05]} c="#1d4ed8" />
        <Box p={[0.6, 2.5, 0]} r={[0, 0, -0.22]} s={[1.55, 2.5, 0.28]} c="#1d4ed8" />
        <Box p={[0.9, 3.15, 0]} r={[0, 0, -0.22]} s={[1.15, 0.52, 0.3]} c="#ffffff" />
      </At>

      {/* Smoking jet turbine engine & sheared leading-edge wing stub */}
      <At p={[-1.85, 0, -3.4]} r={[0.08, -0.28, 0.12]}>
        <Cyl p={[0, 0.68, 0]} r={[0, 0, Math.PI / 2]} rad={0.68} h={1.85} c="#334155" />
        <Cyl p={[-0.94, 0.68, 0]} r={[0, 0, Math.PI / 2]} rad={0.56} h={0.14} c="#0f172a" />
      </At>
      <At p={[-1.75, 0.95, -3.3]}>
        <SetFlames r={0.58} k={1} t={t} />
        <SetSmoke t={t} h={7.8} r={0.64} n={20} speed={1.05} wind={[0.3, 0.08]} />
      </At>
      <At p={[5.0, 1.25, -3.4]}>
        <SetFlames r={0.4} k={1} t={t + 1.5} />
        <SetSmoke t={t + 1.5} h={6.0} r={0.48} n={16} speed={0.95} wind={[0.26, 0.06]} />
      </At>

      {/* Scattered luggage, life vests, and cabin debris across the sandbar */}
      <Box p={[-3.1, 0.2, 0.85]} r={[0, 0.48, 0]} s={[0.72, 0.4, 0.5]} c="#dc2626" />
      <Box p={[-3.1, 0.42, 0.85]} r={[0, 0.48, 0]} s={[0.24, 0.07, 0.08]} c="#0f172a" />
      <Box p={[2.5, 0.18, 1.05]} r={[0, -0.35, 0.08]} s={[0.66, 0.36, 0.46]} c="#2563eb" />
      <Box p={[1.4, 0.14, -2.0]} r={[0, 0.22, 0]} s={[0.58, 0.28, 0.42]} c="#eab308" />
      <Box p={[-0.75, 0.08, 1.85]} r={[0, 0.65, 0]} s={[0.46, 0.14, 0.42]} c="#f97316" />
      <Box p={[3.4, 0.26, -1.5]} r={[0, -0.2, 0]} s={[0.62, 0.52, 0.62]} c="#78350f" />

      {/* Framing palms and basalt rocks */}
      <IslandPalm p={[-7.2, 0, -4.2]} h={5.2} lean={[0.1, 0.04]} />
      <IslandPalm p={[7.0, 0, -4.0]} h={4.9} lean={[-0.09, 0.05]} />
      <Box p={[-6.5, 0.45, 2.1]} s={[1.5, 0.9, 1.3]} c="#3f3f46" />
      <Box p={[6.2, 0.38, 2.4]} s={[1.35, 0.76, 1.15]} c="#52525b" />
    </>
  );
};

// ============================================================================
// 2. REEF LAGOON (reef_lagoon)
// Clear shallow water, vibrant coral heads, swimming blue parrotfish mesh.
// ============================================================================
export const ReefLagoonSet: React.FC<SetProps> = ({ t = 0 }) => {
  const ripple = Math.sin(t * 2.1) * 0.18;
  return (
    <>
      {/* Crystal-clear shallow turquoise reef water & bright white sand seafloor */}
      <Ground c="#0284c7" r={160} y={-0.22} />
      <Box p={[0, -0.14, 0]} s={[64, 0.06, 44]} c="#06b6d4" />
      <Box p={[0, -0.06, 0.4]} s={[38, 0.05, 24]} c="#22d3ee" />
      <Box p={[0, -0.02, 0.8]} s={[28, 0.03, 14]} c="#67e8f9" />

      {/* Warm coral sandbank on the back/left so actors at y=0 stand ankle-deep or on sandbar */}
      <Box p={[0, -0.03, -2.2]} s={[26, 0.06, 5.8]} c="#fdf4dc" />
      <Box p={[0, -0.015, 2.2 + ripple]} s={[24, 0.02, 0.65]} c="#ecfeff" />
      <Box p={[0, -0.015, -0.4 - ripple]} s={[22, 0.02, 0.55]} c="#cffafe" />

      {/* Vibrant 3D Coral Heads (pink brain coral, orange staghorn, purple sea fans) */}
      {[
        [-2.8, 0.8, '#f43f5e', '#fb923c'],
        [2.6, 0.9, '#ec4899', '#a855f7'],
        [-1.2, 2.3, '#f97316', '#facc15'],
        [1.5, 2.1, '#a855f7', '#ec4899'],
        [3.8, -0.5, '#f43f5e', '#f97316'],
        [-3.9, -0.6, '#ec4899', '#38bdf8'],
      ].map(([cx, cz, c1, c2], idx) => (
        <At key={idx} p={[cx as number, 0, cz as number]}>
          <Box p={[0, 0.14, 0]} s={[0.85, 0.28, 0.75]} c="#475569" />
          <Ball p={[-0.12, 0.34, 0.05]} s={0.26} c={c1 as string} ico />
          <Ball p={[0.18, 0.3, -0.06]} s={0.22} c={c2 as string} ico />
          {/* Staghorn coral branches */}
          <Cyl p={[0.05, 0.48, 0.12]} r={[0.2, 0, -0.25]} rad={0.045} h={0.38} c="#fb923c" />
          <Cyl p={[-0.15, 0.45, -0.1]} r={[-0.2, 0, 0.28]} rad={0.04} h={0.34} c="#facc15" />
        </At>
      ))}

      {/* School of animated swimming blue parrotfish */}
      <SwimmingParrotfish p={[0.6, 0.22, 1.1]} rotY={-0.3} t={t} phase={0} scale={1.15} />
      <SwimmingParrotfish p={[-1.5, 0.2, 1.4]} rotY={0.4} t={t} phase={1.8} scale={1.0} />
      <SwimmingParrotfish p={[2.1, 0.24, 1.6]} rotY={-0.8} t={t} phase={3.2} scale={0.95} />
      <SwimmingParrotfish p={[-0.4, 0.18, 2.5]} rotY={0.2} t={t} phase={4.5} scale={1.05} />

      {/* Framing lagoon palms and basalt reef outcrops */}
      <IslandPalm p={[-6.2, 0, -3.4]} h={5.0} lean={[0.11, 0.04]} />
      <IslandPalm p={[6.0, 0, -3.2]} h={4.8} lean={[-0.1, 0.04]} />
      <IslandPalm p={[0.5, 0, -4.5]} h={5.3} lean={[0.04, 0.05]} />
      <Box p={[-5.4, 0.42, 1.8]} s={[1.4, 0.84, 1.2]} c="#334155" />
      <Box p={[5.2, 0.38, 2.0]} s={[1.3, 0.76, 1.1]} c="#475569" />
    </>
  );
};

// ============================================================================
// 3. JUNGLE CAMP (jungle_camp)
// Palm trees, bamboo A-frame shelter with leaf roof, stone fire ring,
// 3 conical solar distillation pits covered in clear plastic.
// ============================================================================
export const JungleCampSet: React.FC<SetProps> = ({ t = 0 }) => {
  return (
    <>
      {/* Turquoise lagoon horizon & warm sandy jungle clearing at y = 0 */}
      <Ground c="#0891b2" r={150} y={-0.16} />
      <Box p={[0, -0.04, 0]} s={[34, 0.08, 22]} c="#f1d399" />
      <Box p={[0, -0.02, -1.0]} s={[26, 0.04, 14]} c="#e5c383" />
      <Box p={[0, -0.015, -3.6]} s={[28, 0.03, 7.5]} c="#36692f" />

      {/* Bamboo A-Frame Shelter with Green Palm-Leaf Roof & Single Leaf Mattress */}
      <At p={[3.1, 0, -2.3]} r={[0, -0.35, 0]}>
        <Box p={[0, 0.04, 0]} s={[3.2, 0.08, 2.7]} c="#d9b87c" />
        {/* Slanted bamboo rafters */}
        <Box p={[-0.85, 1.15, 1.1]} r={[0, 0, -0.58]} s={[0.14, 2.65, 0.14]} c="#84cc16" />
        <Box p={[0.85, 1.15, 1.1]} r={[0, 0, 0.58]} s={[0.14, 2.65, 0.14]} c="#84cc16" />
        <Box p={[-0.85, 1.15, -1.1]} r={[0, 0, -0.58]} s={[0.14, 2.65, 0.14]} c="#65a30d" />
        <Box p={[0.85, 1.15, -1.1]} r={[0, 0, 0.58]} s={[0.14, 2.65, 0.14]} c="#65a30d" />
        {/* Braided hibiscus cordage knots at ridgepole apex */}
        <Box p={[0, 2.15, 0]} s={[0.16, 0.16, 2.85]} c="#a37c40" />
        <Box p={[0, 2.18, 1.1]} s={[0.24, 0.22, 0.24]} c="#78350f" />
        {/* Layered green palm-frond leaf roof */}
        <Box p={[-0.58, 1.55, 0]} r={[0, 0, 0.98]} s={[0.12, 1.48, 2.55]} c="#22c55e" />
        <Box p={[-0.95, 0.85, 0]} r={[0, 0, 0.98]} s={[0.12, 1.38, 2.6]} c="#16a34a" />
        <Box p={[0.58, 1.55, 0]} r={[0, 0, -0.98]} s={[0.12, 1.48, 2.55]} c="#22c55e" />
        <Box p={[0.95, 0.85, 0]} r={[0, 0, -0.98]} s={[0.12, 1.38, 2.6]} c="#15803d" />
        {/* Single woven leaf mattress inside the narrow triangular frame */}
        <Box p={[0, 0.1, 0]} s={[1.15, 0.08, 1.95]} c="#4ade80" />
        <Box p={[0, 0.15, -0.7]} s={[0.95, 0.1, 0.35]} c="#22c55e" />
      </At>

      {/* Cobblestone Fire Ring & Driftwood Seats */}
      <At p={[0.15, 0, -1.9]}>
        <Disc p={[0, 0.02, 0]} r={0.95} c="#3b2f26" />
        {Array.from({ length: 12 }, (_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return (
            <Box
              key={i}
              p={[Math.cos(a) * 0.86, 0.14, Math.sin(a) * 0.86]}
              r={[0, -a, 0]}
              s={[0.34, 0.28, 0.28]}
              c={i % 2 === 0 ? '#64748b' : '#475569'}
            />
          );
        })}
        <Box p={[0, 0.16, 0]} r={[0, 0.4, 0]} s={[0.95, 0.15, 0.18]} c="#6b4423" />
        <Box p={[0, 0.18, 0]} r={[0, -0.6, 0]} s={[0.95, 0.15, 0.18]} c="#5c3a1d" />
        <SetFlames r={0.38} k={0.9} t={t} />
        {/* Driftwood log benches */}
        <Box p={[-1.4, 0.22, 0.35]} r={[0, 0.3, 0]} s={[0.38, 0.34, 1.45]} c="#8c6239" />
        <Box p={[1.4, 0.22, 0.35]} r={[0, -0.3, 0]} s={[0.38, 0.34, 1.45]} c="#8c6239" />
      </At>

      {/* 3 Conical Solar Distillation Pits covered in clear plastic with pebble weights */}
      {[
        [-2.2, -1.3],
        [-3.6, -1.6],
        [-2.8, -2.8],
      ].map(([px, pz], idx) => (
        <At key={idx} p={[px, 0, pz]}>
          {/* Conical 1m pit rim & dark damp sand interior */}
          <Disc p={[0, 0.015, 0]} r={0.64} c="#8c6d46" />
          <Disc p={[0, 0.025, 0]} r={0.48} c="#3f2e1e" />
          {/* Crushed green shoreline plants packed around central cup */}
          <Box p={[-0.24, 0.05, 0.1]} r={[0, 0.4, 0]} s={[0.22, 0.04, 0.14]} c="#22c55e" />
          <Box p={[0.24, 0.05, -0.1]} r={[0, -0.5, 0]} s={[0.22, 0.04, 0.14]} c="#16a34a" />
          <Box p={[0.05, 0.05, 0.25]} r={[0, 0.2, 0]} s={[0.2, 0.04, 0.14]} c="#4ade80" />
          {/* Central collection cup */}
          <Cyl p={[0, 0.08, 0]} rad={0.11} h={0.14} c="#f8fafc" />
          <Cyl p={[0, 0.14, 0]} rad={0.095} h={0.03} c="#38bdf8" glow />
          {/* Inverted clear plastic cone & center pebble weight */}
          <Cone p={[0, 0.13, 0]} r={[Math.PI, 0, 0]} s={[0.56, 0.14, 0.56]} c="#bae6fd" />
          <Box p={[0, 0.18, 0]} s={[1.1, 0.02, 1.1]} c="#e0f2fe" />
          <Ball p={[0, 0.19, 0]} s={0.09} c="#334155" />
          {/* Perimeter anchor stones */}
          <Box p={[0.54, 0.08, 0]} s={[0.18, 0.14, 0.18]} c="#64748b" />
          <Box p={[-0.54, 0.08, 0]} s={[0.18, 0.14, 0.18]} c="#64748b" />
          <Box p={[0, 0.08, 0.54]} s={[0.18, 0.14, 0.18]} c="#475569" />
          <Box p={[0, 0.08, -0.54]} s={[0.18, 0.14, 0.18]} c="#475569" />
        </At>
      ))}

      {/* Driftwood aiming tripod standing near camp */}
      <At p={[-1.2, 0, -2.4]}>
        <Box p={[-0.35, 0.72, 0.26]} r={[0.22, 0, -0.26]} s={[0.09, 1.55, 0.09]} c="#8c6239" />
        <Box p={[0.35, 0.72, 0.26]} r={[0.22, 0, 0.26]} s={[0.09, 1.55, 0.09]} c="#8c6239" />
        <Box p={[0, 0.72, -0.36]} r={[-0.28, 0, 0]} s={[0.09, 1.55, 0.09]} c="#75512d" />
        <Box p={[0, 1.38, 0]} s={[0.28, 0.12, 0.28]} c="#d4a359" />
      </At>

      {/* Lush camp palm canopy & bamboo stalks */}
      <IslandPalm p={[-5.2, 0, -3.2]} h={5.1} lean={[0.09, 0.03]} />
      <IslandPalm p={[5.5, 0, -3.3]} h={5.3} lean={[-0.08, 0.04]} />
      <IslandPalm p={[0.3, 0, -4.9]} h={5.6} lean={[0.03, 0.06]} />
      <IslandPalm p={[-2.4, 0, -4.6]} h={5.0} lean={[-0.05, 0.04]} />
    </>
  );
};

// ============================================================================
// 4. STORM BEACH (storm_beach)
// Dark cyclone sky, driving rain particles, rising surge waves,
// fallen 180kg aluminum beam.
// ============================================================================
export const StormBeachSet: React.FC<SetProps> = ({ t = 0 }) => {
  const surgeZ = Math.sin(t * 2.6) * 0.42;

  // 72 deterministic slanted 3D rain streaks driving across the cyclone scene
  const rainDrops = Array.from({ length: 72 }, (_, i) => {
    const rx = ((i * 5.7) % 18) - 9.0;
    const rz = ((i * 3.3) % 9) - 4.0;
    const ry = 4.8 - ((t * 11.0 + i * 0.37) % 4.6);
    return [rx, ry, rz] as Vec3;
  });

  return (
    <>
      {/* Dark churning cyclone ocean & storm-flooded beach */}
      <Ground c="#082f49" r={160} y={-0.14} />
      <Box p={[0, -0.06, 0]} s={[52, 0.08, 34]} c="#0c4a6e" />
      <Box p={[0, -0.03, -0.6]} s={[28, 0.06, 9.8]} c="#57534e" />
      <Box p={[0, -0.02, -1.8]} s={[24, 0.04, 6.4]} c="#78716c" />

      {/* Dark rotating cumulonimbus storm wall on the horizon */}
      <Box p={[0, 4.2, -16]} s={[48, 4.5, 4]} c="#0f172a" />
      <Box p={[-8, 3.2, -14]} s={[22, 3.2, 3.5]} c="#1e293b" />
      <Box p={[8, 3.4, -14]} s={[22, 3.4, 3.5]} c="#1e293b" />

      {/* Rising 2m storm-surge wave walls crashing onto the 1.2m beach */}
      <At p={[0, 0, 2.0 + surgeZ]}>
        <Box p={[0, 0.28, 0]} s={[30, 0.56, 1.5]} c="#0369a1" />
        <Box p={[0, 0.6, -0.45]} s={[30, 0.22, 0.85]} c="#e0f2fe" />
        <Box p={[0, 0.05, -1.2]} s={[28, 0.08, 1.3]} c="#7dd3fc" />
      </At>

      {/* Fallen 180kg Structural Aluminum Fuselage Beam at the tideline */}
      <At p={[1.35, 0, 0.55]} r={[0.05, -0.22, -0.12]}>
        <Box p={[0, 0.28, 0]} s={[2.9, 0.46, 0.72]} c="#94a3b8" />
        <Box p={[0, 0.52, 0]} s={[2.75, 0.12, 0.78]} c="#cbd5e1" />
        {/* Royal-blue airline stripe & structural rivets on the 180kg beam */}
        <Box p={[0, 0.3, 0.37]} s={[2.8, 0.14, 0.04]} c="#1d4ed8" />
        {/* Basalt fulcrum rock positioned 40cm from load */}
        <Box p={[-0.65, 0.22, 0.42]} s={[0.48, 0.44, 0.46]} c="#1e293b" />
      </At>

      {/* Storm-lashed fire ring & anchored driftwood tripod */}
      <At p={[0.0, 0, -1.5]}>
        <Disc p={[0, 0.02, 0]} r={0.9} c="#1e293b" />
        {Array.from({ length: 10 }, (_, i) => {
          const a = (i / 10) * Math.PI * 2;
          return (
            <Box
              key={i}
              p={[Math.cos(a) * 0.82, 0.14, Math.sin(a) * 0.82]}
              r={[0, -a, 0]}
              s={[0.32, 0.26, 0.26]}
              c="#334155"
            />
          );
        })}
        <Box p={[0, 0.16, 0]} r={[0, 0.4, 0]} s={[0.9, 0.16, 0.18]} c="#451a03" />
        <Box p={[0.95, 0.14, -0.2]} r={[0, 0.3, 0.1]} s={[0.85, 0.18, 0.45]} c="#15803d" />
      </At>

      {/* Wind-lashed palm trees bending violently in the 220 km/h cyclone */}
      <IslandPalm p={[-5.2, 0, -3.2]} h={4.8} lean={[0.28, 0.09]} />
      <IslandPalm p={[5.4, 0, -3.4]} h={4.9} lean={[0.26, 0.1]} />

      {/* Driving diagonal 3D rain streaks */}
      {rainDrops.map((rp, i) => (
        <Box key={i} p={rp} r={[0, 0, -0.32]} s={[0.024, 0.56, 0.024]} c="#bae6fd" />
      ))}
    </>
  );
};

// ============================================================================
// 5. RIDGE HELIPAD (ridge_helipad)
// 40m basalt cliff at dawn with a 3D rescue helicopter and spinning rotors.
// ============================================================================
export const RidgeHelipadBespokeSet: React.FC<SetProps> = ({ t = 0 }) => {
  const rotorAngle = t * 24;

  return (
    <>
      {/* Distant turquoise ocean & miniature island reef 40m below the cliff */}
      <Ground c="#0c4a6e" r={180} y={-8.0} />
      <At p={[0, -6.8, -24]}>
        <Box p={[0, 0, 0]} s={[28, 0.2, 16]} c="#06b6d4" />
        <Box p={[0, 0.18, 0]} s={[18, 0.28, 10]} c="#fde68a" />
      </At>

      {/* 40m Volcanic Basalt Cliff Plateau at y = 0 */}
      <Box p={[0, -2.5, 0]} s={[22, 5.0, 14]} c="#18181b" />
      <Box p={[0, -0.05, 0]} s={[20, 0.1, 12.5]} c="#27272a" />
      <Box p={[0, -0.02, 0.2]} s={[16.5, 0.05, 9.5]} c="#3f3f46" />

      {/* Helipad Landing Circle & White 'H' Marker */}
      <At p={[0, 0, -1.8]}>
        <Disc p={[0, 0.015, 0]} r={3.6} c="#334155" />
        <Disc p={[0, 0.025, 0]} r={3.2} c="#475569" />
        <Box p={[-0.95, 0.035, 0]} s={[0.35, 0.02, 2.2]} c="#f8fafc" />
        <Box p={[0.95, 0.035, 0]} s={[0.35, 0.02, 2.2]} c="#f8fafc" />
        <Box p={[0, 0.035, 0]} s={[1.9, 0.02, 0.35]} c="#f8fafc" />
        {Array.from({ length: 8 }, (_, i) => {
          const a = (i / 8) * Math.PI * 2;
          return (
            <GlowBall
              key={i}
              p={[Math.cos(a) * 3.4, 0.12, Math.sin(a) * 3.4]}
              size={0.28}
              color="#facc15"
            />
          );
        })}
      </At>

      {/* 3D Coast Guard Rescue Helicopter with Spinning Main & Tail Rotors */}
      <At p={[0.2, 0, -2.5]} r={[0, 0.22, 0]}>
        {/* Landing skids */}
        <Box p={[0, 0.1, 0.88]} s={[3.1, 0.12, 0.14]} c="#1e293b" />
        <Box p={[0, 0.1, -0.88]} s={[3.1, 0.12, 0.14]} c="#1e293b" />
        <Box p={[-0.85, 0.38, 0.88]} s={[0.12, 0.52, 0.12]} c="#334155" />
        <Box p={[0.85, 0.38, 0.88]} s={[0.12, 0.52, 0.12]} c="#334155" />
        <Box p={[-0.85, 0.38, -0.88]} s={[0.12, 0.52, 0.12]} c="#334155" />
        <Box p={[0.85, 0.38, -0.88]} s={[0.12, 0.52, 0.12]} c="#334155" />

        {/* Coast Guard Orange & White Fuselage Cabin */}
        <Box p={[0, 1.32, 0]} s={[3.4, 1.48, 1.78]} c="#ea580c" />
        <Box p={[0, 1.38, 0]} s={[3.44, 0.38, 1.82]} c="#f8fafc" />
        {/* Open sliding cabin door */}
        <Box p={[0.15, 1.28, 0.9]} s={[1.25, 1.05, 0.06]} c="#0f172a" />
        {/* Cockpit nose & windshield */}
        <Box p={[-1.95, 1.15, 0]} s={[0.95, 1.08, 1.54]} c="#ea580c" />
        <Box p={[-1.85, 1.48, 0]} s={[0.85, 0.62, 1.44]} c="#38bdf8" />

        {/* Tail boom & vertical stabilizer */}
        <Box p={[2.85, 1.52, 0]} s={[2.6, 0.52, 0.52]} c="#ea580c" />
        <Box p={[3.95, 2.05, 0]} r={[0, 0, 0.28]} s={[0.62, 1.25, 0.16]} c="#f8fafc" />
        {/* Spinning tail rotor */}
        <At p={[4.05, 2.1, 0.18]} r={[0, 0, rotorAngle * 1.6]}>
          <Box s={[0.95, 0.1, 0.04]} c="#0f172a" />
          <Box s={[0.1, 0.95, 0.04]} c="#0f172a" />
        </At>

        {/* Rotor mast & spinning 4-blade main rotor */}
        <Cyl p={[0, 2.25, 0]} rad={0.16} h={0.45} c="#334155" />
        <At p={[0, 2.48, 0]} r={[0, rotorAngle, 0]}>
          <Box s={[6.8, 0.05, 0.28]} c="#0f172a" />
          <Box s={[0.28, 0.05, 6.8]} c="#0f172a" />
        </At>

        {/* Searchlights under nose */}
        <GlowBall p={[-2.15, 0.65, 0.35]} size={2.2} color="#fef08a" />
        <GlowBall p={[-2.15, 0.65, -0.35]} size={2.2} color="#fef08a" />
      </At>
      <Disc p={[-1.8, 0.03, -0.4]} r={1.85} c="#fef9c3" />

      {/* Basalt cliff crags & ridge palms */}
      <Box p={[-6.4, 0.85, -2.2]} s={[2.2, 1.7, 2.0]} c="#27272a" />
      <Box p={[6.4, 0.95, -2.0]} s={[2.4, 1.9, 2.0]} c="#27272a" />
      <IslandPalm p={[-6.8, 0, 1.5]} h={4.4} lean={[0.12, 0.04]} scale={0.92} />
      <IslandPalm p={[6.8, 0, 1.4]} h={4.5} lean={[-0.12, 0.04]} scale={0.92} />
    </>
  );
};
