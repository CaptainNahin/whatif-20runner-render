// Synchronized bottom-center cinema caption overlay (8% from bottom, 4-6 words per chunk,
// bold white sans-serif text on a subtle dark pill with the active spoken word highlighted in #FFD700).
import React from 'react';
import { AbsoluteFill } from 'remotion';
import type { Words } from '../episode/cue';

type TimedDisplayWord = {
  display: string;
  t0: number;
  t1: number;
};

const cleanVo = (s: string) =>
  (s || '')
    .replace(/\[[^\]]*\]/g, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

const normToken = (s: string) =>
  s
    .toLowerCase()
    .replace(/[’']/g, "'")
    .replace(/[^a-z0-9']+/g, '');

function buildTimedDisplayWords(vo: string, words: Words | undefined, dur: number): TimedDisplayWord[] {
  const cleaned = cleanVo(vo);
  if (!cleaned) return [];
  const rawTokens = cleaned.split(/\s+/).filter(Boolean);
  if (!rawTokens.length) return [];

  if (!words || !words.length) {
    const span = Math.max(0.4, dur - 0.3);
    return rawTokens.map((display, i) => ({
      display,
      t0: 0.1 + (i / rawTokens.length) * span,
      t1: 0.1 + ((i + 1) / rawTokens.length) * span,
    }));
  }

  let wCursor = 0;
  const result: TimedDisplayWord[] = [];
  for (let i = 0; i < rawTokens.length; i++) {
    const display = rawTokens[i];
    // A hyphenated token like "Fourteen-B" or "karate-chop" may span 1 or 2 entries in `words`
    const subParts = display
      .split(/[-–—]+/)
      .map(normToken)
      .filter(Boolean);
    const count = Math.max(1, subParts.length);

    // Search nearby in `words` for first subPart match
    let matchedIdx = -1;
    if (subParts.length > 0) {
      for (let j = wCursor; j < Math.min(words.length, wCursor + 4); j++) {
        if (normToken(words[j][0]) === subParts[0]) {
          matchedIdx = j;
          break;
        }
      }
    }
    if (matchedIdx < 0) {
      matchedIdx = Math.min(words.length - 1, wCursor);
    }
    const t0 = words[matchedIdx][1];
    wCursor = Math.min(words.length - 1, matchedIdx + count);
    const nextT = matchedIdx + count < words.length ? words[matchedIdx + count][1] : Math.max(t0 + 0.28, dur - 0.15);
    result.push({
      display,
      t0,
      t1: Math.max(t0 + 0.12, nextT),
    });
  }

  // Ensure monotonic start/end times
  for (let i = 0; i < result.length - 1; i++) {
    if (result[i + 1].t0 < result[i].t0) {
      result[i + 1].t0 = result[i].t0 + 0.08;
    }
    result[i].t1 = Math.max(result[i].t0 + 0.06, result[i + 1].t0);
  }
  return result;
}

export const Subtitles: React.FC<{
  vo?: string;
  words?: Words;
  t: number;
  dur: number;
  chunkSize?: number;
}> = ({ vo, words, t, dur, chunkSize = 5 }) => {
  if (!vo) return null;
  const timed = buildTimedDisplayWords(vo, words, dur);
  if (!timed.length) return null;

  const firstT = timed[0].t0;
  const lastT = timed[timed.length - 1].t1;
  if (t < firstT - 0.25 || t > lastT + 0.45) return null;

  // Fade in at start of line and fade out after last word
  const fadeIn = Math.min(1, Math.max(0, (t - (firstT - 0.25)) / 0.15));
  const fadeOut = Math.min(1, Math.max(0, (lastT + 0.45 - t) / 0.2));
  const opacity = Math.min(fadeIn, fadeOut);
  if (opacity <= 0.01) return null;

  // Active word index
  let activeIdx = 0;
  for (let i = 0; i < timed.length; i++) {
    if (t + 0.03 >= timed[i].t0) {
      activeIdx = i;
    } else {
      break;
    }
  }

  // Group into chunks of 4-6 words (default 5, avoiding 1-word orphan chunks at the end)
  const chunks: TimedDisplayWord[][] = [];
  let idx = 0;
  while (idx < timed.length) {
    const remaining = timed.length - idx;
    const take = remaining <= 6 ? remaining : remaining === 7 ? 4 : chunkSize;
    chunks.push(timed.slice(idx, idx + take));
    idx += take;
  }

  let activeChunk = chunks[0];
  let activeInChunk = activeIdx;
  let acc = 0;
  for (const ch of chunks) {
    if (activeIdx < acc + ch.length) {
      activeChunk = ch;
      activeInChunk = activeIdx - acc;
      break;
    }
    acc += ch.length;
  }

  return (
    <AbsoluteFill
      style={{
        pointerEvents: 'none',
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingBottom: '8%',
      }}
    >
      <div
        style={{
          display: 'inline-flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          alignItems: 'center',
          gap: '12px',
          maxWidth: '82%',
          padding: '13px 30px',
          borderRadius: '999px',
          background: 'rgba(10, 14, 24, 0.78)',
          border: '1.5px solid rgba(255, 255, 255, 0.15)',
          boxShadow: '0 8px 26px rgba(0, 0, 0, 0.6)',
          opacity,
        }}
      >
        {activeChunk.map((w, i) => {
          const isCurrent = i === activeInChunk && t >= firstT - 0.05;
          return (
            <span
              key={i}
              style={{
                fontFamily: '"Inter", "Barlow", "DejaVu Sans", "Helvetica Neue", Arial, sans-serif',
                fontWeight: 800,
                fontSize: '42px',
                lineHeight: 1.18,
                letterSpacing: '0.01em',
                color: isCurrent ? '#FFD700' : '#FFFFFF',
                textShadow: isCurrent
                  ? '0 0 16px rgba(255, 215, 0, 0.45), 0 3px 8px rgba(0, 0, 0, 0.95)'
                  : '0 3px 8px rgba(0, 0, 0, 0.9)',
                transform: isCurrent ? 'scale(1.06)' : 'scale(1)',
                display: 'inline-block',
              }}
            >
              {w.display}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
