import fs from 'node:fs';
import { Config } from '@remotion/cli/config';

const browserCandidates = [
  process.env.REMOTION_CHROME_EXECUTABLE,
  '/data/data/com.termux/files/usr/bin/chromium',
  '/data/data/com.termux/files/usr/bin/chromium-browser',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/usr/bin/google-chrome',
].filter(Boolean) as string[];

const browserExecutable = browserCandidates.find((p) => fs.existsSync(p));
if (browserExecutable) {
  Config.setBrowserExecutable(browserExecutable);
}

Config.setChromeMode('chrome-for-testing');
// GPU WebGL through ANGLE/SWANGLE; lossless PNG frames so the final encode is the only lossy step.
Config.setChromiumOpenGlRenderer(process.platform === 'android' ? 'swangle' : 'angle');
Config.setVideoImageFormat('png');
Config.setPixelFormat('yuv420p');
Config.setCodec('h264');
Config.setCrf(14);
Config.setOverwriteOutput(true);
